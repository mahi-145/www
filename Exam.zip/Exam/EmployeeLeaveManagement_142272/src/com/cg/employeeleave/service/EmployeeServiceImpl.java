package com.cg.employeeleave.service;

import java.util.Iterator;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employeeleave.beans.EmployeeDetails;
import com.cg.employeeleave.beans.EmployeeLeaveDetails;
import com.cg.employeeleave.dao.IEmployeeDAO;

@Service("employeeservice")
@Transactional
public class EmployeeServiceImpl implements IEmployeeService 
{
	@Autowired
	IEmployeeDAO employeeDao;
	
	@Override
	public List<EmployeeLeaveDetails> getEmployeeLeaveDeatils(int empId) {
		// TODO Auto-generated method stub
		return employeeDao.getEmployeeLeaveDeatils(empId);
	}

	@Override
	public List<EmployeeDetails> getEmployeeName(int empId) {
		// TODO Auto-generated method stub
		return employeeDao.getEmployeeName(empId);
	}

	@Override
	public List<Integer> getEmployeeIds()
	{
		// TODO Auto-generated method stub
		return employeeDao.getEmployeeIds();
	}

	
	/******************************Employee Id validation ******************************/
	@Override
	public boolean validateEmployeeId(int empId) 
	{
		int count=0;
		Iterator it=employeeDao.getEmployeeIds().iterator();
		
		while(it.hasNext())
		{
			int id=(int)it.next();
			if(empId == id)
			{
				count=1;
				break;
			}
		}
		if(count==1)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}

	@Override
	public List<Integer> getEmpIds() 
	{
		// TODO Auto-generated method stub
		return employeeDao.getEmpIds();
	}

	@Override
	public boolean ValidateEmpIds(int empId) 
	{
		int count=0;
		Iterator it=employeeDao.getEmpIds().iterator();
		
		while(it.hasNext())
		{
			int id=(int)it.next();
			if(empId == id)
			{
				count=1;
				break;
			}
		}
		if(count==1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public String getName(int empId)
	{
		System.out.println(empId);
		return employeeDao.getName(empId);
	}

}
