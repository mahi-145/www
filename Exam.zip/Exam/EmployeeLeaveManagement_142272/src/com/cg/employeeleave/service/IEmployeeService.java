package com.cg.employeeleave.service;

import java.util.List;

import com.cg.employeeleave.beans.EmployeeDetails;
import com.cg.employeeleave.beans.EmployeeLeaveDetails;

public interface IEmployeeService 
{
	public List<EmployeeLeaveDetails> getEmployeeLeaveDeatils(int empId);
	
	public List<EmployeeDetails> getEmployeeName(int empId);
	
	/****************************************************************/
	public List<Integer> getEmployeeIds();
	public boolean  validateEmployeeId(int empId);
	
	public List<Integer> getEmpIds();
	public boolean ValidateEmpIds(int empId);
	
	public String getName(int empId);
}
