package com.cg.employeeleave.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee_details")
public class EmployeeDetails 
{
	@Id
	@Column(name="empid")
	private Integer empId;
	
	@Column(name="ename")
	private String empName;
	
	@Column(name="address")
	private String empAddress;
	
	@Column(name="leaves_avail")
	private Integer leavesAvail;

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpAddress() {
		return empAddress;
	}

	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}

	public Integer getLeavesAvail() {
		return leavesAvail;
	}

	public void setLeavesAvail(Integer leavesAvail) {
		this.leavesAvail = leavesAvail;
	}

	@Override
	public String toString() {
		return "EmployeeDetails [empId=" + empId + ", empName=" + empName
				+ ", empAddress=" + empAddress + ", leavesAvail=" + leavesAvail
				+ "]";
	}

	public EmployeeDetails() 
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeDetails(Integer empId, String empName, String empAddress,
			Integer leavesAvail) 
	{
		super();
		this.empId = empId;
		this.empName = empName;
		this.empAddress = empAddress;
		this.leavesAvail = leavesAvail;
	}
	
	
	
	
}
