package com.cg.employeeleave.beans;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee_leave_details")
public class EmployeeLeaveDetails 
{
	@Id
	@Column(name="leave_id")
	private Integer empLeaveId;
	
	@Column(name="empid")
	private Integer empId;
	
	@Column(name="start_date")
	private Date startDate;
	
	@Column(name="end_date")
	private Date endDate;
	
	@Column(name="description")
	private String description;
	
	@Column(name="leaves_applied")
	private Integer leavesApplied;

	public Integer getEmpLeaveId() {
		return empLeaveId;
	}

	public void setEmpLeaveId(Integer empLeaveId) {
		this.empLeaveId = empLeaveId;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getLeavesApplied() {
		return leavesApplied;
	}

	public void setLeavesApplied(Integer leavesApplied) {
		this.leavesApplied = leavesApplied;
	}

	public EmployeeLeaveDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeLeaveDetails(Integer empLeaveId, Integer empId,
			Date startDate, Date endDate, String description,
			Integer leavesApplied) {
		super();
		this.empLeaveId = empLeaveId;
		this.empId = empId;
		this.startDate = startDate;
		this.endDate = endDate;
		this.description = description;
		this.leavesApplied = leavesApplied;
	}

	@Override
	public String toString() {
		return "EmployeeLeaveDetails [empLeaveId=" + empLeaveId + ", empId="
				+ empId + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", description=" + description + ", leavesApplied="
				+ leavesApplied + "]";
	}
	
	
	
}
