<?php
	require_once("Rest.inc.php");
    include("../include/function.php");
	    class API extends REST {
		public $data = "";
		const DB_SERVER = "localhost";
		const DB_USER = "root";
		const DB_PASSWORD = "";
		const DB = "Abhishek";
		private $db = NULL;
	
		public function __construct(){
			parent::__construct();				
			$this->dbConnect();					
		}
		private function dbConnect(){
			$this->db = mysql_connect(self::DB_SERVER,self::DB_USER,self::DB_PASSWORD);
			if($this->db)
			{
				mysql_select_db(self::DB,$this->db);
			}
		}

		public function processApi(){

			$func = strtolower(trim(str_replace("api/","",$_REQUEST['rquest'])));

		 	if((int)method_exists($this,$func) > 0)
				$this->$func();
			else
				$this->response('',404);				// If the method not exist with in this class, response would be "Page not found".
		}

//////////////////////////////////////////  Login code /////////////////////////////////////////////////////////////////////////
		private function doLogin(){
			if($this->get_request_method() != "POST"){
				$this->response('',406);
			}
			 
			 $body = file_get_contents("php://input");
			 $xml = simplexml_load_string($body);

			foreach($xml->children() as $child)
			  {
			  switch($child->getName()){
			   case "userId": 
			   		$email = $child;
					break;
			   case "password": 
			   		$password = $child;
					break;
					}
			  }
			if($email!='' && $password!=''){
					$sql = mysql_query("Select * From tbl_users Where UserID = '$email' && Password = '$password'", $this->db);
					if(mysql_num_rows($sql) > 0){
					$result = mysql_fetch_array($sql,MYSQL_ASSOC);
					$error = array('errorCode' => "0", "errorstring" => "success");
					$this->response($this->xml($error,'status'), 200);
				}
				else
				{
						$error = array('errorCode' => 400, "errorstring" => "Protocol error");
						$this->response($this->xml($error,'status'), 400);
				}
			}
			else
			{
					$error = array('errorCode' => 400, "errorstring" => "success");
					$this->response($this->xml($error,'status'), 400);
			}
		}

///////////////////////////////////////////////   Get Location Code ///////////////////////////////////////////////////////////////////////////////
        
		private function location(){	
			    if($this->get_request_method() != "POST"){
				$this->response('',406);
			    }
		     $id = $this->_request['userId'];		
             $headers = apache_request_headers();
			 foreach ($headers as $header => $value) 
			  {
				 if($header == "Latitude")
				  $Latitude = $value;
				 if($header == "Longitude")
				  $Longitude = $value;
				 if($header == "Accuracy")
				  $Accuracy = $value;
			  }
			 $body = file_get_contents("php://input");
			 $xml = simplexml_load_string($body);
			foreach($xml->children() as $child)
			  {
			  switch($child->getName())
			        {
				   case "userId": 
						$userId = $child;
						break;
				   case "reqType": 
						$reqType = $child;
						break;
				   case "error": 
						$error = $child;
						break;
					}
			  }
            if($Latitude!='' && $Longitude!='') {   
			$upd = mysql_query("update fosmaster set Latitude='$Latitude', Longitude='$Longitude', Accuracy='$Accuracy' where UserID='$userId'"); }else{ }
        // $ins = mysql_query("Insert Into Updqry Values ('update fosmaster set Latitude=$Latitude, Longitude=$Longitude, Accuracy=$Accuracy where UserID=$userId')", $this->db);
					
			$error = array('errorCode' => "0", "errorstring" => "success");
			$this->response($this->xml($error,'status'), 200);
		}
		
//////////////////////////////////////////////////////  Log out Code ////////////////////////////////////////////////////////////////////////////////

	    private function doLogout(){	
			if($this->get_request_method() != "GET"){
				$this->response('',406);
			}
			$id = $this->_request['userId'];
			if($id!=''){				
                    $updlogin = mysql_query("update fosmaster set Latitude='',Longitude='',loginstatus=0 where UserID='$id'");
					$inslogin = mysql_query("update tbl_loginmaster set logouttime=now() where UserID='$id' and logintime is not null and logouttime is null");

					$error = array('errorCode' => "0", "errorstring" => "success");
					$this->response($this->xml($error,'status'), 200);
			}
			else
			{
			   $this->response('',204);
			}		
		}

//////////////////////////////////////////////////////////  Get Last Error //////////////////////////////////////////////////////////////

                private function lastError(){	
			    if($this->get_request_method() != "POST"){
				$this->response('',406);
			    }
			 $body = file_get_contents("php://input");
			 $xml = simplexml_load_string($body);
			foreach($xml->children() as $child)
			  {
			  switch($child->getName()){
			   case "userId": 
			   		$userId = $child;
					break;
			   case "reqType": 
			   		$reqType = $child;
					break;
			   case "error": 
			   		$error = $child;
					break;
					}
			  }
			if($error=='0'){
			   if($reqType=='taskList')
			       {
		//$ins = mysql_query("Insert Into Updqry Values ('SELECT * FROM tbl_allocate_receipt WHERE userId=$userId')", $this->db);		   
                  $upd = mysql_query("update tbl_datamaster set transfer='1' WHERE transfer IS NULL && Fosid IN (SELECT id FROM tbl_fos WHERE userId='$userId')");
 				  $del = mysql_query("delete from tbl_tasklist WHERE transfer IS NULL && Fosid IN (SELECT id FROM tbl_fos WHERE userId='$userId')");
			      $upd = mysql_query("update tbl_statusupdate set flag='1' where id=2 and User_Id='$userId'");		
				   }
				   else
				   {
			      $upd = mysql_query("update tbl_statusupdate set flag='1' where id in(1) and User_Id='$userId' and flag is null limit 1");		
				   }				
					}
					$error = array('errorCode' => "0", "errorstring" => "success");
					$this->response($this->xml($error,'status'), 200);
		}
		
                private function lastErrorP(){	
			    if($this->get_request_method() != "POST"){
				$this->response('',406);
			    }
			 $body = file_get_contents("php://input");
			 $xml = simplexml_load_string($body);
			foreach($xml->children() as $child)
			  {
			  switch($child->getName()){
			   case "userId": 
			   		$userId = $child;
					break;
			   case "reqType": 
			   		$reqType = $child;
					break;
			   case "error": 
			   		$error = $child;
					break;
					}
			  }
			if($error=='0'){
			   if($reqType=='taskList')
			       {
		//$ins = mysql_query("Insert Into Updqry Values ('SELECT * FROM tbl_allocate_receipt WHERE userId=$userId')", $this->db);		   
                  $upd = mysql_query("update tbl_datamaster set transfer='1' WHERE transfer IS NULL && Fosid IN (SELECT id FROM tbl_fos WHERE userId='$userId')");
 				  $del = mysql_query("delete from tbl_tasklist WHERE transfer IS NULL && Fosid IN (SELECT id FROM tbl_fos WHERE userId='$userId')");
			      $upd = mysql_query("update tbl_statusupdate set flag='1' where id=4 and User_Id='$userId'");		
				   }
				   else
				   {
			      $upd = mysql_query("update tbl_statusupdate set flag='1' where id in(1,2,3) and User_Id='$userId' and flag is null limit 1");		
				   }				
					}
					$error = array('errorCode' => "0", "errorstring" => "success");
					$this->response($this->xml($error,'status'), 200);
		}
		

		/*
		 * convert array into XML
		*/
		private function xml($data,$xmlstartar){
				$xml = new XmlWriter();
				$xml->openMemory();
				$xml->startDocument('1.0', 'UTF-8');
				$xml->startElement($xmlstartar);
        function write(XMLWriter $xml, $data){
        foreach($data as $key => $value){
            if (is_array($value) && isset($value[0])){
                foreach($value as $itemValue){
                    if(is_array($itemValue)){
                        $xml->startElement($key);
                        write($xml, $itemValue);
                        //$xml->endElement();
                        continue;
                    } 
                    if (!is_array($itemValue)){
                        $xml->writeElement($key, $itemValue."");
                    }
                }
            }else if(is_array($value)){
                $xml->startElement($key);
                write($xml, $value);
               // $xml->endElement();
                continue;
            } 
            if (!is_array($value)){
                $xml->writeElement($key, $value."");
            }
        }
    }

	write($xml, $data);
    $xml->endElement();
    return $xml->outputMemory(true);
  }

  public function xmltask($data, $startElement = 'tasklist', $xml_version = '1.0', $xml_encoding = 'UTF-8'){
  $xml = new XmlWriter();
  $xml->openMemory();
  
  $xml->startDocument($xml_version, $xml_encoding);
  $xml->startElement($startElement);	
  //print_r($data);
  for($i=0;$i<count($data);$i++)
  {
	$xml->startElement("task");
	foreach($data[$i] as $k=>$v)
	{
  		$xml->writeElement($k,$v);
	}
	$xml->endElement();
  }
    $xml->endElement();	
    return $xml->outputMemory(true);
  }
public function xmlui($data, $startElement = 'parameterList', $xml_version = '1.0', $xml_encoding = 'UTF-8'){
  $xml = new XmlWriter();
  $xml->openMemory();
  
  $xml->startDocument($xml_version, $xml_encoding);
  $xml->startElement($startElement);	
  for($i=0;$i<count($data);$i++)
  {
	   if($i==0) 
        {
	$xml->startElement("parameter");
	$xml->writeAttribute('condition', 1); 
	 }
	else {
	$xml->startElement("parameter"); }
	foreach($data[$i] as $k=>$v)
	{      if($v==''){ }
     	       else {
  		$xml->writeElement(substr($k, 0, -1),$v); }
	}
	$xml->endElement();
  }
  $xml->endElement();	

  return $xml->outputMemory(true); 
 }
}
	$api = new API;
	$api->processApi();
?>