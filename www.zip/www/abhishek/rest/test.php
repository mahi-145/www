<?php
 if(is_dir("../upload_file/"))
 echo "test";
 else
 echo "error";
?>