package minty.masscom.client;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import minty.masscom.client.Constants.serverUpdateType;
import minty.masscom.client.Constants.status;
import minty.masscom.client.restClient.RestClient;
import minty.masscom.client.service.updateintentservice;
import minty.masscom.client.sql.TaskDataSource;
import minty.masscom.client.xmlEntity.Case;
import minty.masscom.client.xmlEntity.LastError;
import minty.masscom.client.xmlEntity.Parameter;
import minty.masscom.client.xmlEntity.Status;
import minty.masscom.client.xmlEntity.Task;
import minty.masscom.client.xmlEntity.TaskList;
import minty.masscom.client.xmlEntity.UserLogin;

import org.apache.http.client.ClientProtocolException;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaRecorder;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.opengl.Visibility;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.Messenger;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class masscommClientActivity extends Activity 
{
	/** Last Error **/
	public LastError mLastError = null;

	/** Common memebers Begin **/
	public static final String TAG = "masscommClientActivity";
	private String workingDir = 
		Environment.getExternalStorageDirectory().toString() + Constants.filename.workingDir;
	//private RestClient m_restClient = null;
	private masscommClientActivity activity = null;
	private String currentMenu = "Login";
	private GpsLocator mGpsLocator;

	private GpsLocator mGpsLocator1;
	private Task GpsTask = new Task();
	
	public enum Request
	{
		LOGIN,TASKLIST_UPDATE,UI_INS,UI_SME,UI_COSP,LOGOUT,ERROR,NO_UPDATE
	}

	private TaskManager mtaskMgr = null; 
	DynamicUIxml mdyxmlObj;

	private Request request;
	private TaskDataSource taskSource;
	private Messenger m_messenger = null; 

	/** Common memebers End*/

	/*** Login Page Begin **/
	private EditText m_UNameText = null; 
	private EditText m_UPassword = null;
	private ImageButton m_loginButton = null;
	private ProgressBar m_progressBar = null;
	/** Long Page End ***/

	/***** Post Login Page Begin **/
	ListViewAdapter adapter = null;
	private ListView m_ListView = null;
	/***** Post Login Page End **/

	/**** Information Page Begin *****/
	private ImageButton m_prevButton = null;
	private TextView m_CaseStatus = null;
	private TextView m_StateText = null;
	private ImageButton m_nextButton = null;
	private FrameLayout m_InfoFrameLayout = null;
	private int mcurrentpage = -1;

	/*** begin personal info page ***/
	private EditText 	m_name;
	private EditText 	m_phone;
	private EditText	m_Altphone;
	private EditText 	m_address;
	private EditText	m_pincode;
	private EditText	m_simNumber;
	private EditText	m_billCycle;
	private EditText	m_billAddType;
	private EditText	m_dob;
	private EditText	m_dealerComment;
	private EditText	m_parentName;
	private EditText	m_addProofType;
	private EditText	m_addProofValue;
	private EditText	m_idProofType;
	private EditText	m_idProofValue;
	private EditText	m_scheme;
	private EditText	m_tariffPlan;
	private EditText	m_multiMobiles;
	private EditText	m_multiRejectMobiles;
	private customSpinner 	m_Reject_Reason_Spinner;
	private CheckBox 	m_addressCheck;
	private LinearLayout m_addressChangeLayout;
	private RadioButton m_minorAddressType;
	private RadioButton m_majorAddressType;
	private EditText 	m_modifiedAddress;
	private CheckBox 	m_commercialCheck;
	private EditText 	m_personmet_name;
	private customSpinner 	m_relationship_Spinner;

	private EditText 	m_activation_Type;
	private EditText 	m_pre_Pv;
	private EditText 	m_comp_Name;
	private EditText 	m_cust_Class;
	private EditText 	m_gender;
	private EditText 	m_alt_Address;
	private EditText 	m_alt_Add_Phone;
	private EditText 	m_new_EmailId;

	private customSpinner 	m_maritalStatus_Spinner;
	private customSpinner 	m_simDelivery_Spinner;
	private customSpinner 	m_planConfirmation_Spinner;
	private customSpinner 	m_firstBillSample_Spinner;
	private customSpinner 	m_paymentOptions_Spinner;
	
	/*** end personal info page ***/
	
	/*** begin personal info additional items ***/
	private LinearLayout m_caseEntryTypeLayout;
	private EditText m_Visit_Date;
	private EditText m_company_name;
	private EditText m_income;
	private EditText m_house_colour;
	private EditText m_gate_colour;
	private EditText m_sd_confirmation;
	private EditText m_new_alt_number;
	private EditText m_landmark;
	private EditText m_ntp_ecs;
	private EditText m_neighbour_check_name_or_plot;
	private EditText m_poa_poi_seen;
	private customSpinner m_entry_allowed_spinner;
	private EditText m_no_of_connections;
	private customSpinner m_office_setup_spinner;
	private EditText m_nature_of_business;
	private customSpinner m_business_activity_spinner;
	private customSpinner m_neighbour_check_spinner;
	private EditText m_website;
	private EditText m_designation;
	private EditText m_job_stability;
	private EditText m_visiting_card;
	private EditText m_official_mailid;
	private EditText m_official_altno;
	private EditText m_official_landmark;
	
	/*** end personal info additional items ***/
	
	/**** Question List Page Begin *****/
	private ListView m_QuestionListView = null;
	private ParamListViewAdapter m_QuestionListAdapter = null;
	/**** Question List Page End *****/
	/*** begin documents page ***/
	private ImageView m_document1;
	private ImageButton m_document1ShootButton;
	private ImageView m_document2;
	private ImageButton m_document2ShootButton;
	private CheckBox m_LandMarkCheck;
	private ImageView m_LandMark;
	private ImageButton m_LandMarkShootButton;
	private LinearLayout m_LandMarkLayout;
	private PhotoSurface m_photoSurface = null;

	/*** end documents page ***/
	/*** begin signature page ***/
	private TextView m_UserSignDeclaration;
	private ImageView m_UserSignPreview;
	private ImageButton m_UsertakeSignButton;
	private FingerPaint m_fingerPaintView;
	//private EditText 	m_newcustomerremarks;
	/*** end signature page ****/
	/*** begin remarks page ***/
	private customSpinner 	m_feebackSpinner;
	private EditText 	m_customerremarks;
	/*** end remarks page ***/	
	private class FilePath
	{
		public String m_currentImagePath = null;
	}
	private FilePath currImagefilePath =  new FilePath();
	/**** Information Page End *******/

	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		try
		{
			super.onCreate(savedInstanceState);
			mtaskMgr = TaskManager.getTaskManagerObject();
			mdyxmlObj = DynamicUIxml.getDynamicUIxmlObject();
			File file = new File(workingDir);
			if(file.exists() == false)
			{	
				boolean Ret = file.mkdir();
				if(Ret == false)//already exist
				{
					workingDir = Environment.getExternalStorageDirectory().toString();
				}
			}
			mtaskMgr.setWorkingDir(workingDir);
			mdyxmlObj.setWorkingDir(workingDir);
			activity = this;
			taskSource = initializeTaskDataSource();
			SharedApplication sharedApp = (SharedApplication)getApplication();
			sharedApp.setSqlDataSource(taskSource);
			sharedApp.setTaskManager(mtaskMgr);
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in onCreate : "+ ex.getMessage());
		}
	}

	public TaskDataSource initializeTaskDataSource()
	{
		try
		{
			if(mtaskMgr.mtaskSource == null)
			{
				mtaskMgr.mtaskSource = new TaskDataSource(this);
				mtaskMgr.mtaskSource.open();
			}
			return mtaskMgr.mtaskSource;
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in initializeTaskDataSource : "+ ex.getMessage());
			return mtaskMgr.mtaskSource;
		}
	}

	@Override
	public void onResume()
	{
		try
		{
			super.onResume();
			SharedPreferences sharedPreferences = getSharedPreferences("masscom", Context.MODE_PRIVATE);
			String loginState = sharedPreferences.getString("Login", "0");
			if(loginState.compareTo("1") == 0)
			{
				if(mtaskMgr.mUserId == null)
					mtaskMgr.mUserId = sharedPreferences.getString("USERID", "");
				restorelastPage();
				//switchPage(1);
				startBackgroundService();
			}
			else
				switchPage(0);
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in onResume : "+ ex.getMessage());
		}
	}

	@Override
	public void onPause()
	{
		try{
			if(m_photoSurface != null)
				m_photoSurface.onCloseCamera();

			if(mtaskMgr.currentScreen.compareTo(Constants.Screen.Personal) ==0
					||mtaskMgr.currentScreen.compareTo(Constants.Screen.Question) == 0
					||mtaskMgr.currentScreen.compareTo(Constants.Screen.Photo) == 0
					|| mtaskMgr.currentScreen.compareTo(Constants.Screen.Signature) == 0)
			{
				savePreviousInfoPage(mcurrentpage,true); 
			}
			if(mtaskMgr.currentScreen.compareTo(Constants.Screen.Remarks) == 0)
			{
				saveRemarks_page();
			}
			super.onPause();
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in onPause : "+ ex.getMessage());
		}
	}
	public boolean isNetworkAvailable() 
	{
		try
		{
			ConnectivityManager cm = (ConnectivityManager) 
			getSystemService(Context.CONNECTIVITY_SERVICE);
			NetworkInfo networkInfo = cm.getActiveNetworkInfo();
			if (networkInfo != null && networkInfo.isConnected()) {
				return true;
			}
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in isNetworkAvailable : "+ ex.getMessage());
		}
		return false;
	}

	private void restorelastPage()
	{
		try{
			if(mtaskMgr.currentScreen.compareTo(Constants.Screen.MainScreen) == 0 
					|| mtaskMgr.currentScreen.compareTo(Constants.Screen.LoginScreen) == 0)
			{
				switchPage(1);
			}
			else if(mtaskMgr.currentScreen.compareTo(Constants.Screen.Personal) ==0)
			{
				setContentView(R.layout.framelayout);
				InitializeInfoPage(0);
			}
			else if(mtaskMgr.currentScreen.compareTo(Constants.Screen.Signature) == 0)
			{
				setContentView(R.layout.framelayout);
				InitializeInfoPage(1);
			}
			else if(mtaskMgr.currentScreen.compareTo(Constants.Screen.Photo) == 0)
			{
				setContentView(R.layout.framelayout);
				InitializeInfoPage(2);
			}
			else if(mtaskMgr.currentScreen.compareTo(Constants.Screen.Question) == 0)
			{
				setContentView(R.layout.framelayout);
				InitializeInfoPage(3);
			}
			else if(mtaskMgr.currentScreen.compareTo(Constants.Screen.Remarks) == 0)
			{
				setContentView(R.layout.framelayout);
				InitializeInfoPage(4);
			}
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in restorelastPage : "+ ex.getMessage());
		}

	}
	private void switchPage(int index)
	{
		try{
			switch(index)
			{
			case 0: //Login Page
				setContentView(R.layout.main);
				InitializeLoginPageControls();
				currentMenu =Constants.Screen.LoginScreen;
				break;
			case 1://post login page
				setContentView(R.layout.main_list);
				InitializePostLoginPageControls();
				currentMenu =Constants.Screen.MainScreen;
				break;
			case 2://general Info page
				setContentView(R.layout.framelayout);
				InitializeInfoPage(0);
				break;
			case 3://general Info page -> Camera page directly
				setContentView(R.layout.framelayout);
				InitializeInfoPage(2);
				break;
			case 4://general Info page -> Remarks page directly
				setContentView(R.layout.framelayout);
				InitializeInfoPage(4);
				break;
			}
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in switchPage : "+ ex.getMessage());
		}
	}

	private void InitializeLoginPageControls()
	{
		try{
			mtaskMgr.currentScreen = Constants.Screen.LoginScreen;
			m_UNameText  	= (EditText)findViewById(R.id.ID_UID_TEXT);
			m_UPassword 	= (EditText)findViewById(R.id.ID_PWD_TEXT);
			m_loginButton 	= (ImageButton)findViewById(R.id.ID_LOGIN_BUTTON);
			m_progressBar   = (ProgressBar)findViewById(R.id.ID_PROGRESS_BAR);
			m_loginButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) 
				{
					if(m_UNameText.getText().toString().length() > 0 && m_UPassword.getText().toString().length() > 0)
					{
						mtaskMgr.mUserId = m_UNameText.getText().toString();
						m_progressBar.setVisibility(ProgressBar.VISIBLE);
						TelephonyManager telephonyManager = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
						String IMEINumber = telephonyManager.getDeviceId();
						String SimNumber = telephonyManager.getSimSerialNumber() ;
						if(isNetworkAvailable() == true)
						{
							String loginUri = Constants.URI.ServerURL + Constants.URI.login;
							RestClient restClient = new RestClient(loginUri);
							restClient.addHeader("Accept", "application/xml");
							restClient.addHeader("Content-type", "application/xml");
							UserLogin ulogin = new UserLogin();
							ulogin.setuserId(m_UNameText.getText().toString());
							ulogin.setpassword(m_UPassword.getText().toString());
							IMEINumber = IMEINumber == null ? "" : IMEINumber;
							ulogin.setdeviceId(IMEINumber);
							SimNumber = SimNumber == null ? "" : SimNumber;
							ulogin.setSimId(SimNumber);
							mtaskMgr.mUserId = m_UNameText.getText().toString();
							String xString = ulogin.Marshall();
							restClient.setEntityString(xString);
							AsyncExecute asyn = new AsyncExecute(activity,request.LOGIN,RestClient.POST,restClient);
							asyn.execute("","");
							m_loginButton.setClickable(false);
						}
						else
						{
							Toast.makeText(activity, "Network is not available", Toast.LENGTH_LONG).show();
						}

					}

				}
			});
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in InitializeLoginPageControls : "+ ex.getMessage());
		}
	}

	public boolean onTaskStateSelected(int ItemIndex) 
	{
		/*
		 *<item >Available</item>
        <item >Not Available</item>
        <item >Re-Scheduled</item>
        <item >Hold</item>
		 */
		try
		{
			switch(ItemIndex)
			{
			case 0://Available
				mtaskMgr.m_selectedTask.setstate(Constants.TaskState.POSITIVE);
				//initialize question list on status
				ArrayList<Parameter> paramList = mdyxmlObj.getParameterList(mtaskMgr.m_selectedTask.getcaseCategory());
				QuesAndAnswerList quesListObj = new QuesAndAnswerList();
				mtaskMgr.m_QuestionList = quesListObj.fillAdapter(paramList);
				
				switchPage(2);
				break;
			case 1://Not Available
				mtaskMgr.m_selectedTask.setstate(Constants.TaskState.NEGATIVE);
				switchPage(3);
				break;
			case 2://Re-Schedule
				mtaskMgr.m_selectedTask.setstate(Constants.TaskState.RESCHEDULED);
				switchPage(4);
				break;
			case 3://Hold
				mtaskMgr.m_selectedTask.setstate(Constants.TaskState.HOLD);
				switchPage(3);
				break;
			}
			return true;
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in onTaskStateSelected : "+ ex.getMessage());
		}
		return false;
	}

	@Override
	public boolean onPrepareOptionsMenu(Menu menu) 
	{
		try{
			menu.clear();
			String menuString[] = {};
			int menuId[] = {};
			int menuResource[] = {0,0};
			if(currentMenu.compareTo(Constants.Screen.MainScreen) == 0)
			{
				menuString = getResources().getStringArray(R.array.ID_MAINMENU_STRING_OPTION);
				menuId = getResources().getIntArray(R.array.ID_MAINMENU_INDEX_OPTION);
				menuResource[0] = R.drawable.ic_logout;
			}
			else if(currentMenu.compareTo(Constants.Screen.Signature) == 0)
			{
				menuString = getResources().getStringArray(R.array.ID_SIGNMENU_STRING_OPTION);
				menuId = getResources().getIntArray(R.array.ID_SIGNMENU_INDEX_OPTION);
				menuResource[0] = R.drawable.ic_menu_save;
				menuResource[1] = R.drawable.ic_menu_delete;
			}
			else if(currentMenu.compareTo(Constants.Screen.Photo) == 0)
			{
				menuString = getResources().getStringArray(R.array.ID_PHOTOMENU_STRING_OPTION);
				menuId = getResources().getIntArray(R.array.ID_PHOTOMENU_INTEGER_OPTION);
				menuResource[0] = R.drawable.ic_camera;
				menuResource[1] = R.drawable.ic_back;
			}
			else if(currentMenu.compareTo(Constants.Screen.Remarks) == 0)
			{
				menuString = getResources().getStringArray(R.array.ID_REMARKSMENU_STRING_OPTION);
				menuId = getResources().getIntArray(R.array.ID_REMARKSMENU_INDEX_OPTION);
				menuResource[0] = R.drawable.ic_upload;
			}
			for(int i = 0; i < menuString.length; i++)
			{
				MenuItem item = menu.add(Menu.NONE,menuId[i],i,menuString[i]);
				item.setIcon(menuResource[i]);
			}
			super.onPrepareOptionsMenu(menu);
			return true;
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in onPrepareOptionsMenu : "+ ex.getMessage());
			return false;
		}
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		try{
			if(item.getItemId() == getResources().getIntArray(R.array.ID_MAINMENU_INDEX_OPTION)[0])
			{
				doLogout();
			}
			else if(item.getItemId() == getResources().getIntArray(R.array.ID_SIGNMENU_INDEX_OPTION)[0])
			{
				saveSignImage();
			}
			else if(item.getItemId() == getResources().getIntArray(R.array.ID_SIGNMENU_INDEX_OPTION)[1])
			{
				clearSignScreen();
			}
			else if(item.getItemId() == getResources().getIntArray(R.array.ID_PHOTOMENU_INTEGER_OPTION)[0])
			{
				capturePhoto();
			}
			else if(item.getItemId() == getResources().getIntArray(R.array.ID_PHOTOMENU_INTEGER_OPTION)[1])
			{
				closeCamera();
			}
			else if(item.getItemId() == getResources().getIntArray(R.array.ID_REMARKSMENU_INDEX_OPTION)[0])
			{
				SubmitTask();
			}
			else
			{
				super.onOptionsItemSelected(item);
			}
			return true;
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in onPrepareOptionsMenu : "+ ex.getMessage());
			return false;
		}
	}

	private void doLogout()
	{
		try{
			if(mtaskMgr.LogoutEventFired == true)
				return;
			mtaskMgr.LogoutEventFired = true;
			String loginUri = Constants.URI.ServerURL + Constants.URI.logout;
			RestClient restClient = new RestClient(loginUri);
			restClient.addHeader("Accept", "application/xml");
			restClient.addParam("userId",mtaskMgr.mUserId);
			AsyncExecute asyn = new AsyncExecute(activity,request.LOGOUT,RestClient.GET,restClient);;
			asyn.execute("","");
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in doLogout : "+ ex.getMessage());
		}
	}

	private void InitializePostLoginPageControls()
	{
		try{
			mtaskMgr.currentScreen = Constants.Screen.MainScreen;
			m_CaseStatus = (TextView)findViewById(R.id.ID_TEXT_CASE_STATUS);
			m_ListView	   = (ListView)findViewById(R.id.ID_LISTVIEW_XML);
			ArrayList<Case> values = taskSource.getAllTask();
			mtaskMgr.UpdatefromCaseOnCreate(values);
			ArrayList<Task> tasklist = mtaskMgr.getTaskList();
			adapter = new ListViewAdapter(this, tasklist);
			m_ListView.setAdapter(adapter);
			m_CaseStatus.setText("Pending(" + taskSource.getPendingCount() + ") Hold(" + taskSource.getHoldCount() + ")");
			m_ListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() 
			{
				@Override
				public boolean onItemLongClick(AdapterView<?> adapterView, View view,int arg2, long arg3) 
				{
					mtaskMgr.m_selectedTask = adapter.getItem(arg2);
					String title = getResources().getString(R.string.ID_CHOOSE_PHONENUMBER);
					String[] phoneArray = new String[2];
					phoneArray[0] = mtaskMgr.m_selectedTask.getphone();
					phoneArray[1] = mtaskMgr.m_selectedTask.getAltphone();
					MenuDialog dlg = new MenuDialog(activity);
					dlg.setHeading(title);
					dlg.setListOptions(phoneArray);
					dlg.initDialog( new minty.masscom.client.OnItemSelectedListener()
					{
						@Override
						public void onItemSelected(int selectedItem,int id) 
						{
							RecordingManager recordManager = RecordingManager.getRecordManagerObject();
							String phoneNumber = selectedItem == 0 ? mtaskMgr.m_selectedTask.getphone() : mtaskMgr.m_selectedTask.getAltphone();
							String fileName = phoneNumber +"_"+ mtaskMgr.m_selectedTask.getId()+".3gp";
							recordManager.setOutputfileName(fileName);
							recordManager.SetRecordingStatus(true);
							mtaskMgr.m_selectedTask.setAudiofile(fileName);
							mtaskMgr.setTasktoFile(mtaskMgr.m_selectedTask);
							try
							{
								Intent call = new Intent(Intent.ACTION_CALL);
								call.setData(Uri.parse("tel:" + phoneNumber));
								startActivity(call);
							}
							catch(ActivityNotFoundException ex)
							{
								Log.e(TAG,ex.getMessage());
							}
						}

					});
					dlg.show();
					return true;
				}
			});
			m_ListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				public void onItemClick(AdapterView<?> adapterView, View view,int arg2, long arg3)
				{	
					mtaskMgr.m_selectedTask = adapter.getItem(arg2);
					boolean fileExist = mtaskMgr.m_selectedTask.getAudiofile().length() > 0;
					if(fileExist == true)
					{
						String fileName = workingDir + "/"+ mtaskMgr.m_selectedTask.getAudiofile();
						File file = new File(fileName);
						fileExist = file.exists() == true;
					}

					if(fileExist == false)
					{
						Toast.makeText(activity, "talk to customer.Long touch to select phone number.", Toast.LENGTH_LONG).show();
					}
					String title = getResources().getString(R.string.ID_SELECT);
					String[] strArray = getResources().getStringArray(R.array.ID_SELECT_OPTION);
					MenuDialog dlg = new MenuDialog(activity);
					dlg.setHeading(title);
					dlg.setListOptions(strArray);
					dlg.initDialog( new minty.masscom.client.OnItemSelectedListener()
					{
						@Override
						public void onItemSelected(int selectedItem,int id) 
						{
							onTaskStateSelected(selectedItem);
						}

					});
					dlg.show();
				}
			});
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in InitializePostLoginPageControls "+ ex.getMessage());
		}
	}

	private void InitializeInfoPage(int index)
	{
		try{
			m_prevButton = (ImageButton)findViewById(R.id.ID_INFOPREV_BUTTON);
			m_StateText = (TextView)findViewById(R.id.ID_TEXT_STATE);
			m_nextButton = (ImageButton)findViewById(R.id.ID_INFO_NEXTBUTTON);
			m_InfoFrameLayout = (FrameLayout)findViewById(R.id.ID_FRAME_LAYOUT);
			m_StateText.setText(mtaskMgr.m_selectedTask.getstate());
			switchInfoViewPage(index);
			m_nextButton.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) 
				{
					if(savePreviousInfoPage(mcurrentpage,false) == -1)
					{
						return;
					}
					if(mtaskMgr.m_selectedTask.getstate().compareTo(Constants.TaskState.POSITIVE) == 0)
					{
						int nextpage = 0;
						if(mcurrentpage == 2)
						{
							if(mtaskMgr.m_selectedTask.getcaseCategory().compareTo("C") == 0)
							{
								nextpage = mcurrentpage + 2;
								switchInfoViewPage(nextpage);
							}
							else
							{
								nextpage = mcurrentpage + 1;
								switchInfoViewPage(nextpage);
							}
						}
						else
						{
							nextpage = mcurrentpage + 1;
							switchInfoViewPage(nextpage);
						}
					}
					else if((mtaskMgr.m_selectedTask.getstate().compareTo(Constants.TaskState.NEGATIVE) == 0
							|| mtaskMgr.m_selectedTask.getstate().compareTo(Constants.TaskState.HOLD) == 0) && mcurrentpage == 2)
					{
						int nextpage = mcurrentpage + 2;
						switchInfoViewPage(nextpage);
					}
				}
			});
			m_prevButton.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) 
				{
					if(mtaskMgr.m_selectedTask.getstate().compareTo(Constants.TaskState.POSITIVE) == 0)
					{
						int prevpage = 0;
						if(mcurrentpage == 4)
						{
							if(mtaskMgr.m_selectedTask.getcaseCategory().compareTo("C") == 0)
							{
								prevpage = mcurrentpage - 2;
								switchInfoViewPage(prevpage);
							}
							else
							{
								prevpage = mcurrentpage - 1;
								switchInfoViewPage(prevpage);
							}
						}
						else
						{
							prevpage = mcurrentpage - 1;
							switchInfoViewPage(prevpage);
						}
					}
					else if((mtaskMgr.m_selectedTask.getstate().compareTo(Constants.TaskState.NEGATIVE) == 0
							|| mtaskMgr.m_selectedTask.getstate().compareTo(Constants.TaskState.HOLD) == 0) && mcurrentpage == 4)
					{
						int prevpage = mcurrentpage - 2;
						switchInfoViewPage(prevpage);
					}
					else//in any other case directly move to task list 
					{
						switchPage(1);
					}
				}
			});
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in InitializeInfoPage "+ ex.getMessage());
		}
	}

	private int savePreviousInfoPage(int pageId,boolean forceSave)
	{
		try
		{
			switch(pageId)
			{
			case 0://genral info page
				if(IsInfoPage_OptionsCompleted() == 0 || forceSave == true)
				{
					setValues_InfoPageControls_to_task();
					return 0;
				}
				else
				{
					return -1;
				}
			case 1:
				return isSignPageComplete();
			case 2:
				return isPhotoPageComplete();
			case 3:
				if(isQuestionPageComplete() == 0 || forceSave == true)
				{
					saveQuesAnsList();
					return 0;
				}
				else
				{
					return -1;
				}
			case 4:
				break;
			}

			return 0;
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in savePreviousInfoPage "+ ex.getMessage());
			return -1;
		}
	}
	private void switchInfoViewPage(int pageId)
	{
		try
		{
			switch(pageId)
			{
			case -1:
				m_InfoFrameLayout.removeAllViews();
				switchPage(1);
				mcurrentpage = -1;
				break;
			case 0://infopage
			{
				m_InfoFrameLayout.removeAllViews();
				LayoutInflater inflater = activity.getLayoutInflater();
				LinearLayout personalInfoView = (LinearLayout)inflater.inflate(R.layout.personal, null);
				m_InfoFrameLayout.addView(personalInfoView);
				initializePersonalInfoPage();
				mcurrentpage = 0;
				currentMenu = Constants.Screen.MainScreen;
			}
			break;
			case 1: //signature page
			{
				currentMenu = Constants.Screen.MainScreen;
				m_InfoFrameLayout.removeAllViews();
				LayoutInflater inflater = activity.getLayoutInflater();
				LinearLayout signatureView = (LinearLayout)inflater.inflate(R.layout.signature, null);
				m_InfoFrameLayout.addView(signatureView);
				initializeSignature();
				mcurrentpage = 1;
			}
			break;
			case 2://camera
			{
				currentMenu = Constants.Screen.MainScreen;
				m_InfoFrameLayout.removeAllViews();
				LayoutInflater inflater = activity.getLayoutInflater();
				LinearLayout documentsView = (LinearLayout)inflater.inflate(R.layout.documents, null);
				m_InfoFrameLayout.addView(documentsView);
				InitializeCameraShoot();
				mcurrentpage = 2;
			}
			break;
			case 3://question page
			{
				currentMenu = Constants.Screen.MainScreen;
				m_InfoFrameLayout.removeAllViews();
				LayoutInflater inflater = activity.getLayoutInflater();
				LinearLayout generalQuestionView = (LinearLayout)inflater.inflate(R.layout.generalquestions, null);
				m_InfoFrameLayout.addView(generalQuestionView);
				initializeQuestionPage();
				mcurrentpage = 3;
			}
			break;
			case 4:
			{
				currentMenu = Constants.Screen.Remarks;
				m_InfoFrameLayout.removeAllViews();
				LayoutInflater inflater = activity.getLayoutInflater();
				LinearLayout remarks = (LinearLayout)inflater.inflate(R.layout.remark, null);
				m_InfoFrameLayout.addView(remarks);
				InitializeRemarks();
				mcurrentpage = 4;
			}
			}
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in switchInfoViewPage "+ ex.getMessage());
		}
	}

	private void initializePersonalInfoPage()
	{
		try
		{
			mtaskMgr.currentScreen = Constants.Screen.Personal;
			m_name = 					(EditText)findViewById(R.id.ID_PINFO_NAME);
			m_phone = 					(EditText)findViewById(R.id.ID_PINFO_PHONE);
			m_Altphone=					(EditText)findViewById(R.id.ID_ALT_PHONE);
			m_address = 				(EditText)findViewById(R.id.ID_PINFO_ADDRESS);
			m_pincode = 				(EditText)findViewById(R.id.ID_PINFO_PINCODE); 
			m_simNumber = 				(EditText)findViewById(R.id.ID_PSIM_NUMBER); 
			m_billCycle = 				(EditText)findViewById(R.id.ID_PBILL_CYCLE); 
			m_billAddType = 			(EditText)findViewById(R.id.ID_PBILL_ADD_TYPE); 
			m_dob = 					(EditText)findViewById(R.id.ID_PDOB); 
			m_dealerComment = 			(EditText)findViewById(R.id.ID_PDEALER_COMMENT); 
			m_parentName = 				(EditText)findViewById(R.id.ID_PPARENT_NAME); 
			m_addProofType = 			(EditText)findViewById(R.id.ID_PADD_PROOF_TYPE); 
			m_addProofValue = 			(EditText)findViewById(R.id.ID_PADD_PROOF_VALUE); 
			m_idProofType = 			(EditText)findViewById(R.id.ID_PID_PROOF_TYPE); 
			m_idProofValue = 			(EditText)findViewById(R.id.ID_PID_PROOF_VALUE); 
			m_scheme = 					(EditText)findViewById(R.id.ID_PSCHEME); 
			m_tariffPlan = 				(EditText)findViewById(R.id.ID_PTARIFF_PLAN); 
			m_activation_Type = 		(EditText)findViewById(R.id.ID_PACT_TYPE); 
			m_pre_Pv = 					(EditText)findViewById(R.id.ID_PPRE_PV); 
			m_comp_Name = 				(EditText)findViewById(R.id.ID_PCOMP_NAME); 
			m_cust_Class = 				(EditText)findViewById(R.id.ID_PCUST_CLASS); 
			m_gender = 					(EditText)findViewById(R.id.ID_PGENDER); 
			m_alt_Address = 			(EditText)findViewById(R.id.ID_PALT_ADDRESS); 
			m_alt_Add_Phone = 			(EditText)findViewById(R.id.ID_PALT_ADD_PHONE); 
			m_multiMobiles = 			(EditText)findViewById(R.id.ID_PINFO_MULTI_MOBILES); 
			m_multiRejectMobiles = 		(EditText)findViewById(R.id.ID_PINFO_MULTI_REJECT); 
			m_Reject_Reason_Spinner =	(customSpinner) findViewById(R.id.ID_MULTI_REJECT_REASON_SPINNER);
			String[] RejectionOptions = getResources().getStringArray(R.array.ID_MULTI_REJECT_REASON_ARRAY);
			m_Reject_Reason_Spinner.setOptions(RejectionOptions);
			String prompt = getResources().getString(R.string.ID_SELECT);
			m_Reject_Reason_Spinner.setPrompt(prompt);
			m_Reject_Reason_Spinner.setOnClickListener();
			//Toast.makeText(activity, "Before Address Check ", Toast.LENGTH_LONG).show();
			m_addressCheck = 			(CheckBox)findViewById(R.id.ID_ADDRESS_CHANGE_CHECKBOX);
			m_addressChangeLayout = 	(LinearLayout)findViewById(R.id.ID_ADDCHANGE_LAYOUT);
			m_minorAddressType		=  (RadioButton)findViewById(R.id.ID_MINOR_ADDCHANGE);
			m_majorAddressType		=  (RadioButton)findViewById(R.id.ID_MAJORADD_CHANGE);
			m_modifiedAddress		=  (EditText)findViewById(R.id.ID_NEWCHANGED_ADDRESS);
			m_commercialCheck = 		(CheckBox)findViewById(R.id.ID_COMMERCIAL_CONNECTION);
			m_personmet_name= 			(EditText)findViewById(R.id.ID_PPERSONMET_NAME);
			m_relationship_Spinner =	(customSpinner) findViewById(R.id.ID_RELATIONSHIP_SPINNER);
			String[] RelationOptions = getResources().getStringArray(R.array.ID_CUSTOMER_RELATIONSHIP);
			m_relationship_Spinner.setOptions(RelationOptions);
			prompt = getResources().getString(R.string.ID_SELECT);
			m_relationship_Spinner.setPrompt(prompt);
			m_relationship_Spinner.setOnClickListener();
			m_new_EmailId = 				(EditText)findViewById(R.id.ID_PNEW_EMAILID);

			m_maritalStatus_Spinner =	(customSpinner) findViewById(R.id.ID_MARITAL_STATUS_SPINNER);
			String[] sOptions = getResources().getStringArray(R.array.ID_MARITAL_STATUS_ARRAY);
			m_maritalStatus_Spinner.setOptions(sOptions);
			prompt = getResources().getString(R.string.ID_SELECT);
			m_maritalStatus_Spinner.setPrompt(prompt);
			m_maritalStatus_Spinner.setOnClickListener();
			m_simDelivery_Spinner =	(customSpinner) findViewById(R.id.ID_SIM_DELIVERY_SPINNER);
			sOptions = getResources().getStringArray(R.array.ID_SIM_DELIVERY_ARRAY);
			m_simDelivery_Spinner.setOptions(sOptions);
			prompt = getResources().getString(R.string.ID_SELECT);
			m_simDelivery_Spinner.setPrompt(prompt);
			m_simDelivery_Spinner.setOnClickListener();
			m_planConfirmation_Spinner =	(customSpinner) findViewById(R.id.ID_PLAN_CONFIRMATION_SPINNER);
			sOptions = getResources().getStringArray(R.array.ID_PLAN_CONFIRMATION_ARRAY);
			m_planConfirmation_Spinner.setOptions(sOptions);
			prompt = getResources().getString(R.string.ID_SELECT);
			m_planConfirmation_Spinner.setPrompt(prompt);
			m_planConfirmation_Spinner.setOnClickListener();
			m_firstBillSample_Spinner =	(customSpinner) findViewById(R.id.ID_FIRST_BILL_SAMPLE_SPINNER);
			sOptions = getResources().getStringArray(R.array.ID_FIRST_BILL_SAMPLE_ARRAY);
			m_firstBillSample_Spinner.setOptions(sOptions);
			prompt = getResources().getString(R.string.ID_SELECT);
			m_firstBillSample_Spinner.setPrompt(prompt);
			m_firstBillSample_Spinner.setOnClickListener();
			m_paymentOptions_Spinner =	(customSpinner) findViewById(R.id.ID_PAYMENT_OPTIONS_SPINNER);
			sOptions = getResources().getStringArray(R.array.ID_PAYMENT_OPTIONS_ARRAY);
			m_paymentOptions_Spinner.setOptions(sOptions);
			prompt = getResources().getString(R.string.ID_SELECT);
			m_paymentOptions_Spinner.setPrompt(prompt);
			m_paymentOptions_Spinner.setOnClickListener();

			
			if(mtaskMgr.m_selectedTask.getcaseEntryType().equals("Ind"))
			{
				m_caseEntryTypeLayout = (LinearLayout)findViewById(R.id.layoutIndividual);
				
				m_Visit_Date = (EditText)findViewById(R.id.ID_PVISIT_DATE_IND);
				m_company_name = (EditText)findViewById(R.id.ID_PCOMPANY_NAME_IND);
				m_income = (EditText)findViewById(R.id.ID_PINCOME_IND);
				m_house_colour = (EditText)findViewById(R.id.ID_PHOUSE_COLOUR_IND);
				m_gate_colour = (EditText)findViewById(R.id.ID_PGATE_COLOUR_IND);
				m_sd_confirmation = (EditText)findViewById(R.id.ID_PSD_CONFIRMATION_IND);
				m_new_alt_number = (EditText)findViewById(R.id.ID_PNEW_ALT_NUMBER_IND);
				m_landmark = (EditText)findViewById(R.id.ID_PLANDMARK_IND);
				m_ntp_ecs = (EditText)findViewById(R.id.ID_PNTP_ECS_IND);
				m_neighbour_check_name_or_plot = (EditText)findViewById(R.id.ID_PNEIGHBOUR_CHECK_OR_PLOTNO_IND);
				m_poa_poi_seen = (EditText)findViewById(R.id.ID_PPOA_POI_SEEN_IND);
			}
			else if(mtaskMgr.m_selectedTask.getcaseEntryType().equals("Cocp"))
			{
				m_caseEntryTypeLayout = (LinearLayout)findViewById(R.id.layoutCOCP);
				
				m_Visit_Date = (EditText)findViewById(R.id.ID_PVISIT_DATE_COCP);
				m_entry_allowed_spinner = (customSpinner)findViewById(R.id.ID_ENTRY_ALLOWED_SPINNER_COCP);
				sOptions = getResources().getStringArray(R.array.ID_ENTRY_ALLOWED_ARRAY);
				m_entry_allowed_spinner.setOptions(sOptions);
				prompt = getResources().getString(R.string.ID_SELECT);
				m_entry_allowed_spinner.setPrompt(prompt);
				m_entry_allowed_spinner.setOnClickListener();

				m_no_of_connections = (EditText)findViewById(R.id.ID_PNO_OF_CONNECTIONS_COCP);
				m_office_setup_spinner = (customSpinner)findViewById(R.id.ID_OFFICE_SETUP_SPINNER_COCP);
				sOptions = getResources().getStringArray(R.array.ID_OFFICE_SETUP_ARRAY);
				m_office_setup_spinner.setOptions(sOptions);
				prompt = getResources().getString(R.string.ID_SELECT);
				m_office_setup_spinner.setPrompt(prompt);
				m_office_setup_spinner.setOnClickListener();
				
				m_nature_of_business = (EditText)findViewById(R.id.ID_PNATURE_OF_BUSINESS_COCP);
				m_business_activity_spinner = (customSpinner)findViewById(R.id.ID_BUSINESS_ACTIVITY_SPINNER_COCP);
				sOptions = getResources().getStringArray(R.array.ID_BUSINESS_ACTIVITY_ARRAY);
				m_business_activity_spinner.setOptions(sOptions);
				prompt = getResources().getString(R.string.ID_SELECT);
				m_business_activity_spinner.setPrompt(prompt);
				m_business_activity_spinner.setOnClickListener();
				
				m_neighbour_check_spinner = (customSpinner)findViewById(R.id.ID_NEIGHBOUR_CHECK_SPINNER_COCP);
				sOptions = getResources().getStringArray(R.array.ID_NEIGHBOUR_CHECK_ARRAY);
				m_neighbour_check_spinner.setOptions(sOptions);
				prompt = getResources().getString(R.string.ID_SELECT);
				m_neighbour_check_spinner.setPrompt(prompt);
				m_neighbour_check_spinner.setOnClickListener();
				
				m_neighbour_check_name_or_plot = (EditText)findViewById(R.id.ID_PNEIGHBOUR_CHECK_OR_PLOTNO_COCP);
				m_website = (EditText)findViewById(R.id.ID_PWEBSITE_COCP);
				m_new_alt_number = (EditText)findViewById(R.id.ID_PNEW_ALT_NUMBER_COCP);
				m_landmark = (EditText)findViewById(R.id.ID_PLANDMARK_COCP);
				m_poa_poi_seen = (EditText)findViewById(R.id.ID_PPOA_POI_SEEN_COCP);
				m_sd_confirmation = (EditText)findViewById(R.id.ID_PSD_CONFIRMATION_COCP);
			}
			else if(mtaskMgr.m_selectedTask.getcaseEntryType().equals("CoipResi"))
			{
				m_caseEntryTypeLayout = (LinearLayout)findViewById(R.id.layoutCOIPResi);
				
				m_Visit_Date = (EditText)findViewById(R.id.ID_PVISIT_DATE_COIP_RESI);
				m_company_name = (EditText)findViewById(R.id.ID_PCOMPANY_NAME_COIP_RESI);
				m_income = (EditText)findViewById(R.id.ID_PINCOME_COIP_RESI);
				m_house_colour = (EditText)findViewById(R.id.ID_PHOUSE_COLOUR_COIP_RESI);
				m_gate_colour = (EditText)findViewById(R.id.ID_PGATE_COLOUR_COIP_RESI);
				m_sd_confirmation = (EditText)findViewById(R.id.ID_PSD_CONFIRMATION_COIP_RESI);
				m_new_alt_number = (EditText)findViewById(R.id.ID_PNEW_ALT_NUMBER_COIP_RESI);
				m_landmark = (EditText)findViewById(R.id.ID_PLANDMARK_COIP_RESI);
				m_ntp_ecs = (EditText)findViewById(R.id.ID_PNTP_ECS_COIP_RESI);
				m_neighbour_check_name_or_plot = (EditText)findViewById(R.id.ID_PNEIGHBOUR_CHECK_OR_PLOTNO_COIP_RESI);
				m_poa_poi_seen = (EditText)findViewById(R.id.ID_PPOA_POI_SEEN_COIP_RESI);
			}
			else if(mtaskMgr.m_selectedTask.getcaseEntryType().equals("CoipOff"))
			{
				m_caseEntryTypeLayout = (LinearLayout)findViewById(R.id.layoutCOIPOff);
				
				m_Visit_Date = (EditText)findViewById(R.id.ID_PVISIT_DATE_COIP_OFF);
				m_entry_allowed_spinner = (customSpinner)findViewById(R.id.ID_ENTRY_ALLOWED_SPINNER_COIP_OFF);
				sOptions = getResources().getStringArray(R.array.ID_ENTRY_ALLOWED_ARRAY);
				m_entry_allowed_spinner.setOptions(sOptions);
				prompt = getResources().getString(R.string.ID_SELECT);
				m_entry_allowed_spinner.setPrompt(prompt);
				m_entry_allowed_spinner.setOnClickListener();
				
				m_designation = (EditText)findViewById(R.id.ID_PDESIGNATION_COIP_OFF);
				m_job_stability = (EditText)findViewById(R.id.ID_PJOB_STABILITY_COIP_OFF);
				m_income = (EditText)findViewById(R.id.ID_PINCOME_COIP_OFF);
				m_visiting_card = (EditText)findViewById(R.id.ID_PVISITING_CARD_COIP_OFF);
				m_official_mailid = (EditText)findViewById(R.id.ID_POFFICIAL_MAILID_COIP_OFF);
				m_official_altno = (EditText)findViewById(R.id.ID_POFFICIAL_ALTNO_COIP_OFF);
				m_official_landmark = (EditText)findViewById(R.id.ID_POFFICE_LANDMARK_COIP_OFF);
			}
			
			m_caseEntryTypeLayout.setVisibility(LinearLayout.VISIBLE);
			
			setValuesfrom_SelectedTask_to_InfoPageControls();
			m_addressCheck.setOnClickListener(new View.OnClickListener() 
			{
				@Override
				public void onClick(View v) 
				{
					m_addressChangeLayout.setVisibility(((CheckBox)v).isChecked() == true ? LinearLayout.VISIBLE : LinearLayout.GONE);
				}
			});
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in initializePersonalInfoPage "+ex.getMessage());
		}
	}

	private void setValuesfrom_SelectedTask_to_InfoPageControls()
	{
		try
		{
			m_name.setText(mtaskMgr.m_selectedTask.getname());
			m_phone.setText(mtaskMgr.m_selectedTask.getphone());
			m_Altphone.setText(mtaskMgr.m_selectedTask.getAltphone());
			m_address.setText(mtaskMgr.m_selectedTask.getAddress());
			m_pincode.setText(mtaskMgr.m_selectedTask.getPincode());
			m_simNumber.setText(mtaskMgr.m_selectedTask.getsimNumber());
			m_billCycle.setText(mtaskMgr.m_selectedTask.getbillCycle());
			m_billAddType.setText(mtaskMgr.m_selectedTask.getbillAddType());
			m_dob.setText(mtaskMgr.m_selectedTask.getdob());
			m_dealerComment.setText(mtaskMgr.m_selectedTask.getdealerComment());
			m_parentName.setText(mtaskMgr.m_selectedTask.getparentName());
			m_addProofType.setText(mtaskMgr.m_selectedTask.getaddProofType());
			m_addProofValue.setText(mtaskMgr.m_selectedTask.getaddProofValue());
			m_idProofType.setText(mtaskMgr.m_selectedTask.getidProofType());
			m_idProofValue.setText(mtaskMgr.m_selectedTask.getidProofValue());
			m_scheme.setText(mtaskMgr.m_selectedTask.getscheme());
			m_tariffPlan.setText(mtaskMgr.m_selectedTask.gettariffPlan());
			m_activation_Type.setText(mtaskMgr.m_selectedTask.getactType());
			m_pre_Pv.setText(mtaskMgr.m_selectedTask.getprePv());
			m_comp_Name.setText(mtaskMgr.m_selectedTask.getcompName());
			m_cust_Class.setText(mtaskMgr.m_selectedTask.getcustClass());
			m_gender.setText(mtaskMgr.m_selectedTask.getgender());
			m_alt_Address.setText(mtaskMgr.m_selectedTask.getaltAddress());
			m_alt_Add_Phone.setText(mtaskMgr.m_selectedTask.getaltAddPhone());
			m_multiMobiles.setText(mtaskMgr.m_selectedTask.getmultiMobiles());
			m_multiRejectMobiles.setText(mtaskMgr.m_selectedTask.getmultiReject());
			boolean isChecked = mtaskMgr.m_selectedTask.getAddressChanged().compareTo("true") == 0;
			m_addressCheck.setChecked(isChecked);
			m_addressChangeLayout.setVisibility(isChecked == true ? LinearLayout.VISIBLE : LinearLayout.GONE);
			if(isChecked == true)
			{
				String AddressType = mtaskMgr.m_selectedTask.getAddressChangedType();
				if(AddressType.compareTo("minor") == 0)
					m_minorAddressType.setChecked(true);
				else 
					m_majorAddressType.setChecked(true);
				m_modifiedAddress.setText(mtaskMgr.m_selectedTask.getModifiedAddress());
			}

			isChecked = mtaskMgr.m_selectedTask.getCommercialConnection().compareTo("true") == 0;
			m_commercialCheck.setChecked(isChecked);
			m_personmet_name.setText(mtaskMgr.m_selectedTask.getPersonMet());
			String option = mtaskMgr.m_selectedTask.getpersonRelation();
			String[] RelationOptions = getResources().getStringArray(R.array.ID_CUSTOMER_RELATIONSHIP);
			int i = 0;
			for( ;i < RelationOptions.length; i++)
			{
				if(RelationOptions[i].compareTo(option) == 0)
					break;
			}
			i = i < RelationOptions.length ? i : 0;
			m_relationship_Spinner.setSelection(i);

			option = mtaskMgr.m_selectedTask.getmultiRejectReason();
			String[] RejectionOptions = getResources().getStringArray(R.array.ID_MULTI_REJECT_REASON_ARRAY);
			for(i = 0;i < RejectionOptions.length; i++)
			{
				if(RejectionOptions[i].compareTo(option) == 0)
					break;
			}
			i = i < RejectionOptions.length ? i : 0;
			m_Reject_Reason_Spinner.setSelection(i);

			m_new_EmailId.setText(mtaskMgr.m_selectedTask.getnewEmailId());
			
			option = mtaskMgr.m_selectedTask.getmaritalStatus();
			String[] sOptions = getResources().getStringArray(R.array.ID_MARITAL_STATUS_ARRAY);
			for(i = 0;i < sOptions.length; i++)
			{
				if(sOptions[i].compareTo(option) == 0)
					break;
			}
			i = i < sOptions.length ? i : 0;
			m_maritalStatus_Spinner.setSelection(i);

			option = mtaskMgr.m_selectedTask.getsimDelivery();
			sOptions = getResources().getStringArray(R.array.ID_SIM_DELIVERY_ARRAY);
			for(i = 0;i < sOptions.length; i++)
			{
				if(sOptions[i].compareTo(option) == 0)
					break;
			}
			i = i < sOptions.length ? i : 0;
			m_simDelivery_Spinner.setSelection(i);

			option = mtaskMgr.m_selectedTask.getplanConfirmation();
			sOptions = getResources().getStringArray(R.array.ID_PLAN_CONFIRMATION_ARRAY);
			for(i = 0;i < sOptions.length; i++)
			{
				if(sOptions[i].compareTo(option) == 0)
					break;
			}
			i = i < sOptions.length ? i : 0;
			m_planConfirmation_Spinner.setSelection(i);

			option = mtaskMgr.m_selectedTask.getfirstBillSample();
			sOptions = getResources().getStringArray(R.array.ID_FIRST_BILL_SAMPLE_ARRAY);
			for(i = 0;i < sOptions.length; i++)
			{
				if(sOptions[i].compareTo(option) == 0)
					break;
			}
			i = i < sOptions.length ? i : 0;
			m_firstBillSample_Spinner.setSelection(i);

			option = mtaskMgr.m_selectedTask.getpaymentOptions();
			sOptions = getResources().getStringArray(R.array.ID_PAYMENT_OPTIONS_ARRAY);
			for(i = 0;i < sOptions.length; i++)
			{
				if(sOptions[i].compareTo(option) == 0)
					break;
			}
			i = i < sOptions.length ? i : 0;
			m_paymentOptions_Spinner.setSelection(i);

			//mGpsLocator = new GpsLocator(activity, mtaskMgr.m_selectedTask);
			//mGpsLocator.sendEvent();

			if(mtaskMgr.m_selectedTask.getcaseEntryType().equals("Ind"))
			{
				m_Visit_Date.setText(mtaskMgr.m_selectedTask.getvisitDate());
				m_company_name.setText(mtaskMgr.m_selectedTask.getcompanyName());
				m_income.setText(mtaskMgr.m_selectedTask.getincome());
				m_house_colour.setText(mtaskMgr.m_selectedTask.gethouseColour());
				m_gate_colour.setText(mtaskMgr.m_selectedTask.getgateColour());
				m_sd_confirmation.setText(mtaskMgr.m_selectedTask.getsdConfirmation());
				m_new_alt_number.setText(mtaskMgr.m_selectedTask.getnewAltNo());
				m_landmark.setText(mtaskMgr.m_selectedTask.getlandmark());
				m_ntp_ecs.setText(mtaskMgr.m_selectedTask.getntpecs());
				m_neighbour_check_name_or_plot.setText(mtaskMgr.m_selectedTask.getneighbourCheckNameOrPlot());
				m_poa_poi_seen.setText(mtaskMgr.m_selectedTask.getpoaPoiSeen());
			}
			else if(mtaskMgr.m_selectedTask.getcaseEntryType().equals("Cocp"))
			{
				m_Visit_Date.setText(mtaskMgr.m_selectedTask.getvisitDate());

				option = mtaskMgr.m_selectedTask.getentryAllowed();
				sOptions = getResources().getStringArray(R.array.ID_ENTRY_ALLOWED_ARRAY);
				for(i = 0;i < sOptions.length; i++)
				{
					if(sOptions[i].compareTo(option) == 0)
						break;
				}
				i = i < sOptions.length ? i : 0;
				m_entry_allowed_spinner.setSelection(i);
				
				m_no_of_connections.setText(mtaskMgr.m_selectedTask.getnoOfConnection());

				option = mtaskMgr.m_selectedTask.getofficeSetup();
				sOptions = getResources().getStringArray(R.array.ID_OFFICE_SETUP_ARRAY);
				for(i = 0;i < sOptions.length; i++)
				{
					if(sOptions[i].compareTo(option) == 0)
						break;
				}
				i = i < sOptions.length ? i : 0;
				m_office_setup_spinner.setSelection(i);
				
				m_nature_of_business.setText(mtaskMgr.m_selectedTask.getnatureOfBusiness());
				option = mtaskMgr.m_selectedTask.getbusinessActivity();
				sOptions = getResources().getStringArray(R.array.ID_BUSINESS_ACTIVITY_ARRAY);
				for(i = 0;i < sOptions.length; i++)
				{
					if(sOptions[i].compareTo(option) == 0)
						break;
				}
				i = i < sOptions.length ? i : 0;
				m_business_activity_spinner.setSelection(i);
				

				option = mtaskMgr.m_selectedTask.getneighbourCheckNameOrPlot();
				sOptions = getResources().getStringArray(R.array.ID_NEIGHBOUR_CHECK_ARRAY);
				for(i = 0;i < sOptions.length; i++)
				{
					if(sOptions[i].compareTo(option) == 0)
						break;
				}
				i = i < sOptions.length ? i : 0;
				m_neighbour_check_spinner.setSelection(i);
				
				m_neighbour_check_name_or_plot.setText(mtaskMgr.m_selectedTask.getneighbourCheckNameOrPlot());
				m_website.setText(mtaskMgr.m_selectedTask.getwebsite());
				m_new_alt_number.setText(mtaskMgr.m_selectedTask.getnewAltNo());
				m_landmark.setText(mtaskMgr.m_selectedTask.getlandmark());
				m_poa_poi_seen.setText(mtaskMgr.m_selectedTask.getpoaPoiSeen());
				m_sd_confirmation.setText(mtaskMgr.m_selectedTask.getsdConfirmation());
			}
			else if(mtaskMgr.m_selectedTask.getcaseEntryType().equals("CoipResi"))
			{
				m_Visit_Date.setText(mtaskMgr.m_selectedTask.getvisitDate());
				m_company_name.setText(mtaskMgr.m_selectedTask.getcompanyName());
				m_income.setText(mtaskMgr.m_selectedTask.getincome());
				m_house_colour.setText(mtaskMgr.m_selectedTask.gethouseColour());
				m_gate_colour.setText(mtaskMgr.m_selectedTask.getgateColour());
				m_sd_confirmation.setText(mtaskMgr.m_selectedTask.getsdConfirmation());
				m_new_alt_number.setText(mtaskMgr.m_selectedTask.getnewAltNo());
				m_landmark.setText(mtaskMgr.m_selectedTask.getlandmark());
				m_ntp_ecs.setText(mtaskMgr.m_selectedTask.getntpecs());
				m_neighbour_check_name_or_plot.setText(mtaskMgr.m_selectedTask.getneighbourCheckNameOrPlot());
				m_poa_poi_seen.setText(mtaskMgr.m_selectedTask.getpoaPoiSeen());
			}
			else if(mtaskMgr.m_selectedTask.getcaseEntryType().equals("CoipOff"))
			{
				m_Visit_Date.setText(mtaskMgr.m_selectedTask.getvisitDate());

				option = mtaskMgr.m_selectedTask.getentryAllowed();
				sOptions = getResources().getStringArray(R.array.ID_ENTRY_ALLOWED_ARRAY);
				for(i = 0;i < sOptions.length; i++)
				{
					if(sOptions[i].compareTo(option) == 0)
						break;
				}
				i = i < sOptions.length ? i : 0;
				m_entry_allowed_spinner.setSelection(i);
				
				m_designation.setText(mtaskMgr.m_selectedTask.getdesignation());
				m_job_stability.setText(mtaskMgr.m_selectedTask.getjobStability());
				m_income.setText(mtaskMgr.m_selectedTask.getincome());
				m_visiting_card.setText(mtaskMgr.m_selectedTask.getvisitingCard());
				m_official_mailid.setText(mtaskMgr.m_selectedTask.getofficialMailId());
				m_official_altno.setText(mtaskMgr.m_selectedTask.getofficialAltNo());
				m_official_landmark.setText(mtaskMgr.m_selectedTask.getlandmark());
			}
		
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in setValuesfrom_SelectedTask_to_InfoPageControls "+ ex.getMessage());
		}
	}

	private void setValues_InfoPageControls_to_task()
	{
		try
		{
			mtaskMgr.m_selectedTask.setname(m_name.getText().toString());
			mtaskMgr.m_selectedTask.setphone(m_phone.getText().toString());
			mtaskMgr.m_selectedTask.setAltphone(m_Altphone.getText().toString());
			mtaskMgr.m_selectedTask.setAddress(m_address.getText().toString());
			mtaskMgr.m_selectedTask.setPincode(m_pincode.getText().toString());
			mtaskMgr.m_selectedTask.setsimNumber(m_simNumber.getText().toString());
			mtaskMgr.m_selectedTask.setbillCycle(m_billCycle.getText().toString());
			mtaskMgr.m_selectedTask.setbillAddType(m_billAddType.getText().toString());
			mtaskMgr.m_selectedTask.setdob(m_dob.getText().toString());
			mtaskMgr.m_selectedTask.setdealerComment(m_dealerComment.getText().toString());
			mtaskMgr.m_selectedTask.setparentName(m_parentName.getText().toString());
			mtaskMgr.m_selectedTask.setaddProofType(m_addProofType.getText().toString());
			mtaskMgr.m_selectedTask.setaddProofValue(m_addProofValue.getText().toString());
			mtaskMgr.m_selectedTask.setidProofType(m_idProofType.getText().toString());
			mtaskMgr.m_selectedTask.setidProofValue(m_idProofValue.getText().toString());
			mtaskMgr.m_selectedTask.setscheme(m_scheme.getText().toString());
			mtaskMgr.m_selectedTask.settariffPlan(m_tariffPlan.getText().toString());
			mtaskMgr.m_selectedTask.setactType(m_activation_Type.getText().toString());
			mtaskMgr.m_selectedTask.setprePv(m_pre_Pv.getText().toString());
			mtaskMgr.m_selectedTask.setcompName(m_comp_Name.getText().toString());
			mtaskMgr.m_selectedTask.setcustClass(m_cust_Class.getText().toString());
			mtaskMgr.m_selectedTask.setgender(m_gender.getText().toString());
			mtaskMgr.m_selectedTask.setaltAddress(m_alt_Address.getText().toString());
			mtaskMgr.m_selectedTask.setaltAddPhone(m_alt_Add_Phone.getText().toString());
			mtaskMgr.m_selectedTask.setmultiMobiles(m_multiMobiles.getText().toString());
			mtaskMgr.m_selectedTask.setmultiReject(m_multiRejectMobiles.getText().toString());
			mtaskMgr.m_selectedTask.setAddressChanged(m_addressCheck.isChecked() == true ? "true" : "false");
			if(m_addressChangeLayout.getVisibility() == LinearLayout.VISIBLE)
			{
				String AddChangeType = m_minorAddressType.isChecked() == true ? "minor" : "major";
				mtaskMgr.m_selectedTask.setAddressChangedType(AddChangeType);
				mtaskMgr.m_selectedTask.setModifiedAddress(m_modifiedAddress.getText().toString());
			}
			else
			{
				mtaskMgr.m_selectedTask.setAddressChangedType("");
				mtaskMgr.m_selectedTask.setModifiedAddress("");
			}

			mtaskMgr.m_selectedTask.setCommercialConnection(m_commercialCheck.isChecked() == true ? "true":"false");
			mtaskMgr.m_selectedTask.setPersonMet(m_personmet_name.getText().toString());
			String relation = m_relationship_Spinner.getText().toString();
			mtaskMgr.m_selectedTask.setpersonRelation(relation);
			String rejectionReason = m_Reject_Reason_Spinner.getText().toString();
			mtaskMgr.m_selectedTask.setmultiRejectReason(rejectionReason);

			mtaskMgr.m_selectedTask.setnewEmailId(m_new_EmailId.getText().toString());

			String sOptions = m_maritalStatus_Spinner.getText().toString();
			mtaskMgr.m_selectedTask.setmaritalStatus(sOptions);
			sOptions = m_simDelivery_Spinner.getText().toString();
			mtaskMgr.m_selectedTask.setsimDelivery(sOptions);
			sOptions = m_planConfirmation_Spinner.getText().toString();
			mtaskMgr.m_selectedTask.setplanConfirmation(sOptions);
			sOptions = m_firstBillSample_Spinner.getText().toString();
			mtaskMgr.m_selectedTask.setfirstBillSample(sOptions);
			sOptions = m_paymentOptions_Spinner.getText().toString();
			mtaskMgr.m_selectedTask.setpaymentOptions(sOptions);

			if(mtaskMgr.m_selectedTask.getcaseEntryType().equals("Ind"))
			{
				mtaskMgr.m_selectedTask.setvisitDate(m_Visit_Date.getText().toString());
				mtaskMgr.m_selectedTask.setcompanyName(m_company_name.getText().toString());
				mtaskMgr.m_selectedTask.setincome(m_income.getText().toString());
				mtaskMgr.m_selectedTask.sethouseColour(m_house_colour.getText().toString());
				mtaskMgr.m_selectedTask.setgateColour(m_gate_colour.getText().toString());
				mtaskMgr.m_selectedTask.setsdConfirmation(m_sd_confirmation.getText().toString());
				mtaskMgr.m_selectedTask.setAltphone(m_new_alt_number.getText().toString());
				mtaskMgr.m_selectedTask.setlandmark(m_landmark.getText().toString());
				mtaskMgr.m_selectedTask.setntpecs(m_ntp_ecs.getText().toString());
				mtaskMgr.m_selectedTask.setneighbourCheckNameOrPlot(m_neighbour_check_name_or_plot.getText().toString());
				mtaskMgr.m_selectedTask.setpoaPoiSeen(m_poa_poi_seen.getText().toString());
			}
			else if(mtaskMgr.m_selectedTask.getcaseEntryType().equals("Cocp"))
			{
				mtaskMgr.m_selectedTask.setvisitDate(m_Visit_Date.getText().toString());
				mtaskMgr.m_selectedTask.setentryAllowed(m_entry_allowed_spinner.getText().toString());
				mtaskMgr.m_selectedTask.setnoOfConnection(m_no_of_connections.getText().toString());
				mtaskMgr.m_selectedTask.setofficeSetup(m_office_setup_spinner.getText().toString());
				mtaskMgr.m_selectedTask.setnatureOfBusiness(m_nature_of_business.getText().toString());
				mtaskMgr.m_selectedTask.setbusinessActivity(m_business_activity_spinner.getText().toString());
				mtaskMgr.m_selectedTask.setneighbourCheck(m_neighbour_check_spinner.getText().toString());
				mtaskMgr.m_selectedTask.setneighbourCheckNameOrPlot(m_neighbour_check_name_or_plot.getText().toString());
				mtaskMgr.m_selectedTask.setwebsite(m_website.getText().toString());
				mtaskMgr.m_selectedTask.setnewAltNo(m_new_alt_number.getText().toString());
				mtaskMgr.m_selectedTask.setlandmark(m_landmark.getText().toString());
				mtaskMgr.m_selectedTask.setpoaPoiSeen(m_poa_poi_seen.getText().toString());
				mtaskMgr.m_selectedTask.setsdConfirmation(m_sd_confirmation.getText().toString());
			}
			else if(mtaskMgr.m_selectedTask.getcaseEntryType().equals("CoipResi"))
			{
				m_caseEntryTypeLayout = (LinearLayout)findViewById(R.id.layoutCOIPResi);
				
				mtaskMgr.m_selectedTask.setvisitDate(m_Visit_Date.getText().toString());
				mtaskMgr.m_selectedTask.setcompanyName(m_company_name.getText().toString());
				mtaskMgr.m_selectedTask.setincome(m_income.getText().toString());
				mtaskMgr.m_selectedTask.sethouseColour(m_house_colour.getText().toString());
				mtaskMgr.m_selectedTask.setgateColour(m_gate_colour.getText().toString());
				mtaskMgr.m_selectedTask.setsdConfirmation(m_sd_confirmation.getText().toString());
				mtaskMgr.m_selectedTask.setnewAltNo(m_new_alt_number.getText().toString());
				mtaskMgr.m_selectedTask.setlandmark(m_landmark.getText().toString());
				mtaskMgr.m_selectedTask.setntpecs(m_ntp_ecs.getText().toString());
				mtaskMgr.m_selectedTask.setneighbourCheckNameOrPlot(m_neighbour_check_name_or_plot.getText().toString());
				mtaskMgr.m_selectedTask.setpoaPoiSeen(m_poa_poi_seen.getText().toString());
			}
			else if(mtaskMgr.m_selectedTask.getcaseEntryType().equals("CoipOff"))
			{
				mtaskMgr.m_selectedTask.setvisitDate(m_Visit_Date.getText().toString());
				mtaskMgr.m_selectedTask.setentryAllowed(m_entry_allowed_spinner.getText().toString());
				mtaskMgr.m_selectedTask.setdesignation(m_designation.getText().toString());
				mtaskMgr.m_selectedTask.setjobStability(m_job_stability.getText().toString());
				mtaskMgr.m_selectedTask.setincome(m_income.getText().toString());
				mtaskMgr.m_selectedTask.setvisitingCard(m_visiting_card.getText().toString());
				mtaskMgr.m_selectedTask.setofficialMailId(m_official_mailid.getText().toString());
				mtaskMgr.m_selectedTask.setofficialAltNo(m_official_altno.getText().toString());
				mtaskMgr.m_selectedTask.setofficialLandmark(m_official_landmark.getText().toString());
			}

		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in setValues_InfoPageControls_to_task "+ ex.getMessage());
		}
	}

	private int IsInfoPage_OptionsCompleted()
	{
		try
		{
			if(m_name.getText().toString().length() == 0)
			{
				Toast.makeText(activity, "Please Write Name" , Toast.LENGTH_LONG).show();
				return -1;
			}
			else if(m_phone.getText().toString().length() == 0)
			{
				Toast.makeText(activity, "Please Write Phone Number" , Toast.LENGTH_LONG).show();
				return -1;
			}
			else if(m_Altphone.getText().toString().length() == 0)
			{
				Toast.makeText(activity, "Please Write Alternate Phone Number", Toast.LENGTH_LONG).show();
				return -1;
			}
			else if(m_address.getText().toString().length() == 0)
			{
				Toast.makeText(activity, "Please Write Address" , Toast.LENGTH_LONG).show();
				return -1;
			}
			else if(m_pincode.getText().toString().length() == 0)
			{
				Toast.makeText(activity, "Please Write Pincode", Toast.LENGTH_LONG).show();
				return -1;
			}
			else if(m_addressChangeLayout.getVisibility() == LinearLayout.VISIBLE)
			{
				if(m_modifiedAddress.getText().toString().length() == 0)
				{
					Toast.makeText(activity, "Please Enter Modified Address" , Toast.LENGTH_LONG).show();
					return -1;
				}
			}
			else if(m_personmet_name.getText().toString().length() == 0)
			{
				Toast.makeText(activity, "Please Write the Name of Person Whom met" , Toast.LENGTH_LONG).show();
				return -1;
			}
			else if(m_relationship_Spinner.getSelectedItemPosition() < 1)
			{
				Toast.makeText(activity, "Please Choose Relation" , Toast.LENGTH_LONG).show();
				return -1;
			}
			else if(m_multiRejectMobiles.getText().toString().length() > 0)
			{
				if(m_Reject_Reason_Spinner.getSelectedItemPosition() < 1)
				{
					Toast.makeText(activity, "Please Select Multiple Mobile Rejection Reason" , Toast.LENGTH_LONG).show();
					return -1;
				}
			}
			return 0;
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in IsInfoPage_OptionsCompleted "+ ex.getMessage() );
			return -1;
		}
	}

	private void saveQuesAnsList()
	{
		try{
			mtaskMgr.m_selectedTask.setQuesAnsList(m_QuestionListAdapter.getQuesAnswerList());
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in saveQuesAnsList "+ ex.getMessage());
		}
	}

	private int isQuestionPageComplete()
	{
		try{
			ArrayList<QuesAndAnswer> QuesAndAnswerList = m_QuestionListAdapter.getQuesAnswerList();
			for(int i = 0; i < QuesAndAnswerList.size(); i++)
			{
				QuesAndAnswer qAobj = QuesAndAnswerList.get(i);
				if(qAobj.selectedAnswer == 0)
				{
					Toast.makeText(activity, "Select "+ qAobj.Question, Toast.LENGTH_LONG).show();
					return -1;
				}
			}
			return 0;
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in isQuestionPageComplete "+ ex.getMessage());
			return -1;
		}
	}
	private void initializeQuestionPage()
	{
		try
		{
			mtaskMgr.currentScreen = Constants.Screen.Question;
			m_QuestionListView = (ListView)findViewById(R.id.ID_GENERAL_QUESTIONLIST);
			ArrayList<Parameter> paramList = mdyxmlObj.getParameterList(mtaskMgr.m_selectedTask.getcaseCategory());
			m_QuestionListAdapter = new ParamListViewAdapter(this,mtaskMgr.m_QuestionList,m_QuestionListView);
			m_QuestionListAdapter.setParameterList(paramList);
			m_QuestionListView.setAdapter(m_QuestionListAdapter);
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in initializeQuestionPage "+ ex.getMessage());
		}
	}

	private void capturePhoto()
	{
		try
		{
			m_photoSurface.setPhotoImagefile(workingDir,currImagefilePath.m_currentImagePath);
			m_photoSurface.takePhoto();
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in capturePhoto" + ex.getMessage());
		}
	}
	private void closeCamera()
	{
		try
		{
			m_photoSurface.onCloseCamera();
			setContentView(R.layout.framelayout);
			InitializeInfoPage(2);
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in closeCamera "+ ex.getMessage());
		}
	}

	public void InitializeCameraShoot()
	{
		try
		{
			mtaskMgr.currentScreen = Constants.Screen.Photo;
			m_document1	= (ImageView)findViewById(R.id.ID_IMAGE_DOC_1_PREVIEW);
			m_document1ShootButton = (ImageButton)findViewById(R.id.ID_DOC_1_SHOOT_BUTTON);
			m_document2 = (ImageView)findViewById(R.id.ID_IMAGE_DOC_2_PREVIEW);
			m_document2ShootButton = (ImageButton)findViewById(R.id.ID_DOC_2_SHOOT_BUTTON);
			m_LandMarkCheck = (CheckBox)findViewById(R.id.ID_LANDMARK_CHECKBOX);
			m_LandMark	= (ImageView)findViewById(R.id.ID_IMAGE_LANDMARK_PREVIEW);
			m_LandMarkShootButton = (ImageButton)findViewById(R.id.ID_LANDMARK_SHOOT_BUTTON);
			m_LandMarkLayout = (LinearLayout)findViewById(R.id.ID_LANDMARK_PREVIEWLAYOUT);

			m_document1ShootButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) 
				{
					currImagefilePath.m_currentImagePath = mtaskMgr.m_selectedTask.getId()+"_doc1.jpg";
					mtaskMgr.m_selectedTask.setDoc1Image(currImagefilePath.m_currentImagePath);
					setContentView(R.layout.photo);
					currentMenu = Constants.Screen.Photo;
					takePic();
					/*m_photoSurface = (PhotoSurface)findViewById(R.id.ID_PHOTO_SURFACEVIEW);
					int rotation = activity.getWindowManager().getDefaultDisplay().getRotation();
					m_photoSurface.onStartCamera(rotation);
					currentMenu = Constants.Screen.Photo;*/
				}
			});

			m_document2ShootButton.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) 
				{
					currImagefilePath.m_currentImagePath = mtaskMgr.m_selectedTask.getId()+"_doc2.jpg";
					mtaskMgr.m_selectedTask.setDoc2Image(currImagefilePath.m_currentImagePath);	
					setContentView(R.layout.photo);
					currentMenu = Constants.Screen.Photo;
					takePic();
					/*m_photoSurface = (PhotoSurface)findViewById(R.id.ID_PHOTO_SURFACEVIEW);
					int rotation = activity.getWindowManager().getDefaultDisplay().getRotation();
					m_photoSurface.onStartCamera(rotation);
					currentMenu = Constants.Screen.Photo;*/
				}
			});
			m_LandMarkCheck.setOnClickListener(new View.OnClickListener() 
			{
				@Override
				public void onClick(View v) 
				{
					m_LandMarkLayout.setVisibility(((CheckBox)v).isChecked() == true ? LinearLayout.VISIBLE : LinearLayout.GONE);
					mtaskMgr.m_selectedTask.setLandMarkCheck(((CheckBox)v).isChecked() == true ? "true": "false");
				}
			});

			m_LandMarkShootButton.setOnClickListener(new View.OnClickListener() 
			{
				@Override
				public void onClick(View v) 
				{
					currImagefilePath.m_currentImagePath = mtaskMgr.m_selectedTask.getId()+"_landMark.jpg";
					mtaskMgr.m_selectedTask.setLandMarkImage(currImagefilePath.m_currentImagePath);	
					setContentView(R.layout.photo);
					currentMenu = Constants.Screen.Photo;
					takePic();
					/*m_photoSurface = (PhotoSurface)findViewById(R.id.ID_PHOTO_SURFACEVIEW);
					int rotation = activity.getWindowManager().getDefaultDisplay().getRotation();
					m_photoSurface.onStartCamera(rotation);
					currentMenu = Constants.Screen.Photo;*/
				}
			});

			String docFileName = mtaskMgr.m_selectedTask.getDoc1Image();
			if(docFileName.length() > 0)
			{
				try
				{
					String path = workingDir;
					path = path + "/" + docFileName; 
					File file = new File(path);
					if(file.exists() == false)
					{
						mtaskMgr.m_selectedTask.setDoc1Image("");
						return;
					}
					Bitmap bmp = BitmapFactory.decodeFile(path);
					m_document1.setImageBitmap(bmp);
					Log.v("minty","image photo1 preview drawable done");
				}
				catch(Throwable p)
				{
					Log.e("minty","image photo1 preview drawable crashed");

				}
				finally
				{
					Log.e("minty","image photo1 preview finally");
				}
			}
			docFileName = mtaskMgr.m_selectedTask.getDoc2Image();
			if(docFileName!= null && docFileName.length()> 0)
			{
				try
				{
					String path = workingDir;
					path = path + "/" + docFileName; 
					File file = new File(path);
					if(file.exists() == false)
					{
						mtaskMgr.m_selectedTask.setDoc2Image("");
						return;
					}
					Bitmap bmp = BitmapFactory.decodeFile(path);
					m_document2.setImageBitmap(bmp);
					Log.v("minty","image photo2 preview drawable done");
				}
				catch(Throwable p)
				{
					Log.e("minty","image photo2 preview drawable crashed");

				}
				finally
				{
					Log.e("minty","image photo2  preview finally");
				}

			}

			boolean blandMarkCheck = mtaskMgr.m_selectedTask.getLandMarkCheck().compareTo("true") == 0? true : false;
			m_LandMarkCheck.setChecked(blandMarkCheck);
			m_LandMarkLayout.setVisibility(blandMarkCheck == true ? LinearLayout.VISIBLE : LinearLayout.GONE);
			docFileName = mtaskMgr.m_selectedTask.getLandMarkImage();
			if(docFileName!= null && docFileName.length()> 0)
			{
				try
				{
					String path = workingDir;
					path = path + "/" + docFileName; 
					File file = new File(path);
					if(file.exists() == false)
					{
						mtaskMgr.m_selectedTask.setLandMarkImage("");
						return;
					}
					Bitmap bmp = BitmapFactory.decodeFile(path);
					m_LandMark.setImageBitmap(bmp);
					Log.v("minty","image LandMark image preview drawable done");
				}
				catch(Throwable p)
				{
					Log.e("minty","image LandMark preview drawable crashed");

				}
				finally
				{
					Log.e("minty","image LandMark  preview finally");
				}

			}
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in InitializeCameraShoot "+ ex.getMessage());
		}
	}

	private int isPhotoPageComplete()
	{
		try
		{
			/*String docImage = mtaskMgr.m_selectedTask.getDoc1Image();
			if(docImage.length() == 0)
			{
				Toast.makeText(activity, "Please Take Document 1 Photo", Toast.LENGTH_LONG).show();
				return -1;
			}*/
			return 0;
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in isPhotoPageComplete "+ ex.getMessage());
			return -1;
		}
	}


	private void saveSignImage()
	{
		try
		{
			m_fingerPaintView.SaveImage(workingDir,currImagefilePath.m_currentImagePath);
			setContentView(R.layout.framelayout);
			InitializeInfoPage(1);
			currentMenu = Constants.Screen.MainScreen;
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in saveSignImage "+ ex.getMessage());
		}
	}
	private void clearSignScreen()
	{
		try
		{
			m_fingerPaintView.ClearCanvas();
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in clearSignScreen "+ ex.getMessage());
		}
	}

	private void initializeSignature()
	{
		try
		{
			mtaskMgr.currentScreen = Constants.Screen.Signature;
			m_UserSignDeclaration = (TextView)findViewById(R.id.ID_SIGNATURE_DEC_TEXT);
			m_UserSignPreview = (ImageView)findViewById(R.id.ID_IMAGE_USER_SIGNPREVIEW);
			m_UsertakeSignButton = (ImageButton)findViewById(R.id.ID_SIGN_USER_BUTTON);
			String declarationText = "This is to certify that Mobile No "+ mtaskMgr.m_selectedTask.getphone() + " is been purchased by "+ mtaskMgr.m_selectedTask.getname() +" and all the information provided is true to the best of my knowledge.";
			m_UserSignDeclaration.setTextColor(Color.BLUE);
			m_UserSignDeclaration.setText(declarationText);
			m_UsertakeSignButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) 
				{
					currImagefilePath.m_currentImagePath = mtaskMgr.m_selectedTask.getId()+"_csign.jpg";
					mtaskMgr.m_selectedTask.setcustomerSignImage(currImagefilePath.m_currentImagePath);
					setContentView(R.layout.signaturepaint);
					m_fingerPaintView = (FingerPaint)findViewById(R.id.ID_FINGERPAINTVIEW);
					m_fingerPaintView.ClearCanvas();
					currentMenu = Constants.Screen.Signature;
				}
			});

			String SignImageName = mtaskMgr.m_selectedTask.getcustomerSignImage();
			if(SignImageName.length() > 0)
			{
				try
				{
					String path = workingDir;
					path = path + "/" + SignImageName; 
					File file = new File(path);
					if(file.exists() == false)
					{
						mtaskMgr.m_selectedTask.setcustomerSignImage("");
						return;
					}
					Bitmap bmp = BitmapFactory.decodeFile(path);
					m_UserSignPreview.setImageBitmap(bmp);
					Log.v("minty","image preview drawable done");
				}
				catch(Throwable p)
				{
					Log.e("minty","image preview drawable crashed");

				}
				finally
				{
					Log.e("minty","image preview finally");
				}
			}
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in initializeSignature "+ ex.getMessage());
		}

	}
	private int isSignPageComplete()
	{
		try
		{
			/*String signImage = mtaskMgr.m_selectedTask.getcustomerSignImage();
			if(signImage.length() == 0)
			{
				Toast.makeText(activity, "Please take the customer sign", Toast.LENGTH_LONG).show();
				return -1;
			}*/

			return 0;
		}
		catch(Exception ex)
		{
			Log.e(TAG, "Exception in isSignPageComplete "+ ex.getMessage());
			return -1;
		}
	}

	private void InitializeRemarks()
	{
		try
		{
			mtaskMgr.currentScreen = Constants.Screen.Remarks;
			LinearLayout nfeedback = (LinearLayout)findViewById(R.id.ID_FEEDBACK_LAYOUT);
			//LinearLayout nremarks = (LinearLayout)findViewById(R.id.ID_REMARKS_LAYOUT);
			String state = mtaskMgr.m_selectedTask.getstate();
			if(state.compareTo(Constants.TaskState.NEGATIVE) == 0)
			{
				nfeedback.setVisibility(LinearLayout.VISIBLE);
				//nremarks.setVisibility(LinearLayout.GONE);
				m_feebackSpinner = (customSpinner)findViewById(R.id.ID_FEEDBACK_SPINS);
				String []negativefeedbackArray = getResources().getStringArray(R.array.ID_FEEDBACK_STRING_ARRAY);
				String prompt = getResources().getString(R.string.ID_SELECT);
				m_feebackSpinner.setOptions(negativefeedbackArray);
				m_feebackSpinner.setPrompt(prompt);
				m_feebackSpinner.setOnClickListener();
				String feedback = mtaskMgr.m_selectedTask.getfeedback();
				int index = 0;
				for(int i = 0; i < negativefeedbackArray.length; i++)
				{
					if(negativefeedbackArray[i].compareTo(feedback) == 0) 
					{
						index  = i;
						break;
					}
				}
				m_feebackSpinner.setSelection(index);
			}
			else
			{
				nfeedback.setVisibility(LinearLayout.GONE);
			}
			m_customerremarks	= (EditText)findViewById(R.id.ID_REMARK_TEXT);
			String remark = mtaskMgr.m_selectedTask.getcomment();
			m_customerremarks.setText(remark);
			
			mGpsLocator = new GpsLocator(activity, mtaskMgr.m_selectedTask);
			mGpsLocator.sendEvent();
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in InitializeRemarks" + ex.getMessage());
		}
	}

	private int IsRemarks_pageComplete()
	{
		try
		{
			int retValue = 0;
			String state = mtaskMgr.m_selectedTask.getstate();
			if(state.compareTo(Constants.TaskState.NEGATIVE) == 0)
			{
				if(m_feebackSpinner.getSelectedItemPosition() < 1)
				{
					retValue = -1;
					Toast.makeText(activity, "Please Select Negative Reason", Toast.LENGTH_LONG).show();
					return retValue;
				}
			}
			String exeRemarks = m_customerremarks.getText().toString();
			if(exeRemarks.length() == 0)
			{
				retValue = -1;
				Toast.makeText(activity, "Please Write Remarks", Toast.LENGTH_LONG).show();
				return retValue;
			}
			return retValue;
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in IsRemarks_pageComplete "+ ex.getMessage());
			return -1;
		}
	}

	public void saveRemarks_page()
	{
		try
		{
			String state = mtaskMgr.m_selectedTask.getstate();
			if(state.compareTo(Constants.TaskState.POSITIVE) == 0)
			{
				mtaskMgr.m_selectedTask.setfeedback("");
			}
			else
			{
				if(state.compareTo(Constants.TaskState.NEGATIVE) == 0)
				{
					String feedBack = m_feebackSpinner.getText().toString();
					mtaskMgr.m_selectedTask.setfeedback(feedBack);
				}
			}
			String comments = m_customerremarks.getText().toString();
			mtaskMgr.m_selectedTask.setcomment(comments);
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in saveRemarks_page "+ ex.getMessage());
		}
	}

	public void SubmitTask()
	{
		try
		{
			if(IsRemarks_pageComplete() == -1)
			{
				return;
			}
			saveRemarks_page();
			Case job = mtaskMgr.CreateCase(mtaskMgr.m_selectedTask,mtaskMgr.m_selectedTask.getstate(),Constants.yesno.Yes);
			if(taskSource.updateTask(job) > 0)
			{
				int ret = mtaskMgr.UpdateExistingTask(mtaskMgr.m_selectedTask);
				if(ret == 0)
					Toast.makeText(activity, "Task Submitted", Toast.LENGTH_LONG).show();
			}
			else
			{
				Toast.makeText(activity, "Task Submission failed", Toast.LENGTH_LONG).show();
			}
			switchPage(1);//move back to main page
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in SubmitTask "+ ex.getMessage());
		}
	}
	

	public class AsyncExecute extends AsyncTask<String, String, String> 
	{
		private masscommClientActivity parent = null;
		private Request request;
		private int RequestType = -1;
		private RestClient restClient;  
		AsyncExecute(masscommClientActivity activity,Request req,int type,RestClient rClient)
		{
			parent = activity;
			request = req;
			RequestType = type;
			restClient = rClient;
		}
		@Override
		protected String doInBackground(String... options) 
		{
			String response = "";
			try
			{
				((SharedApplication)getApplication()).getWebWriteLock().lock();
				try
				{
					restClient.callWebService(RequestType);
				}
				finally
				{
					((SharedApplication)getApplication()).getWebWriteLock().unlock();
				}
			}
			catch(IllegalStateException isE)
			{
				isE.printStackTrace();
				response = status.fxmlstatus+"400"+status.sxmlstatus+isE.getMessage()+status.txmlstatus;
				return response; 
			}
			catch(ClientProtocolException cpE)
			{
				cpE.printStackTrace();
				response = status.fxmlstatus+"400"+status.sxmlstatus+cpE.getMessage()+status.txmlstatus;
				return response;
			}
			catch(IOException ioE)
			{
				ioE.printStackTrace();
				response = status.fxmlstatus+"400"+status.sxmlstatus+ioE.getMessage()+status.txmlstatus;
				return response;
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				response = status.fxmlstatus+"400"+status.sxmlstatus+ex.getMessage()+status.txmlstatus;
				return response;
			}
			response = restClient.getResponse();
			Log.e(masscommClientActivity.TAG, response);
			return response;
		}

		@Override
		protected void onPostExecute(String response) 
		{
			try
			{
				if(Request.LOGIN == request)
				{
					m_progressBar.setVisibility(ProgressBar.INVISIBLE);
					m_loginButton.setClickable(true);
				}
				if(Request.LOGOUT == request)
				{
					mtaskMgr.LogoutEventFired = false;
				}
				request = restClient.getResponseCode() == 200 ? request : Request.ERROR; 
				parent.processPostExecute(request, response);
			}
			catch(Exception ex)
			{
				Log.e(TAG,"Exception in onPostExecute "+ ex.getMessage());
			}
		}
	}
	public void processPostExecute(Request req,String response)
	{
		try
		{
			switch(req)
			{
			case ERROR:
				onError(response);
				break;
			case LOGIN:
				onLoginSuccess(response);
				break;
			case LOGOUT:
				onLogoutSuccess(response);
				break;
			case TASKLIST_UPDATE:
				//Toast.makeText(activity, "Response of Task List", Toast.LENGTH_SHORT).show();
				onGetTaskList(response);
				break;
			case UI_INS:
				onGetNewUI(response,"I");
				break;
			case UI_SME:
				onGetNewUI(response,"S");
				break;
			case UI_COSP:
				onGetNewUI(response,"C");
				break;
			case NO_UPDATE:
				onRecLocation(response);
				break;
			}
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in processPostExecute "+ ex.getMessage());
		}
	}

	public void onError(String response)
	{
		try
		{
			Status errStatus = new Status();
			errStatus.UnMarshall(response);
			if(errStatus.geterrorString() == null)
				errStatus.seterrorString(response);
			Toast.makeText(this, errStatus.geterrorString(), Toast.LENGTH_LONG).show();
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in onError "+ ex.getMessage());
		}
	}

	private void SavePreferences(String key, String value)
	{
		try
		{
			SharedPreferences sharedPreferences = getSharedPreferences("masscom", Context.MODE_PRIVATE);
			SharedPreferences.Editor editor = sharedPreferences.edit();
			editor.putString(key, value);
			editor.commit();
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in SavePreferences "+ ex.getMessage());
		}
	}

	public void onLoginSuccess(String response)
	{
		try
		{
			Status loginStatus = new Status();
			loginStatus.UnMarshall(response);
			if(loginStatus.geterrorString() == null)
				loginStatus.seterrorString(response);
			Toast.makeText(this, loginStatus.geterrorString(), Toast.LENGTH_LONG).show();
			if(loginStatus.geterror() == 0)
			{
				switchPage(1); //move to post login page
				SavePreferences("Login","1");
				SavePreferences("USERID", mtaskMgr.mUserId);
				startBackgroundService();
			}
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in onLoginSuccess "+ ex.getMessage());
		}
	}

	private boolean isMyServiceRunning() 
	{
		try
		{
			ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
			for (RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) 
			{
				if ("minty.masscom.client.service.updateintentservice".equals(service.service.getClassName())) {
					return true;
				}
			}
			return false;
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in isMyServiceRunning "+ex.getMessage());
			return false;
		}
	}
	private void startBackgroundService()
	{
		try
		{
			if(isMyServiceRunning() == true)return;
			Intent intent = new Intent(this, updateintentservice.class);
			m_messenger = new Messenger(new IncomingHandler());
			intent.putExtra("MESSENGER", m_messenger);
			intent.putExtra("USERID", mtaskMgr.mUserId);
			startService(intent);
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in startBackgroundService "+ ex.getMessage());
		}
	}
	public void onLogoutSuccess(String response)
	{
		try
		{
			Status logoutStatus = new Status();
			logoutStatus.UnMarshall(response);
			if(logoutStatus.geterrorString() == null)
				logoutStatus.seterrorString(response);
			Toast.makeText(this, logoutStatus.geterrorString(), Toast.LENGTH_LONG).show();
			if(logoutStatus.geterror() == 0)
			{
				SavePreferences("Login","0");
				switchPage(0); //move to Login Page
				stopService(new Intent(masscommClientActivity.this, updateintentservice.class));
			}
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in onLogoutSuccess "+ ex.getMessage());
		}
	}

	public void onGetTaskList(String response)
	{
		try
		{
			Toast.makeText(activity, "Task List Update", Toast.LENGTH_SHORT).show();
			TaskList tasklist = new TaskList();
			tasklist.UnMarshall(response);
			ArrayList<Task> taskList =  tasklist.getTaskList();
			int index = 0;
			boolean dataSetModify = false;
			for(index = 0; index < taskList.size(); index++)
			{
				Task task = taskList.get(index);
				if(task.getstate().compareTo(Constants.TaskState.NEW) == 0)
				{
					Case jobCase = mtaskMgr.CreateCase(task,Constants.TaskState.NEW,Constants.yesno.No);
					long retVal = taskSource.insertTask(jobCase);
					if(retVal == -1)//duplicate or unsuccessful
					{
						Log.e(TAG,"new task insertion failed"+ task.getId());
					}
					else//successful
					{
						int ret = mtaskMgr.UpdateOnNewTask(task);
						if(ret == 0)dataSetModify = true;
					}
				}
				else if(task.getstate().compareTo(Constants.TaskState.NEWWELCOME) == 0)
				{
					Case jobCase = mtaskMgr.CreateCase(task,Constants.TaskState.NEWWELCOME,Constants.yesno.No);
					long retVal = taskSource.insertTask(jobCase);
					if(retVal == -1)//duplicate or unsuccessful
					{
						Log.e(TAG,"new task insertion failed"+ task.getId());
					}
					else//successful
					{
						int ret = mtaskMgr.UpdateOnNewTask(task);
						if(ret == 0)dataSetModify = true;
					}
				}
				else if(task.getstate().compareTo(Constants.TaskState.RESCHEDULED) == 0)
				{//rescheduled from server just delete
					Case job = mtaskMgr.CreateCase(task,Constants.TaskState.RESCHEDULED,Constants.yesno.No);
					if(taskSource.deleteTask(job) > 0) //affected rows
					{
						String [][]file = new String[7][2];
						file[0][0] = task.getDoc1Image(); 			file[0][1] = "1";
						file[1][0] = task.getDoc2Image();			file[1][1] = "1";
						file[2][0] = task.getcustomerSignImage();	file[2][1] = "1";
						file[3][0] = task.getExecutiveSignImage();	file[3][1] = "1";
						file[4][0] = task.getLandMarkImage();		file[4][1] = "1";
						file[5][0] = task.getAudiofile();			file[5][1] = "1";
						file[6][0] = task.getId()+".xml";			file[6][1] = "1";
						mtaskMgr.deleteTask(task.getId(),file);	
						dataSetModify = true;
					}
				}
				else if(task.getstate().compareTo(Constants.TaskState.NEGATIVE) == 0)
				{
					//TODO: Do Nothing not expected state
				}
				else if(task.getstate().compareTo(Constants.TaskState.POSITIVE) == 0)
				{
					//TODO: Do Nothing not expected state
				}
				else if(task.getstate().compareTo(Constants.TaskState.HOLD) == 0)
				{//change state hold from server just update
					Case job = mtaskMgr.CreateCase(task,Constants.TaskState.HOLD,Constants.yesno.No);
					if(taskSource.updateTask(job) > 0) //affected rows
					{
						mtaskMgr.UpdateExistingTask(task);
					}
					dataSetModify = true;
				}
				else if(task.getstate().compareTo(Constants.TaskState.WELCOME) == 0)
				{
					//TODO: Do Nothing not expected state
				}
			}
			mLastError.setError("0");
			sendLastError();
			if(dataSetModify == true)
			{
				adapter.notifyDataSetChanged();
				dataSetModify = false;
			}
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in onGetTaskList "+ ex.getMessage());
		}
	}

	public void onGetNewUI(String response,String cCategory)
	{
		try
		{
			int err = mdyxmlObj.onUIUpdate(response, cCategory);
			if(err == 0)
			{
				Toast.makeText(activity, "New UI updated", Toast.LENGTH_SHORT).show();
				mLastError.setError("0");
				sendLastError();
			}
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in onGetNewUI "+ ex.getMessage());
		}
	}

	public void onRecLocation(String response)
	{
		try
		{
			Status errStatus = new Status();
			errStatus.UnMarshall(response);
			if(errStatus.geterrorString() == null)
				errStatus.seterrorString(response);
			//Toast.makeText(this, errStatus.geterrorString(), Toast.LENGTH_LONG).show();
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in onRecLocation "+ ex.getMessage());
		}
	}

	class IncomingHandler extends Handler 
	{
		@Override
		public void handleMessage(Message msg) 
		{
			try
			{
				switch (msg.what) 
				{
				case Constants.serverMessage.UPDATE_ON_SERVER:
				{
					String message = msg.obj.toString();
					if(message.equals(Constants.serverUpdateType.taskList) == true)
					{
						//Toast.makeText(activity, "Task List Update", Toast.LENGTH_SHORT).show();
						onTaskListUpdate();
					}/*
					else if(message.equals(Constants.serverUpdateType.uiUpdate) == true)
					{
						onUIUpdate();	
					}*/
					else if(message.equals(Constants.serverUpdateType.uiInd) == true)
					{
						onUIUpdate("I");	
					}
					else if(message.equals(Constants.serverUpdateType.uiSME) == true)
					{
						onUIUpdate("S");	
					}
					else if(message.equals(Constants.serverUpdateType.uiCOCP) == true)
					{
						onUIUpdate("C");	
					}
				}
				break;
				case Constants.serverMessage.NOUPDATE_ON_SERVER:
				{
					mGpsLocator1 = new GpsLocator(activity,GpsTask);
					mGpsLocator1.sendEvent();

					sendLocation();
				}
				break;
				default:
					super.handleMessage(msg);
					break;
				}
			}
			catch(Exception ex)
			{
				Log.e(TAG,"Exception in handleMessage " + ex.getMessage());
			}
		}
	}

	public void sendLastError()
	{
		try
		{
			if(isNetworkAvailable() == true)
			{
				String lastErrorURI = Constants.URI.ServerURL+ Constants.URI.lastError;
				RestClient restClient = new RestClient(lastErrorURI);
				restClient.addHeader("Accept", "application/xml");
				restClient.addHeader("Content-type", "application/xml");
				if(mLastError == null) return;
				String xString = mLastError.Marshall();
				restClient.setEntityString(xString);
				AsyncExecute asyn = new AsyncExecute(activity,request.ERROR,RestClient.POST,restClient);
				asyn.execute("","");
			}
			else
			{
				Toast.makeText(activity, "Network is not available", Toast.LENGTH_LONG).show();
			}
			mLastError = null;
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in sendLastError "+ ex.getMessage());
		}
	}

	public void sendLocation()
	{
		try
		{
			if(isNetworkAvailable() == true)
			{

				String locationURI = Constants.URI.ServerURL+ Constants.URI.location;
				RestClient restClient = new RestClient(locationURI);
				restClient.addHeader("Accept", "application/xml");
				restClient.addHeader("Content-type", "application/xml");
				restClient.addHeader("Latitude",GpsTask.getLatitude());
				restClient.addHeader("Longitude",GpsTask.getLongitude());
				restClient.addHeader("Accuracy",GpsTask.getAccuracy());
				
				java.util.Date date= new java.util.Date();
				String timets = ""+date.getTime();
				mLastError = new LastError(mtaskMgr.mUserId,serverUpdateType.location,timets,"");
				mLastError.setError("0");
				String xString = mLastError.Marshall();
				restClient.setEntityString(xString);
				AsyncExecute asyn = new AsyncExecute(activity,request.NO_UPDATE,RestClient.POST,restClient);
				asyn.execute("","");
			}
			else
			{
				Toast.makeText(activity, "Network is not available", Toast.LENGTH_LONG).show();
			}
			mLastError = null;
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in sendLocation "+ ex.getMessage());
		}
	}

	public void onTaskListUpdate()
	{
		try
		{
			String taskListURI = Constants.URI.ServerURL + Constants.URI.taskList;
			RestClient restClient = new RestClient(taskListURI);
			restClient.addHeader("Accept", "application/xml");
			java.util.Date date= new java.util.Date();
			String timets = ""+date.getTime();
			restClient.addParam("timeStamp", timets);
			restClient.addParam("userId",mtaskMgr.mUserId);
			AsyncExecute asyn = new AsyncExecute(activity,request.TASKLIST_UPDATE,RestClient.GET,restClient);
			asyn.execute("","");
			mLastError = new LastError(mtaskMgr.mUserId,serverUpdateType.taskList,timets,"");
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in onTaskListUpdate "+ ex.getMessage());
		}
	}

	public void onUIUpdate(String cCategory)
	{
		try
		{
			String UIUpdateURI = Constants.URI.ServerURL + Constants.URI.getNewUI;
			RestClient restClient = new RestClient(UIUpdateURI);
			restClient.addHeader("Accept", "application/xml");
			java.util.Date date= new java.util.Date();
			String timets = ""+date.getTime();
			restClient.addParam("timeStamp", timets);
			restClient.addParam("userId",mtaskMgr.mUserId);
			restClient.addParam("uiCategory", cCategory);
			AsyncExecute asyn = null;
			if(cCategory.toUpperCase() == "I")
			{
				asyn = new AsyncExecute(activity,request.UI_INS,RestClient.GET,restClient);
			}
			else if(cCategory.toUpperCase() == "S")
			{
				asyn = new AsyncExecute(activity,request.UI_SME,RestClient.GET,restClient);
			}
			else if(cCategory.toUpperCase() == "C")
			{
				asyn = new AsyncExecute(activity,request.UI_COSP,RestClient.GET,restClient);
			}
			asyn.execute("","");
			mLastError = new LastError(mtaskMgr.mUserId,serverUpdateType.uiUpdate,timets,"");
		}
		catch(Exception ex)
		{
			Log.e(TAG,"Exception in onUIUpdate "+ ex.getMessage());
		}
	}

	@Override
	public void onBackPressed() 
	{
		return; //don't allow back button
	}

	private void takePic() {
	    Intent cameraIntent = new Intent(
	            android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
/*	    File photo= new File(workingDir,currImagefilePath.m_currentImagePath);
	    cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(photo));*/
	    startActivityForResult(cameraIntent, 2);
	}

	public void onActivityResult(int requestCode, int resultCode, Intent data) {
	if (requestCode == 2 && resultCode != 0) {
	            Bitmap Bitmapphoto = (Bitmap) data.getExtras().get("data");
	            String path = workingDir;
			    File photo= new File(path,currImagefilePath.m_currentImagePath);
			    if(photo.exists())photo.delete();
	            try {
	                FileOutputStream out = new FileOutputStream(photo);
	                Bitmapphoto.compress(Bitmap.CompressFormat.JPEG, 100, out);
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	        }
	    }

}

