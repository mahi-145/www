<?php
$Con = mysql_connect("localhost","root","");
$Db = mysql_select_db("demo",$Con);

$name = $_POST['Name'];
$phone = $_POST['Phone'];
$add = $_POST['Address'];
$city = $_POST['City'];

if($_POST['Save'])
{
	$Ins = "insert into user set name='$name',phone='$phone',address='$add',city='$city'";
	$rsc = mysql_query($Ins);
	header("location:test.php?msg=succ");
}

$Select = "select * from user";
$Rsc  = mysql_query($Select);
//$Data = mysql_fetch_array($Rsc);
//print_r($Data);
//save("user",$_POST['frm']);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Test</title>
</head>

<body>
<form name="frm" method="post" action="test1.php">

<table cellpadding="0" cellspacing="0">
<tr>
	<td>Name</td>
	<td><input type="text" name="Name" value="" required=yes/></td>
</tr>
<tr>
	<td>Phone</td>
	<td><input type="text" name="Phone" value=""/></td>
</tr>
<tr>
	<td>Address</td>
	<td><input type="text" name="Address" value=""/></td>
</tr>
<tr>
	<td>City</td>
	<td><input type="text" name="City" value=""/></td>
</tr>
<tr>
	<td></td>
	<td><input type="submit" name="Save" value="Save"/></td>
</tr>

</table>
</form>

<table border="1">
<tr>
	<td>Name</td>
	<td>Phone</td>
	<td>Address</td>
	<td>City</td>
</tr>
<?php

while($Data = mysql_fetch_array($Rsc))
{
?>
<tr>
	<td><?php echo $Data['name']?></td>
	<td><?php echo $Data['phone']?></td>
	<td><?php echo $Data['address']?></td>
	<td><?php echo $Data['city']?></td>
</tr>


<?php } ?>
</table>


</body>
</html>
