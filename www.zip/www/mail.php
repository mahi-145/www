<?php
		$to = "krishnakp20@gmail.com";
		$subject = "Welcome";
		$txt = "Hello";
		$headers = "From: webmaster@abcsolutions.com \r\n";
		$a = mail($to, $subject, $txt, $headers); 	
	print_r($a);


?>