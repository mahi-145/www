<?php
$i=10;
$j=5;
echo $i+$j;
?>