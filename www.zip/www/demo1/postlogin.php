<!DOCTYPE html>
<html lang="en">

<head>
<title>about</title>
<meta charset="utf-8">    
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta name="description" content="Your description">
<meta name="keywords" content="Your keywords">
<meta name="author" content="Your name">
<!--CSS-->
<link rel="stylesheet" href="css/bootstrap.css" >
<link rel="stylesheet" href="css/style.css">

</head>
<body>
<!--header-->
<?php include("header.php");?>

<h1> Under Construction Please Wait for Sometime </h1>
<!--footer-->

<?php include("footer.php");?>

<script src="js/bootstrap.min.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>