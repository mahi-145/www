<?php
session_start();
include("check_session.php");
$Con = mysql_connect("localhost","root","");
$Db = mysql_select_db("master",$Con);

$appid = $_POST['fb_app_id'];
$appsecret = $_POST['fb_app_secret'];
$pageid = $_POST['fb_page_id'];
$email = $_POST['email'];
$password  = $_POST['password'];
$msg  = $_GET['msg'];

//print_r($_POST); 
if($_POST['Submit'])
{	
	$Ins = "insert into social_media_master set client_id='".$_SESSION['clienttid']."',fb_app_id='$appid', fb_app_secret='$appsecret', fb_page_id='$pageid', email='$email', password='$password'"; 
	$Rsc = mysql_query($Ins);
	if($Rsc)
	{
	 header("location:postlogin1.php?msg=succ");
	}	
	else
	{
	 header("location:postlogin1.php?msg=unsucc");
	}
}
	

?>
<!DOCTYPE html>
<html lang="en">

<head>
<title>contact us</title>
<meta charset="utf-8">    
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta name="description" content="Your description">
<meta name="keywords" content="Your keywords">
<meta name="author" content="Your name">
<meta name = "format-detection" content = "telephone=no" />
<!--CSS-->
<link rel="stylesheet" href="css/bootstrap.css" >
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/font-awesome.css">
</head>
<body>
<!--header-->
<?php include("header.php");?>
<div class="global indent">
    <!--content-->
     <section class="formBox">
        <div class="container">
            <div class="row">
                <article class="col-lg-4 col-md-4 col-sm-4">
                    <h2>address</h2>
                    <div class="info">
                         <p>A-242,<br />
Surajmal Vihar</p>
                    <p class="title">phone</p>
                    <p> 9711443344<br>E-mail: <a href="#">abhishekwadhwa0612@live.com</a></p> 
                    </div>
                </article>
                <article class="col-lg-8 col-md-8 col-sm-8 contactBox2">
                    <h2>Information Form</h2>
<!--                    <span><?php if($msg=='succ') { echo "Sucessfully Recorded";  } else if($msg=='echeck') { echo "Email Id already exits"; }?></span>
-->		
				<form id="contact-form" name="registration-form" method="post" action="">
					    <div class="success-message">Details Recorded</div>
                        <div class="holder">
                            <div class="form-div-1 clearfix">
                                <label class="appid">
                                    <input type="text" placeholder="App ID*: (As registered)" required=yes name="fb_app_id" />
                                    <span class="empty-message">*This field is required.</span>
                            </div>
<!--                            <div class="form-div-2 clearfix">
                                <label class="email">
                                    <input type="email"  placeholder="Email*: me@example.com" required=yes name="email"/>
                                    <span class="empty-message">*This field is required.</span>
                                    <span class="error-message">*This is not a valid email.</span>                                </label>
                            </div>
-->                            <div class="form-div-3 clearfix">
                                <label class="fbappsecret">
                                    <input type="password" placeholder="App Secret*" required=yes name="fb_app_secret" />
                                    <span class="empty-message">*This field is required.</span>
                            </div>
								
                        </div>
						<div class="holder1">
						<div class="form-div-4 clearfix">
                            	<label class="pageID">
				    	             <input type="text" placeholder="Page ID*" required=yes name="fb_page_id"/>
                                    <span class="empty-message">*This field is required.</span>

                        	</div>
                        
                        	<div class="form-div-5 clearfix">
                            	<label class="designation">
                                <label class="email">
                                    <input type="email"  placeholder="Email*: me@example.com" required=yes name="email"/>
                                    <span class="empty-message">*This field is required.</span>
                                    <span class="error-message">*This is not a valid email.</span>                                </label>
                        	</div>
							<div class="form-div-6 clearfix">
                                <label class="password">
                                    <input type="password" placeholder="Password*" required=yes name="password" />
                                    <span class="empty-message">*This field is required.</span>
                                    <span class="error-message">*This is not a valid password.</span>                                </label>
                        	</div>
<!--							<div class="form-div-7 clearfix">
                            	<label class="Address1">
				    	             <input type="text" placeholder="Address Line 1*" required=yes name="Address1"/>
                                    <span class="empty-message">*This field is required.</span>
                                    <span class="error-message">*This is not a valid address.</span>                                </label>

                        	</div>
-->     <!--                   <div class="form-div-8 clearfix">
                            	<label class="Address2">
				    	             <input type="text" placeholder="Address Line 2*" required=yes name="Address2"/>
                                    <span class="empty-message">*This field is required.</span>
                                    <span class="error-message">*This is not a valid address.</span>                                </label>

                        	</div>
        -->                
           <!--             <div class="form-div-9 clearfix">
                            	<label class="State">
				    	             <input type="text" placeholder="Select State*" required=yes name="State" />
                                    <span class="empty-message">*This field is required.</span>
                                    <span class="error-message">*This is not a valid state name.</span>                                </label>

                        	</div>
                        <div class="form-div-10 clearfix">
                            	<label class="Pincode">
				    	             <input type="text" placeholder="Pincode*" required=yes name="Pincode"/>
                                    <span class="empty-message">*This field is required.</span>
                                    <span class="error-message">*This is not a valid pincode.</span>                                </label>

                        	</div>
                        
			-->			</div>
						
                        <div>
                            <input type="submit" name="Submit" value="Submit" class="btn-default btn1">
                        </div>  
                    </form>
                </article>
            </div>
        </div>
    </section>
</div>
<!--footer-->

<?php include("footer.php");?>

<script src="js/bootstrap.min.js"></script>
<script src="js/scripts.js"></script>

</body>
</html>
