<?php
session_start();
$Con = mysql_connect("localhost","root","");
$Db = mysql_select_db("master",$Con);

$cname = $_POST['CompanyName'];
$cemail = $_POST['email'];
$cpassword = $_POST['password'];
$apname = $_POST['authpersonname'];
$desig  = $_POST['designation'];
$mobile = $_POST['MobileNumber'];
$add1 = $_POST['Address1'];
$add2 = $_POST['Address2'];
$state = $_POST['State'];
$pin = $_POST['Pincode'];
$msg  = $_GET['msg'];

//print_r($_POST); 
if($_POST['Submit'])
{
	$Sele = "select * from registration where email='$cemail'";
	$sRSC = mysql_fetch_array(mysql_query($Sele));
	if($sRSC['email']=='')
	{
	$Ins = "insert into registration set companyname='$cname', email='$cemail', password='$cpassword', authPname='$apname', Designation='$desig', MobileNumber='$mobile', Address1='$add1', Address2='$add2', State='$state', Pincode='$pin'"; 
	
	$rsc = mysql_query($Ins) or die(mysql_error());

		if($rsc!='')
		{
		
		$to = $cemail;
		$subject = "Welcome";
		$txt = "Hello";
		$headers = "From: webmaster@abcsolutions.com \r\n";
		mail($to, $subject, $txt, $headers); 	
		
		header("location:contact.php?msg=succ");
		}

	}
	else
	{
	header("location:contact.php?msg=echeck");	
	}
	
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
<title>contact us</title>
<meta charset="utf-8">    
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta name="description" content="Your description">
<meta name="keywords" content="Your keywords">
<meta name="author" content="Your name">
<meta name = "format-detection" content = "telephone=no" />
<!--CSS-->
<link rel="stylesheet" href="css/bootstrap.css" >
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/font-awesome.css">
</head>
<body>
<!--header-->
<?php include("header.php");?>
<div class="global indent">
    <!--content-->
     <section class="formBox">
        <div class="container">
            <div class="row">
                <article class="col-lg-4 col-md-4 col-sm-4">
                    <h2>address</h2>
                    <div class="info">
                         <p>A-242,<br />
Surajmal Vihar</p>
                    <p class="title">phone</p>
                    <p> 9711443344<br>E-mail: <a href="#">abhishekwadhwa0612@live.com</a></p> 
                    </div>
                </article>
                <article class="col-lg-8 col-md-8 col-sm-8 contactBox2">
                    <h2>Registration Form</h2>
                    <span><?php if($msg=='succ') { echo "Sucessfuly Registered";  } else if($msg=='echeck') { echo "Email Id already exists"; }?></span>
					<form id="contact-form" name="registration-form" method="post" action="contact.php">
					    <div class="success-message">Registration form submitted.</div>
                        <div class="holder">
                            <div class="form-div-1 clearfix">
                                <label class="Company Name">
                                    <input type="text" placeholder="Company Name*: (As registered)" required=yes name="CompanyName" />
                                    <span class="empty-message">*This field is required.</span>
                                    <span class="error-message">*This is not a valid name.</span>                                </label>
                            </div>
                            <div class="form-div-2 clearfix">
                                <label class="email">
                                    <input type="email"  placeholder="Email*: me@example.com" required=yes name="email"/>
                                    <span class="empty-message">*This field is required.</span>
                                    <span class="error-message">*This is not a valid email.</span>                                </label>
                            </div>
                            <div class="form-div-3 clearfix">
                                <label class="password">
                                    <input type="password" placeholder="Password*" required=yes name="password" />
                                    <span class="empty-message">*This field is required.</span>
                                    <span class="error-message">*This is not a valid password.</span>                                </label>
                            </div>
								
                        </div>
						<div class="holder1">
						<div class="form-div-4 clearfix">
                            	<label class="authpersonname">
				    	             <input type="text" placeholder="Authorised Person Name*" required=yes name="authpersonname"/>
                                    <span class="empty-message">*This field is required.</span>
                                    <span class="error-message">*This is not a valid name.</span>                                </label>

                        	</div>
                        
                        	<div class="form-div-5 clearfix">
                            	<label class="designation">
				    	             <input type="text" placeholder="Designation"  name="designation" />
                                    <span class="empty-message">*This field is required.</span>
                                    <span class="error-message">*This is not a valid designation.</span>                                </label>
                        	</div>
							<div class="form-div-6 clearfix">
                            	<label class="MobileNumber">
				    	             <input type="text" pattern="[789][0-9]{9}" placeholder="Mobile Number* (10 digits)" required=yes name="MobileNumber"/>
                                    <span class="empty-message">*This field is required.</span>
                                    <span class="error-message">*This is not a valid number.</span>                                </label>
                        	</div>
							<div class="form-div-7 clearfix">
                            	<label class="Address1">
				    	             <input type="text" placeholder="Address Line 1*" required=yes name="Address1"/>
                                    <span class="empty-message">*This field is required.</span>
                                    <span class="error-message">*This is not a valid address.</span>                                </label>

                        	</div>
                        <div class="form-div-8 clearfix">
                            	<label class="Address2">
				    	             <input type="text" placeholder="Address Line 2*" required=yes name="Address2"/>
                                    <span class="empty-message">*This field is required.</span>
                                    <span class="error-message">*This is not a valid address.</span>                                </label>

                        	</div>
                        
                        <div class="form-div-9 clearfix">
                            	<label class="State">
				    	             <input type="text" placeholder="Select State*" required=yes name="State" />
                                    <span class="empty-message">*This field is required.</span>
                                    <span class="error-message">*This is not a valid state name.</span>                                </label>

                        	</div>
                        <div class="form-div-10 clearfix">
                            	<label class="Pincode">
				    	             <input type="text" placeholder="Pincode*" required=yes name="Pincode"/>
                                    <span class="empty-message">*This field is required.</span>
                                    <span class="error-message">*This is not a valid pincode.</span>                                </label>

                        	</div>
                        
						</div>
						
                        <div>
                            <input type="submit" name="Submit" value="Submit" class="btn-default btn1">
                        </div>  
                    </form>
                </article>
            </div>
        </div>
    </section>
</div>
<!--footer-->

<?php include("footer.php");?>

<script src="js/bootstrap.min.js"></script>
<script src="js/scripts.js"></script>

</body>
</html>
