<?php
if($_SESSION['EmailId']=='')
{
header("location:index.php");
}

?>