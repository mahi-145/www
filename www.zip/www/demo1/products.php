<?php
session_start();
include("config.php");
//include("check_session.php");

$cemail = $_POST['email'];
$cpassword = $_POST['password'];
$msg  = $_GET['msg'];

//print_r($_POST); 
if($_POST['Submit'])
{
	$Sele = "select * from registration where email='$cemail' and password='$cpassword'";
	$sRSC = mysql_fetch_array(mysql_query($Sele));
	if($sRSC['email']!='')
	{
		$_SESSION['clienttid'] = $sRSC['id'];
		$_SESSION['EmailId'] = $sRSC['email'];
		$_SESSION['cmp'] = $sRSC['companyname']; 
	header("location:postlogin1.php?msg=succ");
	}
	else
	{
	header("location:products.php?msg=unsucc");	
	}
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
<title><?php echo $title;?></title>
<meta charset="utf-8">    
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta name="description" content="Your description">
<meta name="keywords" content="Your keywords">
<meta name="author" content="Your name">
<!--CSS-->
<link rel="stylesheet" href="css/bootstrap.css" >
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/font-awesome.css">

</head>
<body>
<!--header-->
<?php include("header.php");?>
	 <span><?php if($msg=='succ') { echo "The module is Under Construction Please Wait";  } else if($msg=='unsucc') { echo "Enter valid credentials"; }?></span>

<div class="global indent">
    <!--content-->
     <section class="formBox">
        <div class="container">
            <div class="row">
                <article class="col-lg-4 col-md-4 col-sm-4">
                    <h2>address</h2>
                    <div class="info">
                         <p>A-242,<br />
Surajmal Vihar</p>
                    <p class="title">phone</p>
                    <p> 9711443344<br>E-mail: <a href="#">abhishekwadhwa0612@live.com</a></p> 
                    </div>
                </article>
				<form name="login" method="post">
				
                <article class="col-lg-8 col-md-8 col-sm-8 contactBox2">
                    <h2>Login</h2>
                        <div class="holder">
                            <div class="form-div-1 clearfix">
                                <label class="email">
                                    <input type="text" placeholder="Email*:" required=yes name="email" />
                                                                    </label>
                            </div>
                        </div>
						    <div class="form-div-3 clearfix">
                                <label class="password">
                                    <input type="password" placeholder="Password*" required=yes name="password" />
                             </label>
                            </div>
								
                        
						
						
                        <div>
                            <input type="submit" name="Submit" value="Submit" class="btn-default btn1">
                        </div>  
                    </form>
                </article>
            </div>
        </div>
    </section>
</div>


<?php include("footer.php");?>

<script src="js/bootstrap.min.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>