<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">

<head>
<title>about</title>
<meta charset="utf-8">    
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta name="description" content="Your description">
<meta name="keywords" content="Your keywords">
<meta name="author" content="Your name">
<!--CSS-->
<link rel="stylesheet" href="css/bootstrap.css" >
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/touchTouch.css">
<link rel="stylesheet" href="fonts/font-awesome.css">

</head>
<body>
<!--header-->
<?php include("header.php");?>

<div class="global indent">
    <!--content-->
    <div class="container">
        <div class="row">
            <article class="col-lg-4 col-md-4 col-sm-6 who-box">
                <h2 class="marg">about us</h2>
                    <div class="thumb-pad4">
                        <div class="thumbnail">
                            <figure><img src="img/about_pic1.jpg" alt=""></figure>
                            <div class="caption">
                                <h3></h3>
                                <p>We here at ABC solutions provide an online portal that improves company’s reputation on social media and helps you deal with client’s complaints more effectively.</p>
                                <p> </p>
                            </div>
                        </div>
                    </div>
            </article>
            <article class="col-lg-4 col-md-4 col-sm-6 history-box">
                <h2 class="marg">why choose us?</h2>
                <ul class="list6">
                    <li>
                        <h3></h3>
                        <p> 
•	<strong>Resolve problems quicker :</strong> The workflow system ensures complaints are automatically passed to the right handler, who can resolve issues faster and more efficiently.</p><p>
•	<strong>Increase customer loyalty and ultimately revenues :</strong> Delays and poor treatment can turn a minor complaint into a serious problem. Dealing properly with a complaint is little cost compared with acquiring a new customer. Reducing customer churn is also likely to increase sales and the lifelong value of customers.</p><p>
•	<strong>Respond to Users in a Timely Manner</strong></p><p>
•	<strong>Complete Conversation History -</strong> Once a Facebook profile is connected, ABC solutions remembers your conversations  and surfaces this history throughout so it’s always at your team’s fingertips.</p><p>

•<strong>	More than a Simply Reply Screen -</strong> With immediate access to conversation history and contact details every time you hit reply, ABC solutions social CRM tools help you respond quickly and personally.</p>

                    </li>
                    
                </ul>
            </article>
            <article class="col-lg-4 col-md-4 col-sm-12 trainers-box">
                <h2 class="marg">our staff</h2>
                <div class="row">
                    <article class="col-lg-6 col-md-6 col-sm-4 col-xs-6 trainerBox">
                        <figure><a href="img/img2.jpg"><img src="img/about_pic3.jpg" alt=""></a></figure>
                    </article>
                    <article class="col-lg-6 col-md-6 col-sm-4 col-xs-6 trainerBox">
                        <figure><a href="img/img3.jpg"><img src="img/about_pic4.jpg" alt=""></a></figure>
                    </article>
                    <article class="col-lg-6 col-md-6 col-sm-4 col-xs-6 trainerBox">
                        <figure><a href="img/img4.jpg"><img src="img/about_pic5.jpg" alt=""></a></figure>
                    </article>
                </div>
            </article>           
        </div>
    </div>
</div>
<!--footer-->

<?php include("footer.php");?>

<script src="js/bootstrap.min.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>