<?php
include("get_facebook_interaction.php");

$sec = "180";
header("Refresh: $sec;");

$db1=mysql_connect('localhost','root','');
mysql_select_db('master',$db1) or die('unable to connect');


$qry = "SELECT id, message, picture, sender_name, sender_id, sender_type FROM social_media_feedback WHERE social_media_type='facebook'";  
?>

<script>
//g_timer = null;

window.fbAsyncInit = function() {
FB.init({
  appId      : '1593714017305747',
  xfbml      : true,
  version    : 'v2.8'
});

//clearTimeout(g_timer);
//startTimer();
};

(function(d, s, id){
 var js, fjs = d.getElementsByTagName(s)[0];
 if (d.getElementById(id)) {return;}
 js = d.createElement(s); js.id = id;
 js.src = "//connect.facebook.net/en_US/sdk.js";
 fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
   
  
function replyPost(){
    var id=document.getElementById('messageid').value;
    var postid=document.getElementById('postid').value;
    var msg=document.getElementById('reply_post').value;
    var url="http://localhost/demo1/tamplate/get_facebook_interaction.php";
    FB.getLoginStatus(function(response) {
        if (response.status === 'connected') {
            var uid = response.authResponse.userID;
            var accessToken = response.authResponse.accessToken;
            FB.api('/'+id+'/comments?access_token='+accessToken, 'POST',{ message:msg}, function(response) {
                if (!response || response.error){
                    $("#close-post-box").trigger('click');
                    document.getElementById('messageid').value="";
                    document.getElementById('reply_post').value="";
                    $("#show-message-box").trigger('click');
                    $("#msg-text-message").text('Please login with currect email id / password.');
                }
                else if (response.status === 'not_authorized') {
                    $("#close-post-box").trigger('click');
                    document.getElementById('messageid').value="";
                    document.getElementById('reply_post').value="";
                    $("#show-message-box").trigger('click');
                    $("#msg-text-message").text('User is logged in to Facebook,but has not authenticated your app.');
                }
                else {
                    $.post(url,function(){});
                    $.post('http://localhost/demo1/tamplate/SocialMedia/update_feedback',{id:postid},function(result){
                        if(result){
                            $("#close-post-box").trigger('click');
                            document.getElementById('messageid').value="";
                            document.getElementById('reply_post').value="";
                            $("#show-message-box").trigger('click');
                            $("#msg-text-message").text('Relpy your post/comment successfully.');
                        } 
                    });
                    
                }
            });  
        }
        else{
            $("#show-message-box").trigger('click');
            $("#msg-text-message").text('Please first login then relpy your post/comment.');
        }
    });
}


   
function loginStatus(id,post_id){
    FB.getLoginStatus(function(response) {
        if (response.status === 'connected') {
           document.getElementById('messageid').value=id;
           document.getElementById('postid').value=post_id;
           $("#show-post-box").trigger('click'); 
        }
        else {
            $("#show-message-box").trigger('click');
            $("#msg-text-message").text('Please first login then relpy your post/comment.');
        }
    });
}
</script>

<a class="btn btn-primary btn-lg" id="show-message-box" data-toggle="modal" data-target=".bs-example-modal-sm"></a>
<div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
    <div class="modal-dialog modal-sm">
            <div class="modal-content">
                    <div class="modal-header">
                        <!--
                        <button type="button"  class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        -->
                    </div>
                    <div class="modal-body">
                        <p id="msg-text-message" ></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default"  data-dismiss="modal">Close</button>
                    </div>
            </div>
    </div>
</div>

<span id="show-post-box" data-toggle="modal" data-target="#sendpost"></span>
<div class="modal fade" id="sendpost"  tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="top:115px;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4  class="modal-title">Reply Post/Comment</h4>      
            </div>
            <div class="modal-body">
                <div class="panel-body detail">
                    <div class="form-group">
                        <div class="col-sm-12">
                            <textarea id="reply_post" style="width:568px;height:140px;" class="form-control" ></textarea>
                            <input type="hidden" id="messageid">
                            <input type="hidden" id="postid">
                        </div>
                    </div>
                </div>   
            </div>
            <div class="modal-footer">
                <button type="button" id="close-post-box" class="btn btn-default" data-dismiss="modal">Close</button>
                <input type="button" onClick="replyPost()"  value="Submit" class="btn-web btn">
            </div>
        </div>
    </div>
</div>

<div class="container-fluid" style="margin-top:-30px;" >
    
    <div data-widget-group="group1">     
        
        <div class="panel panel-default" id="panel-inline">
            
            <div class="panel-heading">
                <h2>VIEW User Interactions</h2>
                
                <div class="panel-ctrls"></div>
            </div>
            
             
            <div class="panel-body no-padding">
               
                <div style="float: right;margin-right: 5px;margin-left: 5px;margin-bottom: 20px;border:1px solid #021a40; border-radius: 5px;padding: 10px;" > 
                    <img style="width:40px;margin-top: -10px;" src="https://www.seeklogo.net/wp-content/uploads/2016/09/facebook-icon-preview-200x200.png" ><br/>
                    <input style="width:200px;" onClick="return select();" type="text" value="<?php echo $smd['SocialMediaMaster']['email'];?>" ><br/><br/>
                    <input style="width:200px;" onClick="return select();" type="text" value="<?php echo $smd['SocialMediaMaster']['password'];?>" ><br/><br/>
                    <div onClick="createLogin('<?php echo $smd['SocialMediaMaster']['email'];?>','<?php echo $smd['SocialMediaMaster']['password'];?>')" scope="read_page_mailboxes, email, manage_pages, publish_pages, business_management, publish_actions, public_profile" class="fb-login-button" data-max-rows="1" data-size="large" data-show-faces="false" data-auto-logout-link="true"  ></div>
                    <div class="fb-messengermessageus" 
                         messenger_app_id="338410216544282" 
                         page_id="966700836763959" 
                         color="blue"
                         size="large">
                    </div>
                    
                </div>
 
                <div style="height:665px;overflow:scroll;">
                <table  cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered datatables" >
                    <thead>
                        <tr>
                            <!--<th>S.N</th>-->
                            <th>Media</th>
                            <th>Type</th>
                            <th>Message</th>
                            <th>Sender</th>
                            <th>Time</th>
                            <th>Status</th>
                            <th>ACTION</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1;foreach($data as $row){?>
                            <tr>
                                <!--<td><?php echo $i++;?></td>-->
                                <td><?php echo $row['SocialMediaFeedback']['social_media_type'];?></td>
                                <td><?php echo $row['SocialMediaFeedback']['sender_type'];?></td>
                                <td>
                                    <?php if($row['SocialMediaFeedback']['picture'] !=""){?>
                                    <img src="<?php echo $row['SocialMediaFeedback']['picture'];?>" style="width:200px;" ><br/><br/>
                                    <?php }?>
                                    <?php echo $row['SocialMediaFeedback']['message'];?>
                                </td>
                                
                                <td><?php echo $row['SocialMediaFeedback']['sender_name'];?></td>
                                <td>
                                    <?php
                                    $timestamp = strtotime($row['SocialMediaFeedback']['sender_time']);
                                    echo date("l jS M Y g:ia", $timestamp);
                                    ?>
                                </td>
                                <td><?php if($smd['SocialMediaMaster']['fb_uid'] !=$row['SocialMediaFeedback']['sender_id']){ echo $row['SocialMediaFeedback']['status'];}else{?><i class="material-icons">arrow_forward</i><?php }?></td>
                                <td class="center">
                                    <?php if($smd['SocialMediaMaster']['fb_uid'] !=$row['SocialMediaFeedback']['sender_id']){ ?>
                                    <a title="Reply Post/Comment" onClick="loginStatus('<?php echo $row['SocialMediaFeedback']['message_id'];?>','<?php echo $row['SocialMediaFeedback']['id'];?>')"   href="#">
                                        <label class="btn btn-xs tn-midnightblue btn-raised"><i class="fa fa-send"></i></label>
                                    </a>
                                    <?php }else{?>
                                    <!--<i class="material-icons">arrow_back</i>-->
                                    <?php }?>
                                </td>  
                            </tr>
                        <?php }?>

                    </tbody>
                </table>
                <div>
            </div>
            <div class="panel-footer"></div>
        </div>
    </div>
</div>




