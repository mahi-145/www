<?php 

$db1=mysql_connect('localhost','root','');
mysql_select_db('master',$db1) or die('unable to connect');

$Complaint = $_GET['SenderId'];

$qry = "SELECT *,SUBSTRING_INDEX(`message_id`,'_',-1) MessageId FROM `social_media_feedback` WHERE SUBSTRING_INDEX(`message_id`,'_',1)='$Complaint'";  

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Table Editabel Theme</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="description" content="">

    <link rel="shortcut icon" href="assets/img/logo_abc.png">

 	<!--<link type='text/css' href='http://fonts.googleapis.com/css?family=Roboto:300,400,400italic,500' rel='stylesheet'>
     <link type='text/css'href="https://fonts.googleapis.com/icon?family=Material+Icons"  rel="stylesheet"> -->
  

   <link href="assets/material-design-iconic-font/css/material-icon.css" rel="stylesheet">
   <link href="assets/fonts/font-awesome/css/font-awesome.min.css" rel="stylesheet">                        <!-- Font Awesome -->
   <link href="assets/css/styles.css" type="text/css" rel="stylesheet">                                     <!-- Core CSS with all styles -->

   <link href="assets/plugins/codeprettifier/prettify.css" type="text/css" rel="stylesheet">                <!-- Code Prettifier -->

    <link href="assets/plugins/dropdown.js/jquery.dropdown.css" type="text/css" rel="stylesheet">            <!-- iCheck -->
    <link href="assets/plugins/progress-skylo/skylo.css" type="text/css" rel="stylesheet">                   <!-- Skylo -->

    <!--[if lt IE 10]>
        <script src="assets/js/media.match.min.js"></script>
        <script src="assets/js/respond.min.js"></script>
        <script src="assets/js/placeholder.min.js"></script>
    <![endif]-->
    <!-- The following CSS are included as plugins and can be removed if unused-->
    
<link href="assets/plugins/datatables/dataTables.bootstrap.css" type="text/css" rel="stylesheet">                    <!-- Bootstrap Support for Datatables -->
<link href="assets/plugins/datatables/dataTables.themify.css" type="text/css" rel="stylesheet">          

    </head>

    <body class="animated-content infobar-overlay">
        

                <div class="static-content-wrapper">
                    <div class="static-content">
                        <div class="page-content">
                            <ol class="breadcrumb">
                                
<li><a href="index.html">Home</a></li>
<li><a href="#">Advanced Tables</a></li>
<li class="active"><a href="tables-editable.html">Feedbacks</a></li>
                            </ol>
                            <div class="page-heading">            
                               
                               <h1>Feedbacks</h1>
                           </div>
                            <div class="container-fluid">
                                
<div data-widget-group="group1">
            </div>      
                    <form name="frm" method="post">
                    <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered datatables" >
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>Message</th>
								<th>Sender name</th>
                                <th>Sender ID</th>
                                <th>Sender type</th>
								<th> 			</th>
                            </tr>
                        </thead>
                        <tbody>
                            
						<?php 
						$str= mysql_query($qry);
						$row= $str;
						$i=1;
						while($data= mysql_fetch_array($row))
						{
						
						?>
							<tr>						
                                <td><?php echo $data['id'] ?></td>
                                <td><?php if($data['picture']!='') {echo wordwrap($data['message'],40,"<br>") ."<img src=".$data['picture']." height\"100px\" width=\"100\">"; } else { echo wordwrap($data['message'],30,"<br>"); }?></td>
                                <td><?php echo $data['sender_name'] ?></td>
                                <td><?php echo $data['sender_id'] ?></td>
                                <td><?php echo $data['sender_type'] ?></td>
								<td><input type= "button" value ="reply" onClick="ShowText('<?php echo $i;?>')" /> </td>
								
								<td><?php if($data['Complaint']=='0') { ?><input type="checkbox"	value="1" name="Unresolved[<?php echo $data['id'] ?>]"> <label>Unresolved</label><?php } else { ?> <input type="checkbox"	value="1" name="Unresolved[<?php echo $data['id'] ?>]" disabled="disabled" checked="checked"> <label>Resolved</label> <?php } ?><input type="submit" name="Update" value="Update"> <input type="submit" name="Comments" value="Comments"</td>

                            </tr>
							<?php $i++; } ?>
							
							
                        </tbody>
                    </table>
					</form><!--end table-->
                </div>
               
            </div>
        </div>
    </div>

    </body>
</html>