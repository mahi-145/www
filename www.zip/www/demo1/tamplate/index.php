<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>DialDesk Admin Theme</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="description" content="">

    <link rel="shortcut icon" href="assets/img/logo-icon-dark.png">

 	<!--<link type='text/css' href='http://fonts.googleapis.com/css?family=Roboto:300,400,400italic,500' rel='stylesheet'>
     <link type='text/css'href="https://fonts.googleapis.com/icon?family=Material+Icons"  rel="stylesheet"> -->
  

    <link href="assets/material-design-iconic-font/css/material-icon.css" rel="stylesheet">
    <link href="assets/fonts/font-awesome/css/font-awesome.min.css" rel="stylesheet">        <!-- Font Awesome -->
    <link href="assets/css/styles.css" type="text/css" rel="stylesheet">                                     <!-- Core CSS with all styles -->

    <link href="assets/plugins/codeprettifier/prettify.css" type="text/css" rel="stylesheet">                <!-- Code Prettifier -->
     <link href="assets/plugins/dropdown.js/jquery.dropdown.css" type="text/css" rel="stylesheet">            <!-- iCheck -->
    <link href="assets/plugins/progress-skylo/skylo.css" type="text/css" rel="stylesheet">                   <!-- Skylo -->

    <!--[if lt IE 10]>
        <script src="assets/js/media.match.min.js"></script>
        <script src="assets/js/respond.min.js"></script>
        <script src="assets/js/placeholder.min.js"></script>
    <![endif]-->
    <!-- The following CSS are included as plugins and can be removed if unused-->
    
<link href="assets/plugins/form-daterangepicker/daterangepicker-bs3.css" type="text/css" rel="stylesheet">    <!-- DateRangePicker -->
<link href="assets/plugins/fullcalendar/fullcalendar.css" type="text/css" rel="stylesheet">                   <!-- FullCalendar -->
<link href="assets/plugins/jvectormap/jquery-jvectormap-2.0.2.css" type="text/css" rel="stylesheet">
<link href="assets/less/card.less" type="text/css" rel="stylesheet"> 

<link href="assets/plugins/chartist/dist/chartist.min.css" type="text/css" rel="stylesheet"> <!-- chartist -->
    </head>

    <body class="animated-content infobar-overlay sidebar-scroll">
        
        
<header id="topnav" class="navbar navbar-bleachedcedar navbar-fixed-top" role="banner">
	<!-- <div id="page-progress-loader" class="show"></div> -->

	<div class="logo-area">
		<a class="navbar-brand navbar-brand-default" href="index.html">
			<img class="show-on-collapse img-logo-white" alt="Paper" src="assets/img/logo-icon-white.png">
			<img class="show-on-collapse img-logo-dark" alt="Paper" src="assets/img/out.png">
			<img class="img-white" alt="Paper" src="assets/img/logo.png">
			<img class="img-dark" alt="ShortTermIncomeFund" src="assets/img/logo_abc.png">		</a>

		<span id="trigger-sidebar" class="toolbar-trigger toolbar-icon-bg stay-on-search">
			<a data-toggle="tooltips" data-placement="right" title="Toggle Sidebar">
				<span class="icon-bg">
					<i class="material-icons">menu</i>				</span>			</a>		</span>
		<!--<span id="trigger-search" class="toolbar-trigger toolbar-icon-bg ov-h">
			<a data-toggle="tooltips" data-placement="right" title="Toggle Sidebar">
				<span class="icon-bg">
					<i class="material-icons">search</i>
				</span>
			</a>
		</span>
		<div id="search-box">
			<input class="form-control" type="text" placeholder="Search..." id="search-input"></input>
		</div> -->
	</div><!-- logo-area -->


<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.8&appId=1593714017305747";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>



	<ul class="nav navbar-nav toolbar pull-right">

		<li class="toolbar-icon-bg appear-on-search ov-h" id="trigger-search-close">
	        <a class="toggle-fullscreen"><span class="icon-bg">
	        	<i class="material-icons">close</i>
	        </span></i></a>	    </li>
		<li class="toolbar-icon-bg hidden-xs" id="trigger-fullscreen">
	        <a href="#" class="toggle-fullscreen"><span class="icon-bg">
	        	<i class="material-icons">fullscreen</i>
	        </span></i></a>	    </li>

   		<li class="dropdown toolbar-icon-bg">
			<a href="#" class="hasnotifications dropdown-toggle" data-toggle='dropdown'><span class="icon-bg"><i class="material-icons">notifications</i></span><span class="badge badge-info"></span></a>
			<div class="dropdown-menu animated notifications">
				<div class="topnav-dropdown-header">
					<span>3 new notifications</span>				</div>
				<div class="scroll-pane">
					<ul class="media-list scroll-content">
						<li class="media notification-success">
							<a href="#">
								<div class="media-left">
									<span class="notification-icon"><i class="material-icons">lock</i></span>								</div>
								<div class="media-body">
									<h4 class="notification-heading">Privacy settings have been changed.</h4>
									<span class="notification-time">8 mins ago</span>								</div>
							</a>						</li>
						<li class="media notification-info">
							<a href="#">
								<div class="media-left">
									<span class="notification-icon"><i class="material-icons">shopping_cart</i></span>								</div>
								<div class="media-body">
									<h4 class="notification-heading">A new order has been placed.</h4>
									<span class="notification-time">24 mins ago</span>								</div>
							</a>						</li>
						<li class="media notification-teal">
							<a href="#">
								<div class="media-left">
									<span class="notification-icon"><i class="material-icons">perm_contact_calendar</i></span>								</div>
								<div class="media-body">
									<h4 class="notification-heading">New event started!</h4>
									<span class="notification-time">16 hours ago</span>								</div>
							</a>						</li>
						<li class="media notification-indigo">
							<a href="#">
								<div class="media-left">
									<span class="notification-icon"><i class="material-icons">settings</i></i></span>								</div>
								<div class="media-body">
									<h4 class="notification-heading">New app settings updated.</h4>
									<span class="notification-time">2 days ago</span>								</div>
							</a>						</li>
						<li class="media notification-danger">
							<a href="#">
								<div class="media-left">
									<span class="notification-icon"><i class="material-icons">comment</i></span>								</div>
								<div class="media-body">
									<h4 class="notification-heading">Jessi commented your post.</h4>
									<span class="notification-time">4 days ago</span>								</div>
							</a>						</li>
					</ul>
				</div>
				<div class="topnav-dropdown-footer">
					<a href="#">See all notifications</a>				</div>
			</div>
		</li>

        <li class="dropdown toolbar-icon-bg hidden-xs">
			<a href="#" class="hasnotifications dropdown-toggle" data-toggle='dropdown'><span class="icon-bg"><i class="material-icons">mail</i></span><span
			class="badge badge-info"></span></a>
			<div class="dropdown-menu animated notifications">
				<div class="topnav-dropdown-header">
					<span>2 new messages</span>				</div>
				<div class="scroll-pane">
					<ul class="media-list scroll-content">
						<li class="media notification-message">
							<a href="#">
								<div class="media-left">
									<img class="img-circle avatar" src="assets/demo/avatar/avatar_01.png" alt="" />								</div>
								<div class="media-body">
									<h4 class="notification-heading"><strong>Amy Green</strong> <span class="text-gray">‒ Integer vitae libero ac risus egestas placerat.</span></h4>
									<span class="notification-time">2 mins ago</span>								</div>
							</a>						</li>
						<li class="media notification-message">
							<a href="#">
								<div class="media-left">
									<img class="img-circle avatar" src="assets/demo/avatar/avatar_09.png" alt="" />								</div>
								<div class="media-body">
									<h4 class="notification-heading"><strong>Daniel Andrews</strong> <span class="text-gray">‒ Vestibulum commodo felis quis tortor</span></h4>
									<span class="notification-time">40 mins ago</span>								</div>
							</a>						</li>
						<li class="media notification-message">
							<a href="#">
								<div class="media-left">
									<img class="img-circle avatar" src="assets/demo/avatar/avatar_02.png" alt="" />								</div>
								<div class="media-body">
									<h4 class="notification-heading"><strong>Jane Simpson</strong> <span class="text-gray">‒ Fusce lobortis lorem at ipsum semper sagittis.</span></h4>
									<span class="notification-time">6 hours ago</span>								</div>
							</a>						</li>
						<li class="media notification-message">
							<a href="#">
								<div class="media-left">
									<img class="img-circle avatar" src="assets/demo/avatar/avatar_03.png" alt="" />								</div>
								<div class="media-body">
									<h4 class="notification-heading"><strong>Harold Hawkins</strong> <span class="text-gray">‒ Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</span></h4>
									<span class="notification-time">8 days ago</span>								</div>
							</a>						</li>
						<li class="media notification-message">
							<a href="#">
								<div class="media-left">
									<img class="img-circle avatar" src="assets/demo/avatar/avatar_04.png" alt="" />								</div>
								<div class="media-body">
									<h4 class="notification-heading"><strong>Brian Fisher</strong> <span class="text-gray">‒ Praesent dapibus, neque id cursus faucibus.</span></h4>
									<span class="notification-time">16 hours ago</span>								</div>
							</a>						</li>
						<li class="media notification-message">
							<a href="#">
								<div class="media-left">
									<img class="img-circle avatar" src="assets/demo/avatar/avatar_05.png" alt="" />								</div>
								<div class="media-body">
									<h4 class="notification-heading"><strong>Dylan Black</strong> <span class="text-gray">‒ Pellentesque fermentum dolor. </span></h4>
									<span class="notification-time">2 days ago</span>								</div>
							</a>						</li>
						<li class="media notification-message">
							<a href="#">
								<div class="media-left">
									<img class="img-circle avatar" src="assets/demo/avatar/avatar_06.png" alt="" />								</div>
								<div class="media-body">
									<h4 class="notification-heading"><strong>Bobby Harper</strong> <span class="text-gray">‒ Sed adipiscing ornare risus. Morbi est est.</span></h4>
									<span class="notification-time">4 days ago</span>								</div>
							</a>						</li>
					</ul>
				</div>
				<div class="topnav-dropdown-footer">
					<a href="#">See all messages</a>				</div>
			</div>
		</li>

		<li class="toolbar-icon-bg" id="trigger-infobar">
			<a data-toggle="tooltips" data-placement="right" title="Toggle Sidebar">
				<span class="icon-bg">
					<i class="material-icons">more_vert</i>				</span>			</a>		</li>
	</ul>
</header>

        <div id="wrapper">
            <div id="layout-static">
                <div class="static-sidebar-wrapper sidebar-bleachedcedar">
                    <div class="static-sidebar">
                        <div class="sidebar">
	
	<div class="widget stay-on-collapse" id="widget-sidebar">
        <nav role="navigation" class="widget-body">
	<ul class="acc-menu">
		<li class="nav-separator"><span>Navigation</span></li>
		<li><a  class="withripple" href="index.php"><span class="icon">
		<i class="material-icons">home</i></span><span>Dashboard</span><span class="badge badge-teal"></span></a></li>
		<li><a  class="withripple" href="javascript:;"><span class="icon"><i class="fa fa-user"></i></span><span>Client Management</span></a>
			<ul class="acc-menu">
				<li><a  class="withripple" href="crm.php">CRM</a></li>
				<li><a  class="withripple" href="#">Choose Service Plan</a></li>
				<li><a  class="withripple" href="#">Process Registration</a></li>
				<li><a  class="withripple" href="#">ECR Creation</a></li>	
			</ul>
		</li>

		<li><a  class="withripple" href="javascript:;"><span class="icon"><i class="material-icons">settings</i></span><span>Client Operations</span></a>
			<ul class="acc-menu">
				<li><a  class="withripple" href="message-list.php">Facebook</a></li>
				<li><a  class="withripple" href="#">Link 1</a></li>
			</ul>
		</li>

        <li><a  class="withripple" href="javascript:;"><span class="icon"><i class="fa fa-headphones"></i></span><span>Agent Calling</span></a>
        	<ul class="acc-menu">
        		<!--<li><a  class="withripple" href="#">New</a></li>-->
				<li><a  class="withripple" href="message-list-unresolve.php">Unresolved</a></li>
        		<li><a  class="withripple" href="message-list-resolve.php">Resolved</a></li>
        	</ul>
        </li>
      
	</ul>
</nav>
    </div>
</div>
                    </div>
                </div>
                <div class="static-content-wrapper">
                    <div class="static-content">
                        <div class="page-content">
                            <ol class="breadcrumb">
                                
<li class=""><a href="index.html">Home</a></li>
<li class="active"><a href="index.html">Dashboard</a></li>
                            </ol>
                            <div class="page-heading">            
                               <h1>Dashboard<small>Project Statistics</small></h1>
                               <div class="options">
   <!--  <div class="btn-toolbar">
        <form action="" class="form-horizontal row-border" style="display: inline-block;">
            <div class="form-group hidden-xs">
                <div class="col-sm-8">
                    <button class="btn btn-default" id="daterangepicker-d">
                        <i class="fa fa-calendar"></i> 
                        <span>February 17, 2016 - March 18, 2016</span> <b class="caret"></b>
                    </button>
                </div>
            </div>
        </form>
        <a href="#" class="btn btn-default" style="vertical-align: top;">Settings</a>
    </div> -->
</div>
                           </div>
                            <div class="container-fluid">
                                

<div data-widget-group="group1">
    <div class="row">

        <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <div class="info-tile info-tile-alt tile-indigo">
                <div class="info">
                    <div class="tile-heading"><span>Page Likes</span></div>
                    <div class="tile-body"><span><div class="fb-like" data-href="https://www.facebook.com/impossible-is-nothing-114524245233780/" data-width="40" data-layout="box_count" data-action="recommend" data-size="large" data-show-faces="true" data-share="false"></div></span></div>
                </div>
                <div class="stats">
                    <div class="tile-content"><div id="dashboard-sparkline-indigo"></div></div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <div class="info-tile info-tile-alt tile-danger">
                <div class="info">
                    <div class="tile-heading"><span>Followers</span></div>
                    <div class="tile-body "><span><div class="fb-follow" data-href="https://www.facebook.com/impossible-is-nothing-114524245233780/" data-layout="box_count" data-size="large" data-show-faces="false"></div></span></div>
                </div>
                <div class="stats">
                    <div class="tile-content"><div id="dashboard-sparkline-gray"></div></div>
                </div>
            </div>
        </div>
<!--        <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <div class="info-tile info-tile-alt tile-primary">
                <div class="info">
                    <div class="tile-heading"><span>Conversions</span></div>
                    <div class="tile-body "><span>1,032</span></div>
                </div>
                <div class="stats">
                    <div class="tile-content"><div id="dashboard-sparkline-primary"></div></div>
                </div>
            </div>
        </div>
-->       
<!-- <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <div class="info-tile info-tile-alt tile-success clearfix">
                <div class="info">
                    <div class="tile-heading"><span>Returning</span></div>
                    <div class="tile-body "><span>1,454</span></div>
                </div>
                <div class="stats">
                    <div class="tile-content"><div id="dashboard-sparkline-success"></div></div>
                </div>
            </div>
        </div>
    </div>
-->
    <div class="row">
        <div class="col-md-12 full-width">
            <div class="panel panel-default no-shadow" data-widget='{"draggable": "false"}'>
                <div class="panel-controls dropdown">
                    <button class="btn btn-icon-rounded refresh-panel"><span class="material-icons inverted">refresh</span></button>
                    <button class="btn btn-icon-rounded dropdown-toggle" data-toggle="dropdown"><span class="material-icons inverted">more_vert</span></button>
                    <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Action</a></li>
                        <li><a href="#">Another action</a></li>
                        <li><a href="#">Something else here</a></li>
                        <li class="divider"></li>
                        <li><a href="#">Separated link</a></li>
                    </ul>
                </div>
                <div class="panel-body">
                   <div class="pb-md">
                        <h4 class="mb-n">Like Vs Follow STATISTICS<small>Like and follow stats</small></h4>
                    </div>
                    <div id="fullChart" style="height: 325px " class="centered"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row ">
        <div class="col-md-3 col-sm-6">
            <div class="panel panel-white ov-h" data-widget='{"draggable": "false"}'>
                <div class="panel-controls dropdown">
                    <button class="btn btn-icon-rounded dropdown-toggle" data-toggle="dropdown"><span class="material-icons inverted">more_vert</span></button>
                    <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Action</a></li>
                        <li><a href="#">Another action</a></li>
                        <li><a href="#">Something else here</a></li>
                        <li class="divider"></li>
                        <li><a href="#">Separated link</a></li>
                    </ul>
                </div>
                <div class="panel-heading">
                    <h2>Visitors</h2>
                </div>
                <div class="panel-body ov-h">
                    <div id="areaChart"></div>
                    <div class="pt-md pull-left">
                        <h4 class="mt-n mb-n pt-xs"><small class="mt-n mb-sm">Page views</small>424,121</h4>
                    </div>
                    <div class="pt-md pull-right text-right">
                        <h4 class="mt-n mb-n pt-xs"><small class="mt-n mb-sm">Visitors</small>341</h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="panel panel-white">
                <div class="panel-controls dropdown">
                    <button class="btn btn-icon-rounded dropdown-toggle" data-toggle="dropdown"><span class="material-icons inverted">more_vert</span></button>
                    <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Action</a></li>
                        <li><a href="#">Another action</a></li>
                        <li><a href="#">Something else here</a></li>
                        <li class="divider"></li>
                        <li><a href="#">Separated link</a></li>
                    </ul>
                </div>
                <div class="panel-heading">
                    <h2>Revenue</h2>
                </div>
                <div class="panel-body">
                        <div id="chartistPie"></div>
                    <div class="pt-md pull-left">
                    <h4 class="mt-n mb-n pt-xs"><small class="mt-n mb-sm">Primary</small>416 M</h4>
                    </div>
                    <div class="pt-md pull-right text-right">
                        <h4 class="mt-n mb-n pt-xs"><small class="mt-n mb-sm">Commissions</small>320 K</h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">

            <div class="panel panel-salesfigure">
                <div class="panel-controls dropdown">
                    <div class="togglebutton toggle-info">
                        <label>
                            <input type="checkbox" checked="">
                        </label>
                    </div>
                </div>
                
                <div class="panel-heading">
                    <h2>Markup</h2>
                </div>
                <div class="panel-body">
                    <div class="full-bg">
                        <div class="easypiechart" id="chart1" data-percent="65">
                            <span class="percent percent-big"></span>                        </div>
                    </div>
                    <div class="pt-md pull-left">
                        <h4 class="mt-n mb-n pt-xs"><small class="mt-n mb-sm">Cost of Goods</small>15%</h4>
                    </div>
                    <div class="pt-md pull-right text-right">
                        <h4 class="mt-n mb-n pt-xs"><small class="mt-n mb-sm">Net</small>32%</h4>
                    </div>
                </div>
            </div>
        </div> 
        <div class="col-md-3 col-sm-6">
            <div class="panel panel-salesfigure2">
                <div class="panel-controls dropdown">
                    <div class="togglebutton toggle-warning">
                        <label>
                            <input type="checkbox" checked="">
                        </label>
                    </div>
                </div>
                <div class="panel-heading">
                    <h2>Total Products</h2>
                </div>
                <div class="panel-body">
                    <div id="dailysales2" class="text-center mt mb"></div>
                    <div class="pt-md pull-left">
                        <h4 class="mt-n mb-n pt-xs"><small class="mt-n mb-sm">Active Listings</small>4,986</h4>
                    </div>
                    <div class="pt-md pull-right text-right">
                        <h4 class="mt-n mb-n pt-xs"><small class="mt-n mb-sm">Categories</small>950</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>

<div class="row">
    <div class="col-md-6">
        <div class="panel">
            <div class="panel-calendar">
                <div class="text-center pb-sm">
                    <span class="text block p-md">Wednesday</span>
                        <div class="text-center mt-n mb-n pt-xs ">
                            <span class="circle text-center">10</span>                        </div> 
                </div>
                <div id="calendar"></div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="panel panel-default" >
            <div class="panel-controls dropdown">
                <button class="btn btn-icon-rounded refresh-panel"><span class="material-icons inverted">refresh</span></button>
                <button class="btn btn-icon-rounded dropdown-toggle" data-toggle="dropdown"><span class="material-icons inverted">more_vert</span></button>
                <ul class="dropdown-menu" role="menu">
                    <li><a href="#">Action</a></li>
                    <li><a href="#">Another action</a></li>
                    <li><a href="#">Something else here</a></li>
                    <li class="divider"></li>
                    <li><a href="#">Separated link</a></li>
                </ul>
            </div>
            <div class="panel-body no-padding table-responsive">
                <div class="p-md">
                        <h4 class="mb-n">Calling Agents<small>Assigned to various people</small></h4>
                </div>
                <div class="list-group">
                    <div class="list-group-item withripple">
                        <div class="row-action-primary">
                            <div class="progress-pie-chart" data-percent="12.5"></div>
                        </div>
                        <div class="row-content">
                            <div class="least-content">
                                <img class="img-circle" src="assets/demo/avatar/avatar_01.png" width="16" alt="icon">
                                <img class="img-circle" src="assets/demo/avatar/avatar_02.png" width="16" alt="icon">
                                <img class="img-circle" src="assets/demo/avatar/avatar_03.png" width="16" alt="icon">                            </div>
                            <h4 class="list-group-item-heading">Tata Docomo Support</h4>
                            <p class="list-group-item-text">For selling new SIM Cards</p>
                        </div>
                    </div>
                    <div class="list-group-separator"></div>
                    <div class="list-group-item withripple">
                        <div class="row-action-primary">
                            <div class="progress-pie-chart" data-percent="22"></div>
                        </div>
                        <div class="row-content">
                            <div class="least-content">
                                <img class="img-circle" src="assets/demo/avatar/avatar_05.png" width="16" alt="icon">
                                <img class="img-circle" src="assets/demo/avatar/avatar_04.png" width="16" alt="icon">                            </div>
                            <h4 class="list-group-item-heading">Airtel New Enquiry</h4>
                            <p class="list-group-item-text">Called for confirmation</p>
                        </div>
                    </div>
                    <div class="list-group-separator"></div>
                    <div class="list-group-item withripple">
                        <div class="row-action-primary">
                            <div class="progress-pie-chart" data-percent="67"></div>
                        </div>
                        <div class="row-content">
                            <div class="least-content">
                                <img class="img-circle" src="assets/demo/avatar/avatar_03.png" width="16" alt="icon">                            </div>
                            <h4 class="list-group-item-heading">Call Dropped</h4>
                            <p class="list-group-item-text">not received calls</p>
                        </div>
                    </div>
                    <div class="list-group-separator"></div>
                    <div class="list-group-item withripple">
                        <div class="row-action-primary">
                            <div class="progress-pie-chart" data-percent="14"></div>
                        </div>
                        <div class="row-content">
                            <div class="least-content">
                                <img class="img-circle" src="assets/demo/avatar/avatar_06.png" width="16" alt="icon">
                                <img class="img-circle" src="assets/demo/avatar/avatar_07.png" width="16" alt="icon">                            </div>
                            <h4 class="list-group-item-heading">Currently On Call</h4>
                            <p class="list-group-item-text">all agents who are in call</p>
                        </div>
                    </div>
                    <div class="list-group-separator"></div>
                    <div class="list-group-item withripple">
                        <div class="row-action-primary">
                            <div class="progress-pie-chart" data-percent="33"></div>
                        </div>
                        <div class="row-content">
                            <div class="least-content">
                                <img class="img-circle" src="assets/demo/avatar/avatar_08.png" width="16" alt="icon">
                                <img class="img-circle" src="assets/demo/avatar/avatar_09.png" width="16" alt="icon">                            </div>
                            <h4 class="list-group-item-heading">Outgoing Calls</h4>
                            <p class="list-group-item-text">Latest 3 chats with agants</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
                            </div> <!-- .container-fluid -->
                        </div> <!-- #page-content -->
                    </div>
                    <footer role="contentinfo">
    <div class="clearfix">
        <ul class="list-unstyled list-inline pull-left">
            <li><h6 style="margin: 0;">&copy; 2016 DialDesk</h6></li>
        </ul>
    </div>
</footer>
                </div>
            </div>
        </div>

        <div class="infobar-wrapper scroll-pane">
            <div class="infobar scroll-content">

    
        <ul class="nav nav-tabs material-nav-tabs stretch-tabs icon-tabs">
            <li ><a href="#tab-7-1" data-toggle="tab">
                Your Profile Completion
            </a></li>
        </ul>
    

    <div class="tab-content">
        <div class="tab-pane active" id="tab-7-1">

            <table class="table table-settings ">
                <tbdody>
                    <tr>
                        <td>
                            <h5>Profile Completion</h5>
                            <p>Sets alerts to get notified when changes occur to get new alerming items</p>
                            <div class="progress">    
                                    <div style="width: 20%" class="progress-bar progress-bar-primary"></div>
                                  </div>                        </td>
                        <td><span class="text-success"><i class="material-icons">check</i></span></td>
                    </tr>
                    <tr>
                        <td>
                            <h5>Bank Account</h5>
                            <p>You have not added your bank Details</p>                        </td>
                        <td><span class="text-danger"><i class="material-icons">report_problem</i></span></td>
                    </tr>
                    <tr>
                        <td>
                            <h5>Bank Verified</h5>
                            <p>You bank account has not been verified yet</p>                        </td>
                        <td>
                            <span class="text-danger"><i class="material-icons">report_problem</i></span>                        </td>
                    </tr>
                    <tr>
                        <td>
                            <h5>Warnings</h5>
                            <p>You will get warnning only some specific setttings or alert system</p>                        </td>
                        <td>
                            <span class="togglebutton toggle-warning"><label><input type="checkbox" checked=""> </label></span>                        </td>
                    </tr>
                    <tr>
                        <td>
                            <h5>Sidebar</h5>
                            <p>You can hide/show use with sidebar collapsw settings</p>                        </td>
                        <td><span class="togglebutton toggle-success"><label><input type="checkbox" checked=""> </label></span></td>
                    </tr>
                </tbdody>
            </table>
        </div>
        <div class="tab-pane active" id="tab-7-2">

            <div class="widget">
                <div class="widget-heading">Recent Activities</div>
                <div class="widget-body">
                    <ul class="timeline">
                        <li class="timeline-purple">
                            <div class="timeline-icon"><i class="material-icons">add</i></div>
                            <div class="timeline-body">
                                <div class="timeline-header">
                                    <span class="author">Jana Pena is now Follwing you</span>
                                    <span class="date">2 min ago</span>                                </div>
                            </div>
                        </li>
                        <li class="timeline-primary">
                            <div class="timeline-icon"><i class="material-icons">textsms</i></div>
                            <div class="timeline-body">
                                <div class="timeline-header">
                                    <span class="author">Percy liaye Like your picture</span>
                                    <span class="date">6 min ago</span>                                </div>
                            </div>
                        </li>
                        <li class="timeline-green">
                            <div class="timeline-icon"><i class="material-icons">done</i></div>
                            <div class="timeline-body">
                                <div class="timeline-header">
                                    <span class="author">Leon miles make your presentation for new project</span>
                                    <span class="date">2 hours ago</span>                                </div>
                            </div>
                        </li>
                        <li class="timeline-danger">
                            <div class="timeline-icon"><i class="material-icons">favorite</i></div>
                            <div class="timeline-body">
                                <div class="timeline-header">
                                    <span class="author">Lake wile like your comment</span>
                                    <span class="date">5 hours ago</span>                                </div>
                            </div>
                        </li>
                        <li class="timeline-sky">
                            <div class="timeline-icon"><i class="material-icons">attach_money</i></div>
                            <div class="timeline-body">
                                <div class="timeline-header">
                                    <span class="author">The Mountain Ambience paid your payment</span>
                                    <span class="date">9 hours ago</span>                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="widget">
                <div class="widget-heading">Contacts</div>
                <div class="widget-body">
                    <ul class="media-list contacts">
                        <li class="media notification-message">
                            <div class="media-left">
                                <img class="img-circle avatar" src="assets/demo/avatar/avatar_01.png" alt="" />                            </div>
                            <div class="media-body">
                              <span class="text-gray">Jon Owens</span>
                                <span class="contact-status text-success">Online</span>                            </div>
                        </li>
                        <li class="media notification-message">
                            <div class="media-left">
                                <img class="img-circle avatar" src="assets/demo/avatar/avatar_02.png" alt="" />                            </div>
                            <div class="media-body">
                                <span class="text-gray">Nina Huges</span>
                                <span class="contact-status text-muted">Offline</span>                            </div>
                        </li>
                        <li class="media notification-message">
                            <div class="media-left">
                                <img class="img-circle avatar" src="assets/demo/avatar/avatar_03.png" alt="" />                            </div>
                            <div class="media-body">
                                <span class="text-gray">Austin Lee</span>
                                <span class="contact-status text-danger">Busy</span>                            </div>
                        </li>
                        <li class="media notification-message">
                            <div class="media-left">
                                <img class="img-circle avatar" src="assets/demo/avatar/avatar_04.png" alt="" />                            </div>
                            <div class="media-body">
                                <span class="text-gray">Grady Hines</span>
                                <span class="contact-status text-warning">Away</span>                            </div>
                        </li>
                        <li class="media notification-message">
                            <div class="media-left">
                                <img class="img-circle avatar" src="assets/demo/avatar/avatar_06.png" alt="" />                            </div>
                            <div class="media-body">
                                <span class="text-gray">Adrian Barton</span>
                                <span class="contact-status text-success">Online</span>                            </div>
                        </li>
                    </ul>                                
                </div>
            </div>
            </div>
        </div>
    </div>
</div>
        </div>

<script src="assets/js/jquery-1.10.2.min.js"></script> 							<!-- Load jQuery -->
<script src="assets/js/jqueryui-1.10.3.min.js"></script> 							<!-- Load jQueryUI -->
<script src="assets/js/bootstrap.min.js"></script> 								<!-- Load Bootstrap -->
<script src="assets/js/enquire.min.js"></script> 									<!-- Load Enquire -->

<script src="assets/plugins/velocityjs/velocity.min.js"></script>					<!-- Load Velocity for Animated Content -->
<script src="assets/plugins/velocityjs/velocity.ui.min.js"></script>

<script src="assets/plugins/progress-skylo/skylo.js"></script> 		<!-- Skylo -->

<script src="assets/plugins/wijets/wijets.js"></script>     						<!-- Wijet -->

<script src="assets/plugins/sparklines/jquery.sparklines.min.js"></script> 			 <!-- Sparkline -->

<script src="assets/plugins/codeprettifier/prettify.js"></script> 				<!-- Code Prettifier  -->

<script src="assets/plugins/bootstrap-tabdrop/js/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->

<script src="assets/plugins/nanoScroller/js/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->

<script src="assets/plugins/dropdown.js/jquery.dropdown.js"></script> <!-- Fancy Dropdowns -->
<script src="assets/plugins/bootstrap-material-design/js/material.min.js"></script> <!-- Bootstrap Material -->
<script src="assets/plugins/bootstrap-material-design/js/ripples.min.js"></script> <!-- Bootstrap Material -->

<script src="assets/js/application.js"></script>

<!-- End loading site level scripts -->
    
    <!-- Load page level scripts-->
    
<!-- Charts -->
<script src="assets/plugins/charts-flot/jquery.flot.min.js"></script>                 <!-- Flot Main File -->
<script src="assets/plugins/charts-flot/jquery.flot.pie.min.js"></script>             <!-- Flot Pie Chart Plugin -->
<script src="assets/plugins/charts-flot/jquery.flot.stack.min.js"></script>           <!-- Flot Stacked Charts Plugin -->
<script src="assets/plugins/charts-flot/jquery.flot.resize.min.js"></script>          <!-- Flot Responsive -->
<script src="assets/plugins/charts-flot/jquery.flot.tooltip.min.js"></script>         <!-- Flot Tooltips -->
<script src="assets/plugins/charts-flot/jquery.flot.spline.js"></script>              <!-- Flot Curved Lines -->
<script src="assets/plugins/easypiechart/jquery.easypiechart.min.js"></script>        <!-- EasyPieChart-->
<script src="assets/plugins/curvedLines-master/curvedLines.js"></script>              <!-- marvinsplines -->

<script src="assets/plugins/form-daterangepicker/moment.min.js"></script>             <!-- Moment.js for Date Range Picker -->

                 <!-- Date Range Picker -->
<script src="assets/plugins/bootstrap-datepicker/bootstrap-datepicker.js"></script>               <!-- Datepicker -->
<!-- <script src="assets/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js"></script> --> <!-- DateTime Picker -->

<!-- <script src="assets/plugins/jvectormap/jquery-jvectormap-2.0.2.min.js"></script>   -->    <!-- jVectorMap -->
<!-- <script src="assets/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>  --> <!--World Map
<script src="assets/js/application.js"></script>-->
<script src="assets/plugins/chartist/dist/chartist.min.js"></script> <!-- chartist -->
<script src="assets/main/main-index.js"></script>                                     <!-- Initialize scripts for this page-->

    <!-- End loading page level scripts-->
    </body>
</html>