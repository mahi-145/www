<?php
$db1=mysql_connect('localhost','root','');
mysql_select_db('master',$db1) or die('unable to connect');
include('php-sdk/src/facebook.php');

$qry = mysql_query("SELECT * FROM social_media_master WHERE social_media_type='facebook'",$db1);
while($data = mysql_fetch_assoc($qry)){
    
    $facebook = new Facebook(array(
        'appId' => $data['fb_app_id'],
        'secret' => $data['fb_app_secret'],
        'default_graph_version' => $data['fb_api_version']
    ));
     
   
    
    $access_token = $facebook->getAccessToken();
    
    // wall post sourse code
    // &limit=50
     
    $fbpost = $facebook->api('/'.$data['fb_page_id'].'/feed?fields=from,message,full_picture,created_time');
   
   
    //echo "<pre>";
    //print_r($fbpost["data"]);
    //echo "</pre>";
  
    
    if (isset($fbpost["data"]) && !empty($fbpost["data"])) {
        foreach($fbpost["data"] as $post){
            
            $date_source = strtotime($post['created_time']);
            $post['created_time'] = date('Y-m-d H:i:s', $date_source);
            
            $postExist = mysql_query("SELECT id FROM social_media_feedback WHERE message_id='{$post['id']}' and client_id='{$data['client_id']}' and social_media_type='facebook' and sender_type='Wall Post'",$db1);
            $numrow=mysql_num_rows($postExist);
            if($numrow == 0){
                mysql_query("INSERT INTO social_media_feedback(client_id,social_media_type,access_token,message,message_id,picture,sender_name,sender_id,sender_type,sender_time)VALUES('{$data['client_id']}','{$data['social_media_type']}','$access_token','{$post['message']}','{$post['id']}','{$post['full_picture']}','{$post['from']['name']}','{$post['from']['id']}','Wall Post','{$post['created_time']}')",$db1); 
            }        
        }   
    }
    
    //comment sourse code
    
    $fb_comments = $facebook->api('/'.$data['fb_page_id'].'/feed?fields=comments');
    
   
    //echo "<pre>";
    //print_r($fb_comments["data"]);
    //echo "</pre>";
   
    
    if (isset($fb_comments["data"]) && !empty($fb_comments["data"])) {
        foreach($fb_comments["data"] as $row){
            // $row['id']
            foreach($row['comments']['data'] as $val){
                
                $date_source = strtotime($val['created_time']);
                $val['created_time'] = date('Y-m-d H:i:s', $date_source);
                
                $commentExist = mysql_query("SELECT id FROM social_media_feedback WHERE message_id='{$val['id']}' and client_id='{$data['client_id']}' and social_media_type='facebook' and sender_type='Comment'",$db1);
                $numrow=mysql_num_rows($commentExist);
                if($numrow == 0){
                    mysql_query("INSERT INTO social_media_feedback(client_id,social_media_type,access_token,message,message_id,sender_name,sender_id,sender_type,sender_time)VALUES('{$data['client_id']}','{$data['social_media_type']}','$access_token','{$val['message']}','{$val['id']}','{$val['from']['name']}','{$val['from']['id']}','Comment','{$val['created_time']}')",$db1); 
                }
            } 
        }   
    }               
}

//  1843134055922512_1844262715809646/comments/?access_token=428124507576405|2b98c622dad0e44b90f3d4ca2ee8d264&message=helllo Good Morning
?>