<?php 
$sec = "180";
header("Refresh: $sec;");

$db1=mysql_connect('localhost','root','');
mysql_select_db('master',$db1) or die('unable to connect');


$qry = "SELECT id, message, if(picture!='',picture,'') picture, sender_name, sender_id, sender_type,message_id,Complaint FROM social_media_feedback WHERE social_media_type='facebook' and Complaint='1'";  

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Table Editabel Theme</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="description" content="">

    <link rel="shortcut icon" href="assets/img/logo_abc.png">

 	<!--<link type='text/css' href='http://fonts.googleapis.com/css?family=Roboto:300,400,400italic,500' rel='stylesheet'>
     <link type='text/css'href="https://fonts.googleapis.com/icon?family=Material+Icons"  rel="stylesheet"> -->
  

   <link href="assets/material-design-iconic-font/css/material-icon.css" rel="stylesheet">
   <link href="assets/fonts/font-awesome/css/font-awesome.min.css" rel="stylesheet">                        <!-- Font Awesome -->
   <link href="assets/css/styles.css" type="text/css" rel="stylesheet">                                     <!-- Core CSS with all styles -->

   <link href="assets/plugins/codeprettifier/prettify.css" type="text/css" rel="stylesheet">                <!-- Code Prettifier -->

    <link href="assets/plugins/dropdown.js/jquery.dropdown.css" type="text/css" rel="stylesheet">            <!-- iCheck -->
    <link href="assets/plugins/progress-skylo/skylo.css" type="text/css" rel="stylesheet">                   <!-- Skylo -->

    <!--[if lt IE 10]>
        <script src="assets/js/media.match.min.js"></script>
        <script src="assets/js/respond.min.js"></script>
        <script src="assets/js/placeholder.min.js"></script>
    <![endif]-->
    <!-- The following CSS are included as plugins and can be removed if unused-->
    
<link href="assets/plugins/datatables/dataTables.bootstrap.css" type="text/css" rel="stylesheet">                    <!-- Bootstrap Support for Datatables -->
<link href="assets/plugins/datatables/dataTables.themify.css" type="text/css" rel="stylesheet">          
<script type="text/javascript">
function ShowText(val)
{
alert(val);
document.getElementById(val).style.display='block';
}

</script>
<script>
//g_timer = null;

window.fbAsyncInit = function() {
FB.init({
  appId      : '1593714017305747',
  xfbml      : true,
  version    : 'v2.8'
});

//clearTimeout(g_timer);
//startTimer();
};

(function(d, s, id){
 var js, fjs = d.getElementsByTagName(s)[0];
 if (d.getElementById(id)) {return;}
 js = d.createElement(s); js.id = id;
 js.src = "//connect.facebook.net/en_US/sdk.js";
 fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));

   
  
function replyPost(val){
    var id=document.getElementById('messageid'+val).value;
    var postid=document.getElementById('postid'+val).value;
    var msg=document.getElementById('reply_post'+val).value; 
    var url="http://localhost/demo1/tamplate/get_facebook_interaction.php";
    FB.getLoginStatus(function(response) {  alert(response.status);
        if (response.status === 'connected') {
            var uid = response.authResponse.userID;
            var accessToken = response.authResponse.accessToken;
            FB.api('/'+id+'/comments?access_token='+accessToken, 'POST',{ message:msg}, function(response) {
                if (!response || response.error){
                    $("#close-post-box").trigger('click');
                    document.getElementById('messageid').value="";
                    document.getElementById('reply_post').value="";
                    $("#show-message-box").trigger('click');
                    $("#msg-text-message").text('Please login with currect email id / password.');
                }
                else if (response.status === 'not_authorized') {
                    $("#close-post-box").trigger('click');
                    document.getElementById('messageid').value="";
                    document.getElementById('reply_post').value="";
                    $("#show-message-box").trigger('click');
                    $("#msg-text-message").text('User is logged in to Facebook,but has not authenticated your app.');
                }
                else {
                    $.post(url,function(){});
                    $.post('http://localhost/demo1/tamplate/SocialMedia/update_feedback',{id:postid},function(result){
                        if(result){
                            $("#close-post-box").trigger('click');
                            document.getElementById('messageid').value="";
                            document.getElementById('reply_post').value="";
                            $("#show-message-box").trigger('click');
                            $("#msg-text-message").text('Relpy your post/comment successfully.');
                        } 
                    });
                    
                }
            });  
        }
        else{
            $("#show-message-box").trigger('click');
            $("#msg-text-message").text('Please first login then relpy your post/comment.');
        }
    });
}


   
function loginStatus(id,post_id){
    FB.getLoginStatus(function(response) {
        if (response.status === 'connected') {
           document.getElementById('messageid').value=id;
           document.getElementById('postid').value=post_id;
           $("#show-post-box").trigger('click'); 
        }
        else {
            $("#show-message-box").trigger('click');
            $("#msg-text-message").text('Please first login then relpy your post/comment.');
        }
    });
}
</script>

    </head>

    <body class="animated-content infobar-overlay">
        
        
<header id="topnav" class="navbar navbar-bleachedcedar navbar-fixed-top" role="banner">
	<!-- <div id="page-progress-loader" class="show"></div> -->

	<div class="logo-area">
		<a class="navbar-brand navbar-brand-default" href="index.html">
			<img class="show-on-collapse img-logo-white" alt="Paper" src="assets/img/logo-icon-white.png">
			<img class="show-on-collapse img-logo-dark" alt="Paper" src="assets/img/out.png">
			<img class="img-white" alt="Paper" src="assets/img/logo.png">
			<img class="img-dark" alt="ShortTermIncomeFund" src="assets/img/logo_abc.png">		</a>

		<span id="trigger-sidebar" class="toolbar-trigger toolbar-icon-bg stay-on-search">
			<a data-toggle="tooltips" data-placement="right" title="Toggle Sidebar">
				<span class="icon-bg">
					<i class="material-icons">menu</i>				</span>			</a>		</span>
		<!--<span id="trigger-search" class="toolbar-trigger toolbar-icon-bg ov-h">
			<a data-toggle="tooltips" data-placement="right" title="Toggle Sidebar">
				<span class="icon-bg">
					<i class="material-icons">search</i>
				</span>
			</a>
		</span>
		<div id="search-box">
			<input class="form-control" type="text" placeholder="Search..." id="search-input"></input>
		</div> -->
	</div><!-- logo-area -->

	<ul class="nav navbar-nav toolbar pull-right">

		<li class="toolbar-icon-bg appear-on-search ov-h" id="trigger-search-close">
	        <a class="toggle-fullscreen"><span class="icon-bg">
	        	<i class="material-icons">close</i>
	        </span></i></a>	    </li>
		<li class="toolbar-icon-bg hidden-xs" id="trigger-fullscreen">
	        <a href="#" class="toggle-fullscreen"><span class="icon-bg">
	        	<i class="material-icons">fullscreen</i>
	        </span></i></a>	    </li>

   		<li class="dropdown toolbar-icon-bg">
			<a href="#" class="hasnotifications dropdown-toggle" data-toggle='dropdown'><span class="icon-bg"><i class="material-icons">notifications</i></span><span class="badge badge-info"></span></a>
			<div class="dropdown-menu animated notifications">
				<div class="topnav-dropdown-header">
					<span>3 new notifications</span>				</div>
				<div class="scroll-pane">
					<ul class="media-list scroll-content">
						<li class="media notification-success">
							<a href="#">
								<div class="media-left">
									<span class="notification-icon"><i class="material-icons">lock</i></span>								</div>
								<div class="media-body">
									<h4 class="notification-heading">Privacy settings have been changed.</h4>
									<span class="notification-time">8 mins ago</span>								</div>
							</a>						</li>
						<li class="media notification-info">
							<a href="#">
								<div class="media-left">
									<span class="notification-icon"><i class="material-icons">shopping_cart</i></span>								</div>
								<div class="media-body">
									<h4 class="notification-heading">A new order has been placed.</h4>
									<span class="notification-time">24 mins ago</span>								</div>
							</a>						</li>
						<li class="media notification-teal">
							<a href="#">
								<div class="media-left">
									<span class="notification-icon"><i class="material-icons">perm_contact_calendar</i></span>								</div>
								<div class="media-body">
									<h4 class="notification-heading">New event started!</h4>
									<span class="notification-time">16 hours ago</span>								</div>
							</a>						</li>
						<li class="media notification-indigo">
							<a href="#">
								<div class="media-left">
									<span class="notification-icon"><i class="material-icons">settings</i></i></span>								</div>
								<div class="media-body">
									<h4 class="notification-heading">New app settings updated.</h4>
									<span class="notification-time">2 days ago</span>								</div>
							</a>						</li>
						<li class="media notification-danger">
							<a href="#">
								<div class="media-left">
									<span class="notification-icon"><i class="material-icons">comment</i></span>								</div>
								<div class="media-body">
									<h4 class="notification-heading">Jessi commented your post.</h4>
									<span class="notification-time">4 days ago</span>								</div>
							</a>						</li>
					</ul>
				</div>
				<div class="topnav-dropdown-footer">
					<a href="#">See all notifications</a>				</div>
			</div>
		</li>

        <li class="dropdown toolbar-icon-bg hidden-xs">
			<a href="#" class="hasnotifications dropdown-toggle" data-toggle='dropdown'><span class="icon-bg"><i class="material-icons">mail</i></span><span
			class="badge badge-info"></span></a>
			<div class="dropdown-menu animated notifications">
				<div class="topnav-dropdown-header">
					<span>2 new messages</span>				</div>
				<div class="scroll-pane">
					<ul class="media-list scroll-content">
						<li class="media notification-message">
							<a href="#">
								<div class="media-left">
									<img class="img-circle avatar" src="assets/demo/avatar/avatar_01.png" alt="" />								</div>
								<div class="media-body">
									<h4 class="notification-heading"><strong>Amy Green</strong> <span class="text-gray">? Integer vitae libero ac risus egestas placerat.</span></h4>
									<span class="notification-time">2 mins ago</span>								</div>
							</a>						</li>
						<li class="media notification-message">
							<a href="#">
								<div class="media-left">
									<img class="img-circle avatar" src="assets/demo/avatar/avatar_09.png" alt="" />								</div>
								<div class="media-body">
									<h4 class="notification-heading"><strong>Daniel Andrews</strong> <span class="text-gray">? Vestibulum commodo felis quis tortor</span></h4>
									<span class="notification-time">40 mins ago</span>								</div>
							</a>						</li>
						<li class="media notification-message">
							<a href="#">
								<div class="media-left">
									<img class="img-circle avatar" src="assets/demo/avatar/avatar_02.png" alt="" />								</div>
								<div class="media-body">
									<h4 class="notification-heading"><strong>Jane Simpson</strong> <span class="text-gray">? Fusce lobortis lorem at ipsum semper sagittis.</span></h4>
									<span class="notification-time">6 hours ago</span>								</div>
							</a>						</li>
						<li class="media notification-message">
							<a href="#">
								<div class="media-left">
									<img class="img-circle avatar" src="assets/demo/avatar/avatar_03.png" alt="" />								</div>
								<div class="media-body">
									<h4 class="notification-heading"><strong>Harold Hawkins</strong> <span class="text-gray">? Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</span></h4>
									<span class="notification-time">8 days ago</span>								</div>
							</a>						</li>
						<li class="media notification-message">
							<a href="#">
								<div class="media-left">
									<img class="img-circle avatar" src="assets/demo/avatar/avatar_04.png" alt="" />								</div>
								<div class="media-body">
									<h4 class="notification-heading"><strong>Brian Fisher</strong> <span class="text-gray">? Praesent dapibus, neque id cursus faucibus.</span></h4>
									<span class="notification-time">16 hours ago</span>								</div>
							</a>						</li>
						<li class="media notification-message">
							<a href="#">
								<div class="media-left">
									<img class="img-circle avatar" src="assets/demo/avatar/avatar_05.png" alt="" />								</div>
								<div class="media-body">
									<h4 class="notification-heading"><strong>Dylan Black</strong> <span class="text-gray">? Pellentesque fermentum dolor. </span></h4>
									<span class="notification-time">2 days ago</span>								</div>
							</a>						</li>
						<li class="media notification-message">
							<a href="#">
								<div class="media-left">
									<img class="img-circle avatar" src="assets/demo/avatar/avatar_06.png" alt="" />								</div>
								<div class="media-body">
									<h4 class="notification-heading"><strong>Bobby Harper</strong> <span class="text-gray">? Sed adipiscing ornare risus. Morbi est est.</span></h4>
									<span class="notification-time">4 days ago</span>								</div>
							</a>						</li>
					</ul>
				</div>
				<div class="topnav-dropdown-footer">
					<a href="#">See all messages</a>				</div>
			</div>
		</li>

		<li class="toolbar-icon-bg" id="trigger-infobar">
			<a data-toggle="tooltips" data-placement="right" title="Toggle Sidebar">
				<span class="icon-bg">
					<i class="material-icons">more_vert</i>				</span>			</a>		</li>
	</ul>
</header>

        <div id="wrapper">
            <div id="layout-static">
                <div class="static-sidebar-wrapper sidebar-bleachedcedar">
                    <div class="static-sidebar">
                        <div class="sidebar">
	
	<div class="widget stay-on-collapse" id="widget-sidebar">
        <nav role="navigation" class="widget-body">
	<ul class="acc-menu">
		<li class="nav-separator"><span>Navigation</span></li>
		<li><a  class="withripple" href="index.php"><span class="icon">
		<i class="material-icons">home</i></span><span>Dashboard</span><span class="badge badge-teal"></span></a></li>
		<li><a  class="withripple" href="javascript:;"><span class="icon"><i class="fa fa-user"></i></span><span>Client Management</span></a>
			<ul class="acc-menu">
				<li><a  class="withripple" href="crm.php">CRM</a></li>
				<li><a  class="withripple" href="#">Choose Service Plan</a></li>
				<li><a  class="withripple" href="#">Process Registration</a></li>
				<li><a  class="withripple" href="#">ECR Creation</a></li>	
			</ul>
		</li>

		<li><a  class="withripple" href="javascript:;"><span class="icon"><i class="material-icons">settings</i></span><span>Client Operations</span></a>
			<ul class="acc-menu">
				<li><a  class="withripple" href="message-list.php">facebook</a></li>
				<li><a  class="withripple" href="#">Link 1</a></li>
			</ul>
		</li>

        <li><a  class="withripple" href="javascript:;"><span class="icon"><i class="fa fa-headphones"></i></span><span>Agent Calling</span></a>
        	<ul class="acc-menu">
        		<!--<li><a  class="withripple" href="#">New</a></li>-->
				<li><a  class="withripple" href="message-list-unresolve.php">Unresolved</a></li>
        		<li><a  class="withripple" href="message-list-resolve.php">Resolved</a></li>
        	</ul>
        </li>
	</ul>
</nav>
    </div>
</div>
                    </div>
                </div>
                <div class="static-content-wrapper">
                    <div class="static-content">
                        <div class="page-content">
                            <ol class="breadcrumb">
                                
<li><a href="index.html">Home</a></li>
<li><a href="#">Advanced Tables</a></li>
<li class="active"><a href="tables-editable.html">Feedbacks</a></li>
                            </ol>
                            <div class="page-heading">            
                               
                               <h1>Feedbacks</h1>
                           </div>
                            <div class="container-fluid">
							
                                
<div data-widget-group="group1">
            </div>      
                    <form name="frm" method="post">
                    <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered datatables" >
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>Message</th>
								<th>Sender name</th>
                                <th>Sender ID</th>
                                <th>Sender type</th>
								<th> 			</th>
                            </tr>
                        </thead>
                        <tbody>
                            
						<?php 
						$str= mysql_query($qry, $db1);
						$row= $str;
						$i=1;
						while($data= mysql_fetch_array($row))
						{
						
						?>
							<tr>						
                                <td><?php echo $data['id'] ?></td>
                                <td><?php if($data['picture']!='') {echo wordwrap($data['message'],40,"<br>") ."<img src=".$data['picture']." height\"100px\" width=\"100\">"; } else { echo wordwrap($data['message'],30,"<br>"); }?></td>
                                <td><?php echo $data['sender_name'] ?></td>
                                <td><?php echo $data['sender_id'] ?></td>
                                <td><?php echo $data['sender_type'] ?></td>
								
								
							                            </tr>
							
							<?php $i++; } ?>
							
							
                        </tbody>
                    </table>
					</form><!--end table-->
                </div>
                <div class="panel-footer"></div>
            </div>
        </div>
    </div>

<!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script> -->

<script src="assets/js/jquery-1.10.2.min.js"></script> 							<!-- Load jQuery -->
<script src="assets/js/jqueryui-1.10.3.min.js"></script> 							<!-- Load jQueryUI -->
<script src="assets/js/bootstrap.min.js"></script> 								<!-- Load Bootstrap -->
<script src="assets/js/enquire.min.js"></script> 									<!-- Load Enquire -->

<script src="assets/plugins/velocityjs/velocity.min.js"></script>					<!-- Load Velocity for Animated Content -->
<script src="assets/plugins/velocityjs/velocity.ui.min.js"></script>

<script src="assets/plugins/progress-skylo/skylo.js"></script> 		<!-- Skylo -->

<script src="assets/plugins/wijets/wijets.js"></script>     						<!-- Wijet -->

<script src="assets/plugins/sparklines/jquery.sparklines.min.js"></script> 			 <!-- Sparkline -->

<script src="assets/plugins/codeprettifier/prettify.js"></script> 				<!-- Code Prettifier  -->

<script src="assets/plugins/bootstrap-tabdrop/js/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->

<script src="assets/plugins/nanoScroller/js/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->

<script src="assets/plugins/dropdown.js/jquery.dropdown.js"></script> <!-- Fancy Dropdowns -->
<script src="assets/plugins/bootstrap-material-design/js/material.min.js"></script> <!-- Bootstrap Material -->
<script src="assets/plugins/bootstrap-material-design/js/ripples.min.js"></script> <!-- Bootstrap Material -->

<script src="assets/js/application.js"></script>

<!-- End loading site level scripts -->
    
    <!-- Load page level scripts-->
    
<script src="assets/plugins/datatables/jquery.dataTables.js"></script>                            <!-- Data Tables -->
<script src="assets/plugins/datatables/TableTools.js"></script>                                   <!-- TableTools -->
<script src="assets/plugins/jquery-editable/jquery.editable.js"></script>                         <!-- jQuery Editable -->
<script src="assets/plugins/datatables/dataTables.editor.js"></script>                            <!-- Data Tables Editor-->
<script src="assets/plugins/datatables/dataTables.editor.bootstrap.js"></script>                  <!-- Data Tables Editor for Bootstrap-->
<script src="assets/plugins/datatables/dataTables.bootstrap.js"></script>                         <!-- Bootstrap Support for Datatables -->

<script src="assets/main/tableeditable.js"></script> 

    <!-- End loading page level scripts-->
    </body>
</html>