<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">

<head>
<title>home</title>
<meta charset="utf-8">    
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta name="description" content="Your description">
<meta name="keywords" content="Your keywords">
<meta name="author" content="Your name">
<meta name = "format-detection" content = "telephone=no" />
<!--CSS-->
<link rel="stylesheet" href="css/bootstrap.css" >
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/camera.css">
<link rel="stylesheet" href="fonts/font-awesome.css">
</head>
<body>
<!--header-->


<?php include("header.php");?>



<div class="global">
    <div class="container">
        <div class="row">
            <article class="col-lg-12 welcomeBox">
                <p class="title1"><span>Welcome</span> to ABC Solutions</p>
                <hr>
                <p class="description">   </p>
            </article>
        </div>
    </div>
    <section class="bannerBox clearfix">
        <div class="container">
            <div class="row">
                <article class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                    <p class="title">Powerful CRM</p>
                    <p>A good CRM gives you insights into running your business. A smart CRM gives you the information you need in a way that you can use it. An ideal CRM offers you a solution to simplify your processes from day one. 

Complaints are the ultimate customer feedback. They show what’s not working so it can be fixed. Turning a dissatisfied customer into a happy one is good business. Ultimately it aids customer retention and loyalty. Faced with a growing number of customer complaints – along with pressure from regulators to handle disputes faster and more fairly – financial services firms need a new approach. Traditional, manual systems can’t cope. An automated system – delivered on demand through the cloud or on site – is needed to provide a consistent approach.
</p>
                </article>
                <article class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                    <p class="title">Social CRM</p>
                    <p>Social CRM is a philosophy and a business strategy, supported by a technology platform, business rules, workflow, processes and social characteristics, designed to engage the customer in a collaborative conversation in order to provide mutually beneficial value in a trusted and transparent business environment. It’s the company’s response to the customer’s ownership of the conversation” – Paul Greenberg</p>
 
<p>Social CRM is all about the use of social media by an organization or a brand to respond to the customers. While Social CRM companies can measure where does their brand stand and also can interact with customers directly. Some of the popular used social media for CRM are Facebook & Twitter
For example, telecom giant “Vodafone” has connected with its customers through facebook and twitter. Apart from marketing about new schemes and offers they ask for their feedback from the customers through these platforms.</p>
                </article>
                <article class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                    <p class="title">ABC Solutions</p>
                    <p>•	Manage all your social media interactions from one place</p>
                    <p> •	Integrate your company's social media accounts such as email, facebook with your CRM and keep track of your customer's social media activities in real time
                	<p>•	Get notified immmediately when they interact with your brand in social media so you can respond immediately and close deals faster</p>
				</article>
            </div>
        </div>
    </section>
    <section class="servicesBox clearfix">
        <div class="container">
            <div class="row">                
                <article class="col-lg-8 col-md-8 col-sm-8 memberBox"> 
                    <h2>Contact Us</h2>
                    <div class="row">   
                        <article class="col-lg-6 col-md-6 col-sm-6"> 
                            <p>Surajmal Vihar Delhi-110092</p>
                        </article>
                        <article class="col-lg-6 col-md-6 col-sm-6"> 
                            <p>#9711443344</p>
							<p>abcsolutions.com</p>
                                       </article>
                    </div>
                </article>
                <article class="col-lg-3 col-md-12 col-sm-12 manBox">
                             </article>
            </div>
        </div>
    </section>
</div>
<!--footer-->


<?php include("footer.php");?>
<script src="js/bootstrap.min.js"></script>
<script src="js/scripts.js"></script>

</body>
</html>