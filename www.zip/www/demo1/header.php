<header class="clearfix">
    <div class="menuBox clearfix">
        <div class="container">
            <div class="row">
                <article class="col-lg-12 col-md-12 col-sm-12">
                    <h1 class="navbar-brand navbar-brand_"><a href="index.php">ABC solutions</a></h1>
                    <nav class="navbar navbar-default navbar-static-top mynavbar clearfix" role="navigation">
                        <ul class="nav sf-menu clearfix">
                            <li class="active"><a href="index.php">home</a></li>
                            <li><a href="about.php">about<span></span></a></li>
                            <li><a href="services.php">services</a></li>
							
							<?php if($_SESSION['EmailId']=='') { ?>
                            <li><a href="products.php">Login</a></li>
	<!--						<li><a href="postlogin.php">post login</a></li>   -->
	                         <li><a href="contact.php">Sign Up</a></li>
							<?php } else { ?>
							<li><a href="postlogin1.php">Social Detail</a></li>
							<li><a href="logout.php">Logout</a></li>
								
							<?php } ?>
                        </ul>
                    </nav>
					
					<span style="padding-left:500px;"><?php echo $_SESSION['EmailId'];?></span>
                </article>
            </div>
        </div>
    </div>
</header>