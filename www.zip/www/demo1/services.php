<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
<title>menu</title>
<meta charset="utf-8">    
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta name="description" content="Your description">
<meta name="keywords" content="Your keywords">
<meta name="author" content="Your name">
<!--CSS-->
<link rel="stylesheet" href="css/bootstrap.css" >
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/font-awesome.css">

</head>
<body>
<!--header-->
<?php include("header.php");?>

<div class="global indent">
    <div class="container padBot">
        <div class="row">
            <article class="col-lg-8 col-md-6 col-sm-6">
                <h2>Services</h2>
                <div class="thumb-pad5">
                    <div class="thumbnail">
                        <div class="caption">
                            <h3></h3>
                            <p>
								•	  Customer acquisition and retention </p>
<p>								•	  Minimal customer effort</p>
<p>								•	  Improved business productivity and profitability</p> 
</p>
                            
                          </div>
                    </div>
                </div>
            </article>
                <section class="col-lg-4 col-md-4 col-sm-4">
                            </div>
                        </div>
                    </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
<!--footer-->

<?php include("footer.php");?>

<script src="js/bootstrap.min.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>