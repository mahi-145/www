<footer>
    <div class="container">
        <div class="row">
            <article class="col-lg-12 col-md-12 col-sm-12 box1">
                <ul class="foo_menu">
                    <li class="active"><a class="index.php">home</a></li>
                    <li><a href="about.php">about</a></li>
                    <li><a href="services.php">services</a></li>
                    <li><a href="products.php">Login</a></li>
                    <li><a href="contact.php">Sign Up</a></li>
                </ul>
                <p>ABC Solutions &copy; <em id="copyright-year"></em> </p>
<p class="copy_rt"></p>
                
            </article>
        </div>
    </div>
</footer>