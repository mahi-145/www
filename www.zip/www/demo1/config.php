<?php
$Con = mysql_connect("localhost","root","");
$Db = mysql_select_db("master",$Con);
$title = "ABC solutions";

?>