package com.cg.employeeleave.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.employeeleave.beans.EmployeeDetails;
import com.cg.employeeleave.beans.EmployeeLeaveDetails;
import com.cg.employeeleave.service.IEmployeeService;

@Controller
public class EmployeeController 
{
	@Autowired
	IEmployeeService employeeservice;

	@RequestMapping(value="home",method=RequestMethod.GET)
	public String  getAll()
	{
		return "Home";
	}
	
	@RequestMapping(value="retrievempId",method=RequestMethod.GET)
	public ModelAndView ValidateEmpId(@RequestParam("eid")int empId)
	{
		if(employeeservice.validateEmployeeId(empId)==true)
		{
			if(employeeservice.ValidateEmpIds(empId)==true)
			{
				List<EmployeeLeaveDetails> myData =employeeservice.getEmployeeLeaveDeatils(empId);
				return new ModelAndView("ViewLeaveDetails","emp",myData);
			}
			else
			{
				//List<EmployeeDetails> myData1=employeeservice.getEmployeeName(empId);
				return new ModelAndView("NoLeaveFound");
			}
			
		}
		
		else
		{
			//return new ModelAndView("Home");
			return new ModelAndView("Failure");
		}
		
		//}
		//System.out.println("123");
		//List<EmployeeLeaveDetails> myData =employeeservice.getEmployeeLeaveDeatils(empId);
		//List<EmployeeDetails> myData1=employeeservice.getEmployeeName(empId);
		//System.out.println("234");
		//return new ModelAndView( "ViewLeaveDetails","emp",myData);
	}
}
