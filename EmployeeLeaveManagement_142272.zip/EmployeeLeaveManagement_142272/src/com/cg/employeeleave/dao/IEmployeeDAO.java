package com.cg.employeeleave.dao;

import java.util.List;

import com.cg.employeeleave.beans.EmployeeDetails;
import com.cg.employeeleave.beans.EmployeeLeaveDetails;

public interface IEmployeeDAO 
{
	public List<EmployeeLeaveDetails> getEmployeeLeaveDeatils(int empId);
	
	public List<EmployeeDetails> getEmployeeName(int empId);
	
	
	/****************************************************************/
	public List<Integer> getEmployeeIds();
	public List<Integer> getEmpIds();
}
