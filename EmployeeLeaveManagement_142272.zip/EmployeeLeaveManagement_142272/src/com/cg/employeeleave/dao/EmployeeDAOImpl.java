package com.cg.employeeleave.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.employeeleave.beans.EmployeeDetails;
import com.cg.employeeleave.beans.EmployeeLeaveDetails;

@Repository("employeeDao")
public class EmployeeDAOImpl implements IEmployeeDAO 
{
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<EmployeeLeaveDetails> getEmployeeLeaveDeatils(int empId) 
	{
		Query queryTwo=entityManager.createQuery
						("SELECT eld FROM EmployeeLeaveDetails eld WHERE empId=:eid");
		queryTwo.setParameter("eid", empId);
		return queryTwo.getResultList();
	}

	@Override
	public List<EmployeeDetails> getEmployeeName(int empId) 
	{
		Query queryTwo=entityManager.createQuery
						("SELECT empName FROM EmployeeDetails WHERE empId=:eid");
		queryTwo.setParameter("eid", empId);
		return queryTwo.getResultList();
	}

	@Override
	public List<Integer> getEmployeeIds() 
	{
		Query queryTwo=entityManager.createQuery
				("SELECT empId FROM EmployeeDetails");
		return queryTwo.getResultList();
	}

	@Override
	public List<Integer> getEmpIds() 
	{
		Query queryTwo=entityManager.createQuery
				("SELECT empId FROM EmployeeLeaveDetails");
		return queryTwo.getResultList();
	}

}
