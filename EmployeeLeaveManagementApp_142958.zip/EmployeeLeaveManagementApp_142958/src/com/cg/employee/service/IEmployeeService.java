/*
 * Author:Jymane
 * This Interface Declares All the functions 
 * Related to validation and Dao Class*/
package com.cg.employee.service;

import java.util.List;

import com.cg.employee.dto.EmployeeDetails;
import com.cg.employee.dto.EmployeeLeaveDetails;

public interface IEmployeeService 
{

	public List<EmployeeLeaveDetails> getEmployeeLeaveDeatils(Long empId);
	public boolean validateEmployeeId(long empId);
	public EmployeeDetails getEmpName(long empId);
	public int validateEmployeeLeave(long empId);
}
