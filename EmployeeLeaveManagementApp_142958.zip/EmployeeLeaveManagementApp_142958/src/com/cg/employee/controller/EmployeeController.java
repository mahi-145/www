/**
 *@author jymane
 *Class Function:Controller
 */
package com.cg.employee.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.employee.dto.EmployeeDetails;
import com.cg.employee.dto.EmployeeLeaveDetails;
import com.cg.employee.service.IEmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	IEmployeeService employeeservice;
	
	@RequestMapping(value="all", method=RequestMethod.GET)
	public String show(Model model)
	{
		model.addAttribute("my", new EmployeeDetails());
		return "Home";
	}

	@RequestMapping(value="viewdetails", method=RequestMethod.GET)
	public ModelAndView retrieveData(@Valid @ModelAttribute("my") EmployeeDetails ede,
			BindingResult result)
	{
		ModelAndView mv = new ModelAndView();
		if(result.hasErrors())
		{
			mv.setViewName("Home");
		//	mv.addObject("temp", "Binding Failed");
		}
		else
		{
		try {
			if(employeeservice.validateEmployeeId(ede.getEmpId()))
			{
				/*After Validating EmpId*/
				EmployeeDetails edetail=employeeservice.getEmpName(ede.getEmpId());
				mv.addObject("empDetail", edetail);
				int count=employeeservice.validateEmployeeLeave(ede.getEmpId());
				if(count!=0)
				{
					/*If EmpId is Exits In EmployeeLeaveDetails*/
					List<EmployeeLeaveDetails> empLeaveDetails2=employeeservice.getEmployeeLeaveDeatils(ede.getEmpId());
					mv.addObject("temp",empLeaveDetails2);
					mv.addObject("error",count);
					mv.setViewName("ViewLeaveDetails");
				}
				else
				{
					/*If EmpId is Not Exits In EmployeeLeaveDetails*/
					mv.addObject("error",count);
					mv.addObject("temp", "No Leave record Found");
					mv.setViewName("ViewLeaveHistory");
				}
			}
			else{
				/*If EmpId Not Exits*/
				mv.addObject("temp","This Employee ID Does not exist..");
				mv.setViewName("Home");
			}
		}
		catch (Exception e) 
		{
			mv.addObject("temp",e.getMessage());
			mv.setViewName("Error");
		}
	}

	return mv;
}
}
