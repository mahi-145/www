package com.gear.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gear.bean.Gear;
import com.gear.dao.IGearDao;
import com.gear.exception.GearException;

@Service
public class GearServiceImpl implements IGearService {
	
	@Autowired
	private IGearDao gearDao;
	
	
	
	public IGearDao getGearDao() {
		return gearDao;
	}



	public void setGearDao(IGearDao gearDao) {
		this.gearDao = gearDao;
	}



	@Override
	public Gear view(int queryId) throws GearException {
		
		return gearDao.view(queryId);
	}



	@Override
	public boolean update(Gear gear) throws GearException {
		
		return gearDao.update(gear);
	}

}
