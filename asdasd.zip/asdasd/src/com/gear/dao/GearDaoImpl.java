package com.gear.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.gear.bean.Gear;
import com.gear.exception.GearException;

@Repository
@Transactional
public class GearDaoImpl implements IGearDao {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public Gear view(int queryId) throws GearException 
	{
		Gear bean=new Gear();
		
		try {
			TypedQuery<Gear> qry= entityManager.createQuery("from Gear where queryId=:queryId",Gear.class);
			qry.setParameter("queryId", queryId);
			bean=qry.getSingleResult();
			
		} catch (Exception e) {
			throw new GearException("\n\n\n\nUnable to view in dao layer\n\n\n\n"+e.getMessage());
		}
		return bean;
	}

	@Override
	public boolean update(Gear gear) throws GearException {
boolean isUpdated=false;
		
		
		try {
		//	EmployeeBean emp=entityManager.find(EmployeeBean.class, bean.getEmployeeId());

			
				//emp.setEmployeeName("Shyam");
				
				entityManager.merge(gear);
				isUpdated=true;
		} catch (Exception e) {
			throw new GearException("Unable to update employee in dao layer"+e.getMessage());
		}
		
		return isUpdated;
	}

}
