package com.cg.leave.controller;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.leave.bean.EmployeeDetails;
import com.cg.leave.bean.EmployeeLeaveDetails;
import com.cg.leave.service.IEmployeeLeaveService;



@Controller
public class MyController 
{
	
	@Autowired
	IEmployeeLeaveService employeeleaveservice;
	
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll()
	{
		return "home";
		
	}
	
	@RequestMapping(value="check",method=RequestMethod.POST)
	public ModelAndView validateEmployeeId(@RequestParam("eId") int eId,Model model) throws Exception
	{
	//	if(employeeleaveservice.validateId(eId)){
		List<EmployeeLeaveDetails> eList=employeeleaveservice.getLeaveDetails(eId);
		List<EmployeeDetails> idList=employeeleaveservice.getId(eId);
		try
		{
		/*	if(eid==0)*/
		//	if(employeeleaveservice.validateId(eId))
			if(idList.size()==0)
			{
				System.out.println("are you working? yes");
				int empId = eId;
				model.addAttribute("eId",eId);
				return new ModelAndView("noIdExist","temp",idList);
				
			}	
			
			else if(eList.size()==0)
			{
				System.out.println(eId);
				int empId=eId;
				model.addAttribute("eId",eId);
				String name = employeeleaveservice.getName(eId);
				model.addAttribute("name",name);
				return new ModelAndView("noLeaveFound","temp",eList);
			}
			
			
				int empId=eId;
				model.addAttribute("eId",eId);
				String name = employeeleaveservice.getName(eId);
				
				model.addAttribute("name",name);
				return new ModelAndView("viewLeaveDetails","temp",eList);

		}
		catch(Exception e)
		{
			throw new Exception("Some error occured"+e.getMessage());
		}
		
	}
/*		else{
			return new ModelAndView("nouser");
		}*/
	
	
	
	
	
	
}
	

