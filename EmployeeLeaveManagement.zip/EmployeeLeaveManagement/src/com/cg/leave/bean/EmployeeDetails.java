package com.cg.leave.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="employee_details")
public class EmployeeDetails 
{
	@Id
	@Column(name="empid")
	private int empId;
	
	@Column(name="ename")
	private String empName;
	
	@Column(name="address")
	private String empAddress;
	
	@Column(name="leaves_avail")
	private int leavesAvail;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpAddress() {
		return empAddress;
	}

	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}

	public int getLeavesAvail() {
		return leavesAvail;
	}

	public void setLeavesAvail(int leavesAvail) {
		this.leavesAvail = leavesAvail;
	}

	@Override
	public String toString() {
		return "EmployeeDetails [empId=" + empId + ", empName=" + empName
				+ ", empAddress=" + empAddress + ", leavesAvail=" + leavesAvail
				+ "]";
	}
	
	
	
	
	
}
